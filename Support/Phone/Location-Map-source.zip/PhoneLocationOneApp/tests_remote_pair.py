"""Local cryptographic peer + real stdlib TLS-PSK tests. No phone access."""

import asyncio
import base64
import ipaddress
import json
from pathlib import Path
import plistlib
import ssl
import tempfile
import unittest
from unittest import mock

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, x25519
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

import remote_pair as rp


HOST_KEY = ed25519.Ed25519PrivateKey.from_private_bytes(b"h" * 32)
DEVICE_KEY = ed25519.Ed25519PrivateKey.from_private_bytes(b"d" * 32)
HOST_ID = b"trusted-host-record"
DEVICE_ID = b"trusted-peer-record"


def raw(key):
    return key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)


def derive(secret, info, salt=None):
    return HKDF(algorithm=hashes.SHA512(), length=32, salt=salt, info=info).derive(secret)


def b64(value):
    return base64.b64encode(value).decode()


def tlv(entries):
    output = bytearray()
    for kind, data in entries:
        while len(data) > 255:
            output.extend(bytes((kind, 255)) + data[:255])
            data = data[255:]
        output.extend(bytes((kind, len(data))) + data)
    return bytes(output)


def untlv(data):
    output = {}
    while data:
        kind, size = data[:2]
        output[kind] = output.get(kind, b"") + data[2:2 + size]
        data = data[2 + size:]
    return output


async def receive(reader, magic=b"RPPairing"):
    assert await reader.readexactly(len(magic)) == magic
    size = int.from_bytes(await reader.readexactly(2), "big")
    return json.loads(await reader.readexactly(size))


def frame(value, magic=b"RPPairing"):
    payload = json.dumps(value, separators=(",", ":")).encode()
    return magic + len(payload).to_bytes(2, "big") + payload


class MockPeer:
    def __init__(self, *, bad_signature=False, wrong_identifier=False,
                 corrupt_encryption=False, reject=False, wrong_psk=False):
        self.bad_signature = bad_signature
        self.wrong_identifier = wrong_identifier
        self.corrupt_encryption = corrupt_encryption
        self.reject = reject
        self.wrong_psk = wrong_psk
        self.secret = None
        self.host_proof_received = False
        self.control_closed = asyncio.Event()
        self.tls_done = asyncio.Event()
        self.errors = []
        self.tasks = set()
        self.writers = []
        self.sequence = 0

    async def start(self):
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_2
        context.set_ciphers("PSK-AES256-CBC-SHA384")
        context.set_psk_server_callback(lambda identity: b"!" * 32 if self.wrong_psk else self.secret)
        self.tls_server = await asyncio.start_server(self.tls, "127.0.0.1", 0, ssl=context)
        self.tls_port = self.tls_server.sockets[0].getsockname()[1]
        self.control_server = await asyncio.start_server(self.control, "127.0.0.1", 0)
        self.port = self.control_server.sockets[0].getsockname()[1]
        return self

    async def close(self):
        for server in (self.control_server, self.tls_server):
            server.close()
        for writer in self.writers:
            writer.close()
        for task in list(self.tasks):
            task.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)
        for server in (self.control_server, self.tls_server):
            await asyncio.wait_for(server.wait_closed(), 2)

    async def send(self, writer, value, encrypted=False):
        message = {"streamEncrypted" if encrypted else "plain": {"_0": value}}
        writer.write(frame({"message": message, "sequenceNumber": self.sequence,
                            "originatedBy": "device"}))
        self.sequence += 1
        await writer.drain()

    async def control(self, reader, writer):
        task = asyncio.current_task()
        self.tasks.add(task)
        self.writers.append(writer)
        try:
            handshake = await receive(reader)
            assert handshake["sequenceNumber"] == 0
            options = handshake["message"]["plain"]["_0"]["request"]["_0"]["handshake"]["_0"]
            assert options == {"hostOptions": {"attemptPairVerify": True}, "wireProtocolVersion": 19}
            await self.send(writer, {"response": {"_1": {"handshake": {"_0": {"wireProtocolVersion": 19}}}}})
            m1 = await receive(reader)
            assert m1["sequenceNumber"] == 1
            pairing = m1["message"]["plain"]["_0"]["event"]["_0"]["pairingData"]["_0"]
            assert pairing["kind"] == "verifyManualPairing" and pairing["startNewSession"] is True
            if self.reject:
                await self.send(writer, {"event": {"_0": {"pairingRejectedWithError": {
                    "wrappedError": {"userInfo": {"NSLocalizedDescription": "DO-NOT-LOG-PEER-SECRET"}}}}}})
                await reader.read()
                return
            request = untlv(base64.b64decode(pairing["data"]))
            assert request[6] == b"\x01"
            host_ephemeral = request[3]
            ephemeral = x25519.X25519PrivateKey.from_private_bytes(b"e" * 32)
            peer_ephemeral = raw(ephemeral.public_key())
            self.secret = ephemeral.exchange(x25519.X25519PublicKey.from_public_bytes(host_ephemeral))
            cipher = ChaCha20Poly1305(derive(self.secret, b"Pair-Verify-Encrypt-Info", b"Pair-Verify-Encrypt-Salt"))
            identifier = b"different-device" if self.wrong_identifier else DEVICE_ID
            signature = DEVICE_KEY.sign(peer_ephemeral + identifier + host_ephemeral)
            if self.bad_signature:
                signature = bytes((signature[0] ^ 1,)) + signature[1:]
            encrypted = cipher.encrypt(b"\0\0\0\0PV-Msg02", tlv(((1, identifier), (10, signature))), b"")
            if self.corrupt_encryption:
                encrypted = encrypted[:-1] + bytes((encrypted[-1] ^ 1,))
            response = tlv(((6, b"\x02"), (3, peer_ephemeral), (5, encrypted)))
            await self.send(writer, {"event": {"_0": {"pairingData": {"_0": {"data": b64(response)}}}}})
            try:
                m3 = await receive(reader)
            except asyncio.IncompleteReadError:
                return  # Expected if the client rejected the peer proof.
            assert m3["sequenceNumber"] == 2
            pairing = m3["message"]["plain"]["_0"]["event"]["_0"]["pairingData"]["_0"]
            assert pairing["startNewSession"] is False
            request = untlv(base64.b64decode(pairing["data"]))
            assert request[6] == b"\x03"
            host = untlv(cipher.decrypt(b"\0\0\0\0PV-Msg03", request[5], b""))
            assert host[1] == HOST_ID
            HOST_KEY.public_key().verify(host[10], host_ephemeral + HOST_ID + peer_ephemeral)
            self.host_proof_received = True
            await self.send(writer, {"event": {"_0": {"pairingData": {"_0": {"data": b64(tlv(((6, b"\x04"),)))}}}}})
            envelope = await receive(reader)
            assert envelope["sequenceNumber"] == 3
            encrypted = base64.b64decode(envelope["message"]["streamEncrypted"]["_0"])
            client_cipher = ChaCha20Poly1305(derive(self.secret, b"ClientEncrypt-main"))
            request = json.loads(client_cipher.decrypt(bytes(12), encrypted, b""))
            assert request == {"request": {"_0": {"createListener": {
                "key": b64(self.secret), "transportProtocolType": "tcp"}}}}
            server_cipher = ChaCha20Poly1305(derive(self.secret, b"ServerEncrypt-main"))
            response = json.dumps({"response": {"_1": {"createListener": {"port": self.tls_port}}}}, separators=(",", ":")).encode()
            await self.send(writer, b64(server_cipher.encrypt(bytes(12), response, b"")), encrypted=True)
            await reader.read()  # The control channel must remain alive with the tunnel.
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.errors.append(exc)
        finally:
            self.control_closed.set()
            writer.close()
            self.tasks.discard(task)

    async def tls(self, reader, writer):
        task = asyncio.current_task()
        self.tasks.add(task)
        self.writers.append(writer)
        try:
            assert await receive(reader, b"CDTunnel") == {"type": "clientHandshakeRequest", "mtu": 16000}
            response = frame({"type": "serverHandshakeResponse", "clientParameters": {
                "address": "fd00::2", "netmask": "ffff:ffff:ffff:ffff::", "mtu": 16000},
                "serverAddress": "fd00::1", "serverRSDPort": 58783}, b"CDTunnel")
            # Fragment the handshake, and coalesce its tail with the first IPv6 packet.
            packet = (b"\x60\0\0\0" + (8).to_bytes(2, "big") + b"\x3b\x40" +
                      ipaddress.IPv6Address("fd00::1").packed +
                      ipaddress.IPv6Address("fd00::2").packed + b"testdata")
            self.packet = packet
            writer.write(response[:3])
            await writer.drain()
            writer.write(response[3:] + packet)
            await writer.drain()
            assert await reader.readexactly(len(packet)) == packet
            writer.write(packet)
            await writer.drain()
            self.tls_done.set()
            await reader.read()
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            self.errors.append(exc)
        finally:
            writer.close()
            self.tasks.discard(task)


@unittest.skipUnless(getattr(ssl, "HAS_PSK", False), "Python 3.13/OpenSSL PSK required")
class RemotePairTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.path = Path(self.directory.name) / "pairing.plist"
        self.peers = []

    async def asyncTearDown(self):
        for peer in self.peers:
            await peer.close()
        self.directory.cleanup()

    def record(self, trusted=True):
        value = {"identifier": HOST_ID.decode(), "private_key": b"h" * 32,
                 "public_key": raw(HOST_KEY.public_key()), "alt_irk": b"i" * 16}
        if trusted:
            value.update(peer_identifier=DEVICE_ID.decode(), peer_public_key=raw(DEVICE_KEY.public_key()))
        content = plistlib.dumps(value, fmt=plistlib.FMT_BINARY)
        self.path.write_bytes(content)
        return content

    async def peer(self, **options):
        peer = await MockPeer(**options).start()
        self.peers.append(peer)
        return peer

    async def test_mutual_peer_proof_actual_tls_and_raw_ipv6(self):
        content = self.record()
        peer = await self.peer()
        tunnel = await rp.open_tunnel(self.path, "127.0.0.1", peer.port)
        self.assertTrue(tunnel.peer_authenticated)
        self.assertEqual(tunnel.authentication_mode, "verified_peer_identity")
        self.assertEqual((tunnel.client_address, tunnel.server_address, tunnel.rsd_port, tunnel.mtu),
                         ("fd00::2", "fd00::1", 58783, 16000))
        self.assertEqual(tunnel.writer.get_extra_info("ssl_object").cipher()[0], rp.CIPHER)
        self.assertEqual(await tunnel.reader.readexactly(48), peer.packet)
        tunnel.writer.write(peer.packet)
        await tunnel.writer.drain()
        self.assertEqual(await tunnel.reader.readexactly(48), peer.packet)
        self.assertFalse(peer.control_closed.is_set())
        self.assertTrue(peer.host_proof_received)
        await tunnel.aclose()
        await asyncio.wait_for(peer.control_closed.wait(), 2)
        self.assertFalse(peer.errors)
        self.assertEqual(self.path.read_bytes(), content)

    async def test_original_host_only_record_compatible_but_not_claimed_mutual(self):
        self.record(trusted=False)
        peer = await self.peer()
        tunnel = await rp.open_tunnel(self.path, "127.0.0.1", peer.port)
        self.assertFalse(tunnel.peer_authenticated)
        self.assertEqual(tunnel.authentication_mode, "host_proof_and_session_encryption")
        await tunnel.aclose()

    async def test_invalid_peer_signature_fails_before_host_proof(self):
        self.record()
        peer = await self.peer(bad_signature=True)
        with self.assertRaisesRegex(rp.PairingError, "peer_verification_failed"):
            await rp.open_tunnel(self.path, "127.0.0.1", peer.port)
        self.assertFalse(peer.host_proof_received)

    async def test_wrong_trusted_peer_identity_fails(self):
        self.record()
        peer = await self.peer(wrong_identifier=True)
        with self.assertRaisesRegex(rp.PairingError, "peer_identity_mismatch"):
            await rp.open_tunnel(self.path, "127.0.0.1", peer.port)
        self.assertFalse(peer.host_proof_received)

    async def test_corrupt_aead_tag_fails_even_with_legacy_record(self):
        self.record(trusted=False)
        peer = await self.peer(corrupt_encryption=True)
        with self.assertRaisesRegex(rp.PairingError, "peer_verification_failed"):
            await rp.open_tunnel(self.path, "127.0.0.1", peer.port)

    async def test_peer_rejection_does_not_leak_peer_payload(self):
        self.record()
        peer = await self.peer(reject=True)
        with self.assertRaises(rp.PairingError) as caught:
            await rp.open_tunnel(self.path, "127.0.0.1", peer.port)
        self.assertEqual(str(caught.exception), "pair_verify: pairing_rejected")
        self.assertNotIn("DO-NOT-LOG", str(caught.exception))

    async def test_wrong_tls_psk_fails_and_closes_control(self):
        self.record()
        peer = await self.peer(wrong_psk=True)
        loop = asyncio.get_running_loop()
        previous = loop.get_exception_handler()
        # The peer's deliberate TLS MAC failure is expected; suppress the test
        # server's transport-creation diagnostic, not a production client log.
        loop.set_exception_handler(lambda current_loop, context: None)
        try:
            with self.assertRaisesRegex(rp.PairingError, "tls: connection_failed"):
                await rp.open_tunnel(self.path, "127.0.0.1", peer.port)
            await asyncio.wait_for(peer.control_closed.wait(), 2)
        finally:
            loop.set_exception_handler(previous)

    async def test_cancelled_handshake_releases_control_socket(self):
        self.record()
        closed = asyncio.Event()
        async def silent_peer(reader, writer):
            await reader.read()
            closed.set()
            writer.close()
        server = await asyncio.start_server(silent_peer, "127.0.0.1", 0)
        task = asyncio.create_task(rp.open_tunnel(self.path, "127.0.0.1", server.sockets[0].getsockname()[1]))
        try:
            await asyncio.sleep(.03)
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
            await asyncio.wait_for(closed.wait(), 2)
        finally:
            server.close()
            await server.wait_closed()

    async def test_no_public_network_or_dns_endpoint(self):
        self.record()
        for host in ("example.com", "8.8.8.8", "10.7.0.2", "10.7.0.1.evil"):
            with self.assertRaisesRegex(rp.PairingError, "local_vpn_endpoint_required"):
                await rp.open_tunnel(self.path, host)

    async def test_peer_record_error_is_sanitized(self):
        self.path.write_bytes(b"PRIVATE-PAIRING-MATERIAL-BAD-PLIST")
        with self.assertRaises(rp.PairingError) as caught:
            await rp.open_tunnel(self.path)
        self.assertEqual(str(caught.exception), "record: unreadable_record")

    async def test_bad_magic_and_read_timeout_are_bounded(self):
        reader = asyncio.StreamReader()
        reader.feed_data(b"NOTMAGIC" + b"\0\x02{}")
        with self.assertRaisesRegex(rp.PairingError, "invalid_magic"):
            await rp._read_frame(reader, b"CDTunnel", "cdtunnel")
        reader = asyncio.StreamReader()
        with mock.patch.object(rp, "IO_TIMEOUT", .02):
            with self.assertRaises(TimeoutError):
                await rp._read_frame(reader, b"CDTunnel", "cdtunnel")


class BoundsTests(unittest.TestCase):
    def test_tlv_fragmentation_and_malformed_bounds(self):
        payload = b"x" * 600
        self.assertEqual(rp._tlv_decode(rp._tlv_encode(((5, payload),)))[5], payload)
        for data in (b"\x01", b"\x01\x03x", b"\x01\x01a\x02\x01b\x01\x01c"):
            with self.assertRaises(rp.PairingError):
                rp._tlv_decode(data)

    def test_json_duplicates_and_bad_base64_rejected(self):
        for data in (b'{"x":1,"x":2}', b'{"x":NaN}', b'[]'):
            with self.assertRaises(rp.PairingError):
                rp._json_parse(data, "control")
        with self.assertRaises(rp.PairingError):
            rp._unb64("not base64!", "control")


if __name__ == "__main__":
    unittest.main()
