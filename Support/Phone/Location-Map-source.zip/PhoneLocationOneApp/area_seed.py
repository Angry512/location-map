"""Read a launch-time location supplied by the owner's local Shortcut."""
import json
import os
from pathlib import Path
import plistlib
import threading
from urllib.parse import parse_qs, urlparse

from core import coordinate


def shortcut_seed_paths(root):
    """Resolve the app group's current path rather than storing a Files bookmark."""
    paths = [Path(root) / 'inbox/location-seed.txt']
    try:
        import ctypes as C
        from audio_keepalive import ObjC
        bridge = ObjC()
        pool = bridge.send(bridge.cls('NSAutoreleasePool'), 'new')
        try:
            bundle = bridge.send(bridge.cls('NSBundle'), 'mainBundle')
            group = bridge.send(bundle, 'objectForInfoDictionaryKey:', args=(C.c_void_p,),
                                values=(bridge.string('AppGroupIdentifier'),))
            group = group or bridge.string('group.AsheKube.a-Shell')
            manager = bridge.send(bridge.cls('NSFileManager'), 'defaultManager')
            url = bridge.send(manager, 'containerURLForSecurityApplicationGroupIdentifier:',
                              args=(C.c_void_p,), values=(group,))
            path = bridge.text(bridge.send(url, 'path')) if url else None
            if path and Path(path).is_absolute():
                paths.append(Path(path) / 'location-map-seed.txt')
        finally:
            bridge.send(pool, 'drain', result=None)
    except (OSError, RuntimeError):
        pass  # Older hosts can still receive the original inbox file.
    return tuple(paths)


def newest_seed(sources):
    result = None
    for path in sources:
        try:
            stat = path.stat()
        except OSError:
            continue
        if result is None or stat.st_mtime_ns >= result[1]:
            result = (path, stat.st_mtime_ns, stat.st_size)
    return result


def decode_seed(data):
    if len(data) > 16384:
        return None
    value = None
    for decoder in (plistlib.loads, json.loads):
        try:
            value = decoder(data)
            break
        except (ValueError, TypeError, plistlib.InvalidFileException):
            pass
    if isinstance(value, dict):
        if 'lat' in value and 'lon' in value:
            try:
                lat, lon = coordinate(value['lat'], value['lon'])
                return {'lat': lat, 'lon': lon}
            except ValueError:
                return None
        value = value.get('URL')
    if value is None:
        try:
            value = data.decode('utf-8').strip()
        except UnicodeError:
            return None
    if not isinstance(value, str):
        return None
    parsed = urlparse(value)
    if parsed.hostname not in ('maps.apple.com', 'maps.apple'):
        return None
    params = parse_qs(parsed.query)
    for key in ('ll', 'sll', 'center', 'coordinate'):
        for raw in params.get(key, []):
            try:
                parts = raw.split(',')
                if len(parts) != 2:
                    continue
                lat, lon = coordinate(*map(float, parts))
                return {'lat': lat, 'lon': lon}
            except ValueError:
                continue
    return None


def read_seed(path):
    try:
        if Path(path).stat().st_size > 16384:
            return None
        return decode_seed(Path(path).read_bytes())
    except OSError:
        return None


class AreaSeedWatcher:
    def __init__(self, source, cache, controller, apply):
        self.sources = tuple(map(Path, source)) if isinstance(source, (tuple, list)) else (Path(source),)
        self.cache = Path(cache)
        self.controller, self.apply = controller, apply
        self._seen = None
        self._stop = threading.Event()
        self.thread = None

    def tick(self):
        try:
            fingerprint = newest_seed(self.sources)
            if fingerprint is None or fingerprint == self._seen:
                return
            state = self.controller.snapshot()
            # Consume seeds collected during simulation, so a later Stop does
            # not reclassify a simulated position as the real starting area.
            if state['state'] != 'idle' or state.get('requires_stop'):
                self._seen = fingerprint
                return
            area = read_seed(fingerprint[0])
            if area is None:
                return  # A partial overwrite can finish before the next tick.
            self.cache.parent.mkdir(parents=True, exist_ok=True)
            temp = self.cache.with_suffix('.new')
            fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as output:
                json.dump({'area': area}, output)
            os.replace(temp, self.cache)
            self._seen = fingerprint
            self.apply(area)
        except (OSError, ValueError, KeyError):
            return

    def start(self):
        def run():
            while not self._stop.is_set():
                self.tick()
                self._stop.wait(.75)
        self.thread = threading.Thread(target=run, name='location-starting-area', daemon=True)
        self.thread.start()
        return self

    def close(self):
        self._stop.set()
        if self.thread:
            self.thread.join(1)
