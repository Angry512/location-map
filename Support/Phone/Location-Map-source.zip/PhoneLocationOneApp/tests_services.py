"""Wire-only tests: no host/device connection and no phone location changes."""
import asyncio
import os
import struct
import sys
import unittest
from contextlib import asynccontextmanager, suppress
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "vendor"))

from bpylist2 import archiver
import services


class Writer:
    def __init__(self, reader):
        self.reader = reader
        self.data = bytearray()
        self.closed = False

    def write(self, data):
        if self.closed:
            raise OSError("closed")
        self.data.extend(data)

    async def drain(self):
        await asyncio.sleep(0)

    def close(self):
        self.closed = True
        self.reader.feed_eof()

    async def wait_closed(self):
        return


def pipe(data):
    reader = asyncio.StreamReader()
    reader.feed_data(data)
    return reader, Writer(reader)


def dtx_reply(identifier, channel, kind=0, payload=b"", conversation=1,
              aux=b"", flags=0):
    # Independent wire fixture: the 32-byte DTX header plus 16-byte payload header.
    body = struct.pack("<BBBBIII", kind, 0, 0, 0, len(aux), len(aux) + len(payload), 0) + aux + payload
    return struct.pack("<IIHHIIIiI", 0x1F3D5B79, 32, 0, 1, len(body),
                       identifier, conversation, channel, flags) + body


def capability_hello():
    return dtx_reply(1, 0, kind=2, conversation=0,
                     payload=archiver.archive("_notifyOfPublishedCapabilities:"))


def frames(data):
    result = []
    while data:
        size = int.from_bytes(data[:3], "big")
        result.append((data[3], data[4], int.from_bytes(data[5:9], "big"), data[9:9 + size]))
        data = data[9 + size:]
    return result


def calls(data):
    result = []
    while data:
        header = struct.unpack("<IIHHIIIiI", data[:32])
        size = header[4]
        body = data[32:32 + size]
        kind, _, _, _, aux_size, total, _ = struct.unpack("<BBBBIII", body[:16])
        assert total == len(body) - 16
        args = []
        aux = body[16:16 + aux_size]
        if aux:
            magic, reserved, length = struct.unpack("<IIQ", aux[:16])
            assert magic == 0x1F0 and reserved == 0 and length == len(aux) - 16
            aux = aux[16:]
            while aux:
                marker, tag = struct.unpack("<II", aux[:8])
                assert marker == 10
                aux = aux[8:]
                value = struct.unpack("<I", aux[:4])[0]
                aux = aux[4:]
                if tag == 2:
                    args.append(archiver.unarchive(aux[:value]))
                    aux = aux[value:]
                else:
                    assert tag == 3
                    args.append(value)
        payload = body[16 + aux_size:]
        result.append((header, kind, archiver.unarchive(payload) if payload else None, args))
        data = data[32 + size:]
    return result


class MockServices:
    """Reusable local mock for transport integration tests.

    ``handle_rsd(reader, writer)`` and ``handle_dvt(reader, writer)`` can also be
    attached to a packet-level mock peer, without opening these loopback servers.
    ``events`` records acknowledged Set/Clear selectors and their decoded args.
    This fixture never connects to a phone and implements no device pairing.
    """
    def __init__(self):
        self.rsd_port = None
        self.dvt_port = 62078
        self.events = []
        self.servers = []
        self.writers = set()
        self.tasks = set()

    async def _guard(self, handler, reader, writer):
        task = asyncio.current_task()
        self.tasks.add(task)
        self.writers.add(writer)
        try:
            await handler(reader, writer)
        except (asyncio.IncompleteReadError, ConnectionError):
            pass
        finally:
            self.tasks.discard(task)
            self.writers.discard(writer)
            writer.close()
            with suppress(Exception):
                await writer.wait_closed()

    async def start(self):
        dvt = await asyncio.start_server(
            lambda r, w: self._guard(self.handle_dvt, r, w), "127.0.0.1", 0)
        self.servers.append(dvt)
        self.dvt_port = dvt.sockets[0].getsockname()[1]
        rsd = await asyncio.start_server(
            lambda r, w: self._guard(self.handle_rsd, r, w), "127.0.0.1", 0)
        self.servers.append(rsd)
        self.rsd_port = rsd.sockets[0].getsockname()[1]
        return self

    async def dial(self, host, port):
        if host != "fd00::1" or port not in (self.rsd_port, self.dvt_port):
            raise ValueError("This fixture accepts only its two local test endpoints.")
        return await asyncio.open_connection("127.0.0.1", port)

    async def handle_rsd(self, reader, writer):
        if await reader.readexactly(24) != services.HTTP2_PREFACE:
            raise AssertionError("Invalid mock RSD preface")
        writer.write(services._h2_frame(4, 0))
        await writer.drain()
        buffered = bytearray()
        while True:
            header = await reader.readexactly(9)
            size = int.from_bytes(header[:3], "big")
            if size > services.MAX_FRAME:
                raise AssertionError("Oversized mock RSD frame")
            kind, flags = header[3:5]
            stream = int.from_bytes(header[5:9], "big")
            payload = await reader.readexactly(size)
            if kind == 4 and not flags & 1:
                writer.write(services._h2_frame(4, 0, flags=1))
                await writer.drain()
            if kind != 0 or stream != 1:
                continue
            buffered.extend(payload)
            while len(buffered) >= 24:
                magic, _, length, _ = struct.unpack("<IIQQ", buffered[:24])
                if magic != 0x29B00B92 or length > services.MAX_XPC:
                    raise AssertionError("Invalid mock RSD message")
                if len(buffered) < 24 + length:
                    break
                body = bytes(buffered[24:24 + length])
                del buffered[:24 + length]
                if not body:
                    continue
                decoder = services._XpcReader(body)
                self.assert_payload_magic(decoder.take(8))
                request = decoder.object()
                if request.get("MessageType") == "Handshake":
                    peer = self.discovery_info()
                    writer.write(services._h2_frame(0, 1, services._xpc_wrapper(peer, flags=0x101)))
                    await writer.drain()

    def discovery_info(self):
        return {"Services": {services.DVT_SERVICE: {
            "Port": str(self.dvt_port), "Properties": {"UsesRemoteXPC": False}}},
            "Properties": {}, "MessagingProtocolVersion": 7,
            "UUID": "00000000-0000-0000-0000-000000000000"}

    @staticmethod
    def assert_payload_magic(data):
        if data != struct.pack("<II", 0x42133742, 5):
            raise AssertionError("Invalid mock RSD payload magic")

    async def handle_dvt(self, reader, writer):
        while True:
            header = await reader.readexactly(32)
            size = struct.unpack("<IIHHIIIiI", header)[4]
            if not 16 <= size <= services.MAX_DTX:
                raise AssertionError("Invalid mock DTX message size")
            outgoing = calls(header + await reader.readexactly(size))[0]
            fields, _, selector, args = outgoing
            if selector == "_notifyOfPublishedCapabilities:":
                writer.write(capability_hello())
            elif selector == "_requestChannelWithCode:identifier:":
                if args != [1, services.LOCATION_SERVICE]:
                    raise AssertionError("Incorrect location channel request")
                writer.write(dtx_reply(fields[5], 0))
            elif selector in (services.SET_SELECTOR, services.CLEAR_SELECTOR):
                self.events.append((selector, args))
                writer.write(dtx_reply(fields[5], 1))
            else:
                raise AssertionError("Unexpected mock developer-service selector")
            await writer.drain()

    async def aclose(self):
        for server in self.servers:
            server.close()
            await server.wait_closed()
        for writer in list(self.writers):
            writer.close()
        for task in list(self.tasks):
            task.cancel()
        if self.tasks:
            await asyncio.gather(*list(self.tasks), return_exceptions=True)


@asynccontextmanager
async def mock_services():
    """Yield a started MockServices endpoint pair; close both on exit."""
    peer = await MockServices().start()
    try:
        yield peer
    finally:
        await peer.aclose()


class WireTests(unittest.IsolatedAsyncioTestCase):
    def fixture(self, dtx_data=None, entry=None, split_rsd=False):
        entry = {"Port": "62078", "Properties": {"UsesRemoteXPC": False}} if entry is None else entry
        peer = {"Services": {services.DVT_SERVICE: entry} if entry else {},
                "Properties": {"OSVersion": "test-only"}, "MessagingProtocolVersion": 7,
                "UUID": "00000000-0000-0000-0000-000000000000"}
        response = services._xpc_wrapper(flags=1) + services._xpc_wrapper(peer, flags=0x101)
        if split_rsd:
            peer_frames = (services._h2_frame(0, 1, response[:17])
                           + services._h2_frame(0, 1, response[17:]))
        else:
            peer_frames = services._h2_frame(0, 1, response)
        rsd = pipe(services._h2_frame(4, 0) + peer_frames)
        if dtx_data is None:
            dtx_data = capability_hello() + dtx_reply(2, 0) + dtx_reply(3, 1) + dtx_reply(4, 1)
        dtx = pipe(dtx_data)
        dialed = []

        async def dial(host, port):
            dialed.append((host, port))
            return rsd if port == 58783 else dtx

        return dial, dialed, rsd, dtx

    async def test_rsd_handshake_and_acknowledged_location_selectors(self):
        dial, dialed, rsd, dtx = self.fixture(split_rsd=True)
        client = await services.connect_location(dial, "fd00::1", 58783)
        try:
            await client.set(38.9, -77.0)
            await client.clear()
            self.assertEqual(dialed, [("fd00::1", 58783), ("fd00::1", 62078)])
            wire = bytes(rsd[1].data)
            self.assertTrue(wire.startswith(services.HTTP2_PREFACE))
            opening = frames(wire[len(services.HTTP2_PREFACE):])
            self.assertEqual([(f[0], f[2]) for f in opening[:7]],
                             [(4, 0), (8, 0), (1, 1), (0, 1), (1, 3), (0, 1), (0, 3)])
            self.assertEqual(struct.unpack("<IIQQ", opening[5][3]), (0x29B00B92, 0x201, 0, 0))
            self.assertEqual(struct.unpack("<IIQQ", opening[6][3]), (0x29B00B92, 0x400001, 0, 0))
            outgoing = calls(bytes(dtx[1].data))
            self.assertEqual([call[2] for call in outgoing], [
                "_notifyOfPublishedCapabilities:", "_requestChannelWithCode:identifier:",
                "simulateLocationWithLatitude:longitude:", "stopLocationSimulation"])
            self.assertEqual(outgoing[1][3], [1, services.LOCATION_SERVICE])
            self.assertEqual(outgoing[2][3], [38.9, -77.0])
            self.assertEqual(outgoing[2][0][7:], (1, 1))
            self.assertEqual(outgoing[3][0][7:], (1, 1))
        finally:
            await client.aclose()
        self.assertTrue(rsd[1].closed and dtx[1].closed)

    async def test_reusable_mock_servers_exercise_real_async_streams(self):
        async with mock_services() as peer:
            client = await services.connect_location(peer.dial, "fd00::1", peer.rsd_port)
            try:
                await client.set(38.9, -77.0)
                await client.clear()
                self.assertEqual(peer.events, [
                    (services.SET_SELECTOR, [38.9, -77.0]), (services.CLEAR_SELECTOR, [])])
            finally:
                await client.aclose()

    async def test_negative_ack_is_not_success_and_does_not_expose_payload(self):
        data = capability_hello() + dtx_reply(2, 0) + dtx_reply(
            3, 1, kind=4, payload=b"PRIVATE_DEVICE_ERROR_CONTENT")
        dial, _, rsd, dtx = self.fixture(data)
        client = await services.connect_location(dial, "fd00::1", 58783)
        with self.assertRaises(services.CommandRejected) as caught:
            await client.set(1, 2)
        self.assertNotIn("PRIVATE_DEVICE", str(caught.exception))
        self.assertTrue(client.closed and rsd[1].closed and dtx[1].closed)

    async def test_wrong_channel_or_conversation_cannot_acknowledge_set(self):
        for channel, conversation in [(2, 1), (1, 0), (1, 2)]:
            with self.subTest(channel=channel, conversation=conversation):
                data = capability_hello() + dtx_reply(2, 0) + dtx_reply(3, channel, conversation=conversation)
                dial, _, _, _ = self.fixture(data)
                client = await services.connect_location(dial, "fd00::1", 58783)
                with self.assertRaises(services.ProtocolError):
                    await client.set(1, 2)

    async def test_missing_stop_ack_is_explicitly_unconfirmed(self):
        dial, _, _, _ = self.fixture(capability_hello() + dtx_reply(2, 0))
        client = await services.connect_location(dial, "fd00::1", 58783)
        with mock.patch.object(services, "IO_TIMEOUT", 0.01):
            with self.assertRaisesRegex(services.ServiceTimeout, "unconfirmed"):
                await client.clear()
        self.assertTrue(client.closed)

    async def test_absent_developer_image_service_has_no_install_side_effect(self):
        dial, dialed, rsd, dtx = self.fixture(entry={})
        with self.assertRaisesRegex(services.DeveloperServiceUnavailable, "does not install developer images"):
            await services.connect_location(dial, "fd00::1", 58783)
        self.assertEqual(dialed, [("fd00::1", 58783)])
        self.assertTrue(rsd[1].closed)
        self.assertEqual(bytes(dtx[1].data), b"")

    async def test_fragmented_dtx_ack_is_reassembled_and_correlated(self):
        body = struct.pack("<BBBBIII", 0, 0, 0, 0, 0, 0, 0)
        parts = []
        for index, piece in enumerate([b"", body[:7], body[7:]]):
            length = len(body) if index == 0 else len(piece)
            parts.append(struct.pack("<IIHHIIIiI", 0x1F3D5B79, 32, index, 3,
                                     length, 3, 1, 1, 0) + piece)
        dial, _, _, _ = self.fixture(capability_hello() + dtx_reply(2, 0) + b"".join(parts))
        client = await services.connect_location(dial, "fd00::1", 58783)
        await client.set(1, 2)
        await client.aclose()

    async def test_invalid_coordinates_never_reach_the_transport(self):
        dial, _, _, dtx = self.fixture()
        client = await services.connect_location(dial, "fd00::1", 58783)
        before = bytes(dtx[1].data)
        for lat, lon in [(91, 0), (0, 181), (float("nan"), 0), (0, float("inf")), (True, 0), ("1", 2)]:
            with self.assertRaises(ValueError):
                await client.set(lat, lon)
        self.assertEqual(bytes(dtx[1].data), before)
        await client.aclose()

    async def test_concurrent_calls_remain_serialized(self):
        dial, _, _, dtx = self.fixture()
        client = await services.connect_location(dial, "fd00::1", 58783)
        await asyncio.gather(client.set(1, 2), client.clear())
        self.assertEqual([call[0][5] for call in calls(bytes(dtx[1].data))], [1, 2, 3, 4])
        await client.aclose()

    async def test_oversized_dtx_frame_is_rejected_before_reading_a_body(self):
        header = struct.pack("<IIHHIIIiI", 0x1F3D5B79, 32, 0, 1,
                             services.MAX_DTX + 1, 3, 1, 1, 0)
        dial, _, _, _ = self.fixture(capability_hello() + dtx_reply(2, 0) + header)
        client = await services.connect_location(dial, "fd00::1", 58783)
        with self.assertRaises(services.ProtocolError):
            await client.set(1, 2)


if __name__ == "__main__":
    unittest.main()
