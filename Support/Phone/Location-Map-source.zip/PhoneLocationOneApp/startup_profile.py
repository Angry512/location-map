"""Portable a-Shell startup stanza, including migration of the old absolute path."""
from __future__ import annotations

import re
import shlex

BEGIN = '# >>> Location Map startup >>>'
END = '# <<< Location Map startup <<<'
LEGACY = '# Location Map native startup'

# Keep the resolver in the profile so it needs no file at the previous
# container path. Python's home follows the running a-Shell sandbox.
BOOT = (
    'from pathlib import Path; import runpy,sys; '
    'home=Path.home(); docs=home if home.name=="Documents" else home/"Documents"; '
    'entry=docs/"PhoneLocationOneApp"/"phone_location.py"; sys.path.insert(0,str(entry.parent)); '
    'runpy.run_path(str(entry),run_name="__main__") if entry.is_file() else '
    'print("Location Map files are missing. Run Location Map Repair on your computer.")'
)
STANZA = f'{BEGIN}\nclear\npython3 -c {shlex.quote(BOOT)}\n{END}\n'


def merge_profile(existing: str) -> str:
    """Replace only our exact old or new stanza and preserve other startup commands."""
    managed = re.compile(r'^' + re.escape(BEGIN) + r'\r?\n.*?^' + re.escape(END)
                         + r'(?:\r?\n|$)', re.M | re.S)
    existing = managed.sub('', existing)
    if any(line in (BEGIN, END) for line in existing.splitlines()):
        raise ValueError('Incomplete Location Map startup block')

    legacy = re.compile(r'^' + re.escape(LEGACY) + r'\r?\n(?:clear\r?\n)?'
                        r'(?P<command>python3 [^\r\n]+)(?:\r?\n|$)', re.M)

    def remove_legacy(match):
        parts = shlex.split(match['command'])
        if len(parts) != 2 or not parts[1].endswith('/Documents/PhoneLocationOneApp/phone_location.py'):
            raise ValueError('Unrecognized previous Location Map startup command')
        return ''

    existing = legacy.sub(remove_legacy, existing)
    if LEGACY in existing.splitlines():
        raise ValueError('Incomplete previous Location Map startup block')
    separator = '\n' if existing and not existing.endswith('\n') else ''
    return existing + separator + STANZA
