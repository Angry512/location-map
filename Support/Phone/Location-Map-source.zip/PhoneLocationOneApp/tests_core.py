import asyncio
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest
from unittest import mock

import core
from core import Controller, coordinate


def wait_for(predicate, seconds=3):
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        if predicate():
            return
        time.sleep(.01)
    raise AssertionError('Expected controller state did not arrive')


class Session:
    def __init__(self, *, fail=False):
        self.sets = []
        self.clears = 0
        self.closes = 0
        self.fail = fail

    async def set(self, lat, lon):
        self.sets.append((lat, lon))
        if self.fail:
            raise ConnectionError('fixture secret should never reach UI')

    async def clear(self):
        self.clears += 1

    async def aclose(self):
        self.closes += 1


class Audio:
    def __init__(self):
        self.playing = False

    def start(self):
        self.playing = True

    def stop(self):
        self.playing = False

    def status(self):
        return {'playing': self.playing}


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.journal = Path(self.temp.name) / 'state.json'
        self.controllers = []

    def tearDown(self):
        for controller in self.controllers:
            controller.close()
        self.temp.cleanup()

    def controller(self, session, *, factory=None, audio=Audio):
        async def connect(_):
            return session
        value = Controller(Path(self.temp.name) / 'unused-pairing.plist', self.journal,
                           session_factory=factory or connect, audio_factory=audio).start()
        self.controllers.append(value)
        return value

    def test_coordinate_validation_does_not_accept_bool_nan_or_strings(self):
        self.assertEqual(coordinate(-90, 180), (-90, 180))
        for value in ((True, 0), ('1', 0), (91, 0), (0, float('nan'))):
            with self.assertRaises(ValueError):
                coordinate(*value)

    def test_set_stop_and_private_journal_are_real_ack_driven(self):
        session = Session()
        c = self.controller(session)
        self.assertEqual(c.snapshot()['state'], 'idle')
        self.assertEqual(session.sets, [])
        c.set(37.5, -122.3)
        wait_for(lambda: c.snapshot()['state'] == 'active')
        snapshot = c.snapshot()
        self.assertTrue(snapshot['fresh'])
        self.assertEqual(snapshot['confirmation_source'], 'developer_service_ack')
        self.assertNotIn('position_age_ms', snapshot)
        self.assertEqual(session.sets, [(37.5, -122.3)])
        self.assertTrue(json.loads(self.journal.read_text())['requires_stop'])
        c.stop()
        wait_for(lambda: c.snapshot()['state'] == 'idle')
        self.assertGreaterEqual(session.clears, 1)
        self.assertFalse(json.loads(self.journal.read_text())['requires_stop'])
        self.assertFalse(c.snapshot()['fresh'])

    def test_restart_never_replays_saved_location_and_stop_reconnects(self):
        self.journal.write_text(json.dumps({'point': [40, -74], 'requires_stop': True}))
        session = Session()
        c = self.controller(session)
        self.assertEqual(c.snapshot()['state'], 'error')
        self.assertEqual(session.sets, [])
        self.assertTrue(c.snapshot()['requires_stop'])
        c.stop()
        wait_for(lambda: c.snapshot()['state'] == 'idle')
        self.assertEqual(session.sets, [])
        self.assertEqual(session.clears, 1)

    def test_stop_supersedes_set_waiting_for_connection(self):
        gate, entered = threading.Event(), threading.Event()
        session = Session()
        async def factory(_):
            entered.set()
            while not gate.is_set():
                await asyncio.sleep(.01)
            return session
        c = self.controller(session, factory=factory)
        c.set(1, 2)
        self.assertTrue(entered.wait(1))
        c.stop()
        gate.set()
        wait_for(lambda: c.snapshot()['state'] == 'idle')
        self.assertEqual(session.sets, [])
        self.assertEqual(session.clears, 1)

    def test_transport_failure_is_redacted_and_not_automatically_retried(self):
        session = Session(fail=True)
        c = self.controller(session)
        c.set(3, 4)
        wait_for(lambda: c.snapshot()['state'] == 'error')
        self.assertEqual(len(session.sets), 1)
        self.assertGreaterEqual(session.clears, 1)
        self.assertNotIn('fixture secret', c.snapshot()['message'])
        self.assertFalse(c.snapshot()['fresh'])

    def test_expired_sleep_confirmation_clears_without_replaying_old_point(self):
        session = Session()
        c = self.controller(session)
        c.set(5, 6)
        wait_for(lambda: c.snapshot()['state'] == 'active')
        with c._lock:
            c._ack_wall = time.time() - 30
        self.assertFalse(c.snapshot()['fresh'])
        c._wake()
        wait_for(lambda: session.closes > 0)
        self.assertEqual(len(session.sets), 1)
        self.assertGreaterEqual(session.clears, 1)
        self.assertEqual(c.snapshot()['state'], 'error')

    def test_unavailable_background_audio_clears_instead_of_false_success(self):
        class Unavailable(Audio):
            def start(self):
                raise RuntimeError('No audio session')
        session = Session()
        c = self.controller(session, audio=Unavailable)
        c.set(7, 8)
        wait_for(lambda: c.snapshot()['state'] == 'error')
        self.assertGreaterEqual(session.clears, 1)
        self.assertFalse(c.snapshot()['fresh'])

    def test_close_cancels_a_pending_connection_before_it_can_apply(self):
        entered = threading.Event()
        session = Session()
        async def factory(_):
            entered.set()
            await asyncio.sleep(60)
            return session
        c = self.controller(session, factory=factory)
        c.set(9, 10)
        self.assertTrue(entered.wait(1))
        c.close()
        self.assertFalse(c._thread.is_alive())
        self.assertEqual(session.sets, [])

    def test_audio_start_cannot_refresh_an_old_service_ack(self):
        entered, release = threading.Event(), threading.Event()
        instances = []
        class SlowAudio(Audio):
            def __init__(self):
                super().__init__()
                instances.append(self)
            def start(self):
                entered.set()
                release.wait(2)
                super().start()
        session = Session()
        with mock.patch.object(core, 'LEASE', .1):
            c = self.controller(session, audio=SlowAudio)
            c.set(11, 12)
            self.assertTrue(entered.wait(1))
            time.sleep(.15)  # ACK expires while native startup is delayed.
            release.set()
            wait_for(lambda: c.snapshot()['state'] != 'connecting')
            self.assertEqual(c.snapshot()['state'], 'error')
            self.assertFalse(c.snapshot()['fresh'])
            wait_for(lambda: session.closes > 0)
            self.assertFalse(instances[0].playing)
            self.assertGreaterEqual(session.clears, 1)

    def test_clean_close_persists_confirmed_clear_for_restart(self):
        session = Session()
        c = self.controller(session)
        c.set(13, 14)
        wait_for(lambda: c.snapshot()['state'] == 'active')
        c.close()
        self.assertFalse(c._thread.is_alive())
        self.assertGreaterEqual(session.clears, 1)
        self.assertFalse(json.loads(self.journal.read_text())['requires_stop'])
        restarted = self.controller(Session())
        self.assertEqual(restarted.snapshot()['state'], 'idle')
        self.assertFalse(restarted.snapshot()['requires_stop'])

    def test_failed_shutdown_clear_keeps_restart_recovery_required(self):
        class CannotClear(Session):
            async def clear(self):
                self.clears += 1
                raise ConnectionError('fixture failure')
        session = CannotClear()
        c = self.controller(session)
        c.set(15, 16)
        wait_for(lambda: c.snapshot()['state'] == 'active')
        c.close()
        self.assertFalse(c._thread.is_alive())
        self.assertTrue(json.loads(self.journal.read_text())['requires_stop'])
        restarted = self.controller(Session())
        self.assertEqual(restarted.snapshot()['state'], 'error')
        self.assertTrue(restarted.snapshot()['requires_stop'])

    def test_connection_returning_after_sleep_does_not_apply_queued_point(self):
        entered, release, expired = threading.Event(), threading.Event(), threading.Event()
        original_elapsed = core.elapsed
        session = Session()
        async def factory(_):
            entered.set()
            while not release.is_set():
                await asyncio.sleep(.005)
            return session
        def elapsed(mono, wall):
            return core.MAX_PENDING_AGE + 1 if expired.is_set() else original_elapsed(mono, wall)
        with mock.patch.object(core, 'elapsed', side_effect=elapsed):
            c = self.controller(session, factory=factory)
            c.set(17, 18)
            self.assertTrue(entered.wait(1))
            expired.set()
            release.set()
            wait_for(lambda: c.snapshot()['state'] == 'error')
            wait_for(lambda: session.closes > 0)
            self.assertEqual(session.sets, [])
            self.assertFalse(c.snapshot()['fresh'])
            self.assertIn('expired', c.snapshot()['message'])

    def test_legitimate_120_second_preparation_age_is_still_eligible(self):
        entered, release, prepared = threading.Event(), threading.Event(), threading.Event()
        original_elapsed = core.elapsed
        queued_stamp = []
        session = Session()
        async def factory(_):
            entered.set()
            while not release.is_set():
                await asyncio.sleep(.005)
            return session
        def elapsed(mono, wall):
            stamp = (mono, wall)
            if not queued_stamp:
                queued_stamp.append(stamp)
            if prepared.is_set() and stamp == queued_stamp[0]:
                return 120.0
            return original_elapsed(mono, wall)
        with mock.patch.object(core, 'elapsed', side_effect=elapsed):
            c = self.controller(session, factory=factory)
            c.set(21, 22)
            self.assertTrue(entered.wait(1))
            prepared.set()
            release.set()
            wait_for(lambda: c.snapshot()['state'] == 'active')
            self.assertEqual(session.sets, [(21, 22)])
            self.assertTrue(c.snapshot()['fresh'])

    def test_stop_during_periodic_resend_cannot_publish_old_active_state(self):
        entered, release = threading.Event(), threading.Event()
        class ResendSession(Session):
            async def set(self, lat, lon):
                self.sets.append((lat, lon))
                if len(self.sets) > 1:
                    entered.set()
                    while not release.is_set():
                        await asyncio.sleep(.005)
        session = ResendSession()
        with mock.patch.object(core, 'RESEND', .01):
            c = self.controller(session)
            c.set(19, 20)
            wait_for(lambda: c.snapshot()['state'] == 'active')
            self.assertTrue(entered.wait(2))
            c.stop()
            self.assertFalse(c.snapshot()['fresh'])
            release.set()
            wait_for(lambda: c.snapshot()['state'] == 'idle')
            self.assertFalse(c.snapshot()['fresh'])
            self.assertFalse(c.snapshot()['requires_stop'])


if __name__ == '__main__':
    unittest.main()
