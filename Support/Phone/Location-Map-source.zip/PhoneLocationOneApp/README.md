# Location Map — installed and phone validated

The Home Screen's blue folded-map **Location Map** icon opens a real Apple
MapKit map in the free App Store a-Shell app. Select a point and tap **Simulate**;
reopen the same icon and tap **Stop**. The existing LocalDevVPN connects silently
in the background. The launch path does not open Safari, iSH, or a terminal page.

This installation uses the App Store host, so it has no seven-day personal-signing
renewal. No payment, subscription, paid developer account, or computer server is
involved. Keep a-Shell and LocalDevVPN installed, and preserve a-Shell's files.
Use the Location Map icon rather than the old StikDebug install.

## Repair verified on the owner's iPhone, 2026-11-05

The phone now runs iOS 27.2 and a-Shell 2.3.2. The old profile contained an
absolute path into a container that no longer existed. USB and trusted-network
inspection found the map and pairing intact in the current Documents folder.
The repaired profile resolves Documents from the running host's home path.

- The original Home Screen icon opened the repaired map on Wi-Fi and
  cold-launched it on 5G. The final cellular test confirmed the Wi-Fi switch
  was fully off in Settings.
- The Shortcut now transfers the launch location through a-Shell's Put File
  action and its shared app folder. The old Save File bookmark is gone from the
  launcher. The area cache advanced while the old inbox file stayed unchanged.
- On cellular, a fresh local developer connection was refused while data was
  on. It opened with data paused. The same tunnel accepted three Stop commands
  after 5G returned. The Shortcut now briefly toggles data twice with an eight
  second wait between toggles when no Wi-Fi network is joined. The engine opens
  the link during that window and keeps it for Simulate and Stop.
- Simulate and Stop passed on 5G after data returned, including consecutive runs
  without reopening. They passed again after Wi-Fi was restored. USB was used
  for control and observation. The location engine connected to the phone's own
  LocalDevVPN peer.
- All 80 computer tests pass. They include relocation of the startup path and
  reuse of a prepared connection across two complete Set and Stop cycles.

The USB package remains a draft. Shortcuts closed unexpectedly on two export
attempts, and installation on another phone has not been verified.

## Earlier device checks, 2026-11-02

Device: iPhone 15 Pro, iOS 27.0.1; full a-Shell 2.3.1 and LocalDevVPN 1.3.0.

- Native ctypes callback allocation/execution, TLS-PSK, bundled cryptography,
  UIKit/MapKit and declared background audio passed the installed-host probe.
- Cold native startup presents the map around a launch-time general area.
- A blue dot marks the precise location supplied by Shortcuts when the map is
  opened while idle. It stays distinct from the red simulation pin. The location
  arrow zooms to street level at that point; the dot is not continuous GPS tracking.
- The Home Screen icon connects a previously disconnected VPN and opens the map
  directly. Warm returns preserve the active screen. First-use location and file
  permissions were granted during setup.
- Tapping the map and Simulate produced fresh developer-service acknowledgments.
  An independent Shortcuts Current Location reading matched the selected point.
- A background session continued for more than two minutes and returned with
  fresh connection confirmation. This is a bounded observation, not a promise
  that iOS will keep an app running indefinitely.
- Force-terminating the host during simulation, then reopening through the icon,
  showed **Not confirmed**, not a false active claim. Stop reconnected and cleared
  the simulation. A fresh independent location reading then differed from the
  simulated point. The final session journal has `requires_stop: false`.
- The genuine starting-area cache stays separate from the simulated selection;
  a seed captured while simulating does not replace the genuine area.

The controller lives on the phone. USB was used for installation and observation,
not as its location-service transport or runtime server. After validation, the
unneeded StikDebug and iSH apps were uninstalled; SideStore was already absent.
a-Shell and LocalDevVPN remain installed in the App Library, with their icons
removed from the Home Screen. The Location Map launcher remains visible.

## State and recovery

**Connection confirmed** means a fresh correlated service acknowledgment, with a
short freshness deadline. Saved coordinates alone never prove an active session.
After a force-close or interruption, **Not confirmed** and **Stop** allow recovery.
The app does not automatically replay an old simulation after restart. Leave it
in the app switcher while using simulation; force-closing it can end a session.

Developer-image recovery is implemented with Cryptex assets delivered during USB setup, fresh HTTPS
Apple personalization, the live device nonce, flow-controlled uploads, and final
installed-image checks. Its wire tests pass, but a physical reboot/re-personalize
cycle was not performed in this installation session. Internet access may be
needed for map tiles and image personalization. Future iOS changes, loss of the
trusted pairing, app deletion, and system interruptions can require repair; this
does not claim months of elapsed testing or permanent future compatibility.

## Implementation and computer verification

The repaired source passes **80 tests** with Python 3.13.11 and cryptography 50.0.2.
The previous 75-test version also passed with Python 3.13 and cryptography 49.
The preceding 71-test suite also passed with legacy cryptography 3.4.8. Tests
include a generated-key encrypted peer, actual TLS-PSK, the real vendored TCP
stack against an independent IPv6/TCP peer, and the complete pairing → TLS → TCP
→ RSD → DTX → Controller Set/Stop pipeline. DDI tests use mock Apple responses;
native unit tests cover state/actions/lifecycle, supplemented by the phone checks.

```
python3 -B -m unittest discover -p 'tests_*.py' -q
python3 phone_location.py --check
```

`phone_location.py` owns startup and one-instance locking; `ui_native.py` provides
the native screen; `core.py` owns session state; `remote_pair.py`, `transport.py`,
`services.py` and `ddi.py` implement the connection and recovery. `area_seed.py`
reads the Shortcut handoff from the current a-Shell shared app folder and
accepts `inbox/location-seed.txt` from earlier launchers. The native
host has no Core Location purpose keys, so its code does not request that access.
`audio_keepalive.py` requests background execution during an active simulation.

See `LAUNCHER.md` for the current Shortcut actions. The original Home Screen
icon keeps its Shortcut identity. iOS may show a brief completion indicator.

The startup file lives at `Documents/.profile`. `startup_profile.py` resolves
the current Documents path at launch and migrates the old absolute command.
`install_startup.py` preserves the previous profile. Personal files live under
the phone-only `private/` directory and are excluded from this archive.

The source archive includes no pairing keys, personal location cache, session
journal, or personalized ticket. Pure Python dependencies and third-party
licenses are included; the App Store host supplies crypto, SSL and ctypes.
The combined source is GPL-3.0-or-later due to the PyTCP subset; individual
notices remain under `vendor/` and `UPSTREAM/`. See `SOURCES.md` for provenance.
