"""Real vendored PyTCP bridge against an independent stdlib IPv6/TCP peer.

No operating-system TUN, root, TLS, phone, or second PyTCP singleton. The peer
implements enough TCP to handshake, validate every outgoing TCP checksum, echo
ordered stream data, ACK retransmissions, and complete FIN. Raw IPv6 packets
travel over an ordinary localhost TCP stream just as they do inside CDTunnel.
"""

from __future__ import annotations

import asyncio
from contextlib import suppress
from dataclasses import dataclass, field
import ipaddress
from pathlib import Path
import struct
import sys
import unittest

sys.path.insert(0, str(Path(__file__).with_name("vendor")))
from transport import TunnelNetwork


CLIENT = "fd00::1"
DEVICE = "fd00::2"
SERVICE_PORT = 58783
SYN, ACK, FIN, RST, PSH = 2, 16, 1, 4, 8


def checksum(data):
    """RFC 1071 one's-complement checksum; independent of vendored network code."""
    if len(data) % 2:
        data += b"\0"
    total = sum(struct.unpack("!%dH" % (len(data) // 2), data))
    while total >> 16:
        total = (total & 65535) + (total >> 16)
    return (~total) & 65535


def pseudo(source, destination, length):
    return (ipaddress.IPv6Address(source).packed + ipaddress.IPv6Address(destination).packed
            + length.to_bytes(4, "big") + b"\0\0\0\x06")


def segment(source_port, destination_port, sequence, acknowledgement, flags, data=b"", *, syn=False, window_scale=None):
    options = b"\x02\x04\x04\xc4" if syn else b""  # MSS 1220.
    if syn and window_scale is not None:
        options += b"\x01\x03\x03" + bytes((window_scale,))
    header_size = 20 + len(options)
    tcp = struct.pack("!HHIIBBHHH", source_port, destination_port,
                      sequence & 0xffffffff, acknowledgement & 0xffffffff,
                      (header_size // 4) << 4, flags, 65535, 0, 0) + options + data
    value = checksum(pseudo(DEVICE, CLIENT, len(tcp)) + tcp)
    tcp = tcp[:16] + value.to_bytes(2, "big") + tcp[18:]
    return struct.pack("!IHBB16s16s", 6 << 28, len(tcp), 6, 64,
                       ipaddress.IPv6Address(DEVICE).packed,
                       ipaddress.IPv6Address(CLIENT).packed) + tcp


@dataclass
class Connection:
    source_port: int
    destination_port: int
    receive_next: int
    initial_send: int
    send_next: int
    received: bytearray = field(default_factory=bytearray)
    fin: bool = False


class ManualTCPPeer:
    """In-order echo peer, independent of the implementation under test."""

    def __init__(self, window_scale=None):
        self.window_scale = window_scale
        self.reader = self.writer = self.task = None
        self.connections = {}
        self.errors = []
        self.validated_tcp_packets = 0
        self.data_segments = 0
        self.maximum_payload = 0
        self.fin_count = 0
        self.closed = asyncio.Event()
        self.ready = asyncio.Event()

    async def accept(self, reader, writer):
        self.reader, self.writer = reader, writer
        self.task = asyncio.current_task()
        self.ready.set()
        try:
            while True:
                header = await reader.readexactly(40)
                assert header[0] >> 4 == 6, "Peer received non-IPv6 data"
                length = int.from_bytes(header[4:6], "big")
                assert 0 < length <= 65535 - 40, "Bad IPv6 length"
                body = await reader.readexactly(length)
                if header[6] != 6:
                    # Autoconfig's ICMPv6/ND traffic is irrelevant on this static
                    # point-to-point link. Only the application TCP is examined.
                    continue
                assert length + 40 <= 1500, "TCP packet exceeded negotiated tunnel MTU"
                source = str(ipaddress.IPv6Address(header[8:24]))
                destination = str(ipaddress.IPv6Address(header[24:40]))
                assert source == CLIENT and destination == DEVICE, "Unexpected TCP address"
                assert len(body) >= 20, "Short TCP header"
                assert checksum(pseudo(source, destination, len(body)) + body) == 0, "Invalid TCP checksum"
                self.validated_tcp_packets += 1
                sport, dport, seq, ack, offset, flags, window, _, _ = struct.unpack("!HHIIBBHHH", body[:20])
                header_size = (offset >> 4) * 4
                assert 20 <= header_size <= len(body), "Invalid TCP data offset"
                payload = body[header_size:]
                if payload:
                    self.data_segments += 1
                    self.maximum_payload = max(self.maximum_payload, len(payload))
                    assert len(payload) <= 1220, "Client ignored peer MSS"
                assert dport == SERVICE_PORT, "Unexpected service port"
                key = (sport, dport)
                connection = self.connections.get(key)
                if flags & SYN:
                    if connection is None:
                        initial = 100000 + len(self.connections) * 1000000
                        connection = Connection(sport, dport, (seq + 1) & 0xffffffff, initial, initial + 1)
                        self.connections[key] = connection
                    self.send(connection, SYN | ACK, sequence=connection.initial_send, syn=True)
                    await writer.drain()
                    continue
                assert connection is not None, "TCP data before SYN"
                if flags & RST:
                    continue
                if payload:
                    if seq == connection.receive_next:
                        connection.received.extend(payload)
                        connection.receive_next = (connection.receive_next + len(payload)) & 0xffffffff
                        self.send(connection, ACK | PSH, data=payload)
                        connection.send_next = (connection.send_next + len(payload)) & 0xffffffff
                    else:
                        # Duplicate/out-of-order packets must not duplicate the echo.
                        self.send(connection, ACK)
                if flags & FIN:
                    if not connection.fin and (seq + len(payload)) & 0xffffffff == connection.receive_next:
                        connection.receive_next = (connection.receive_next + 1) & 0xffffffff
                        connection.fin = True
                        self.fin_count += 1
                        self.send(connection, ACK | FIN)
                        connection.send_next = (connection.send_next + 1) & 0xffffffff
                    else:
                        self.send(connection, ACK)
                await writer.drain()
        except (asyncio.IncompleteReadError, ConnectionError, asyncio.CancelledError):
            pass
        except Exception as exc:
            self.errors.append(exc)
        finally:
            self.closed.set()
            writer.close()

    def send(self, connection, flags, data=b"", *, sequence=None, syn=False):
        self.writer.write(segment(connection.destination_port, connection.source_port,
                                  connection.send_next if sequence is None else sequence,
                                  connection.receive_next, flags, data, syn=syn,
                                  window_scale=self.window_scale))

    async def drop_outer_stream(self):
        if self.writer:
            self.writer.close()
            with suppress(Exception):
                await self.writer.wait_closed()


class FakeTunnel:
    client_address = CLIENT
    server_address = DEVICE
    rsd_port = SERVICE_PORT
    mtu = 1500

    def __init__(self, reader, writer):
        self.reader, self.writer = reader, writer
        self.was_closed = False

    async def aclose(self):
        self.was_closed = True
        self.writer.close()
        with suppress(Exception):
            await self.writer.wait_closed()


class TransportTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.resources = []

    async def asyncTearDown(self):
        for network, server, peer, raw in reversed(self.resources):
            await network.aclose()
            server.close()
            await server.wait_closed()
            await peer.drop_outer_stream()
            if peer.task:
                with suppress(Exception):
                    await asyncio.wait_for(peer.closed.wait(), 2)

    async def open_network(self, window_scale=None):
        peer = ManualTCPPeer(window_scale=window_scale)
        server = await asyncio.start_server(peer.accept, "127.0.0.1", 0)
        reader, writer = await asyncio.open_connection("127.0.0.1", server.sockets[0].getsockname()[1])
        raw = FakeTunnel(reader, writer)
        network = TunnelNetwork(raw)
        self.resources.append((network, server, peer, raw))
        await asyncio.wait_for(peer.ready.wait(), 2)
        await asyncio.wait_for(network.open(), 7)
        return network, peer, raw

    async def roundtrip(self, network, peer, payload):
        reader, writer = await asyncio.wait_for(network.dial(DEVICE, SERVICE_PORT), 3)
        writer.write(payload)
        await asyncio.wait_for(writer.drain(), 3)
        try:
            echoed = await asyncio.wait_for(reader.readexactly(len(payload)), 8)
        except TimeoutError:
            self.fail("Echo timeout; validated TCP packets=%s, peer errors=%r, outer closed=%s" %
                      (peer.validated_tcp_packets, peer.errors, network.closed.is_set()))
        self.assertEqual(echoed, payload)
        writer.close()
        await asyncio.wait_for(writer.wait_closed(), 2)
        for _ in range(100):
            if peer.fin_count:
                break
            await asyncio.sleep(.01)
        self.assertGreater(peer.fin_count, 0, "Real TCP FIN never reached the independent peer")
        self.assertGreater(peer.validated_tcp_packets, 2)
        self.assertFalse(peer.errors, repr(peer.errors))
        self.assertIn(payload, [bytes(connection.received) for connection in peer.connections.values()])

    async def test_real_stack_64k_echo_fin_and_reopen(self):
        # Explicit no-window-scale regression: the 16-bit receive-window field
        # must remain valid even with a peer that does not offer scaling.
        network, peer, raw = await self.open_network()
        payload = bytes(range(256)) * 256 + b"odd-length-tail"
        await self.roundtrip(network, peer, payload)
        self.assertGreaterEqual(peer.data_segments, 54, "Large stream was not segmented at the peer MSS")
        self.assertLessEqual(peer.maximum_payload, 1220)
        await network.aclose()
        self.assertTrue(network.closed.is_set())
        self.assertTrue(raw.was_closed)
        # Stop/init the actual process-global stack, not a second simultaneous stack.
        reopened, second_peer, second_raw = await self.open_network()
        await self.roundtrip(reopened, second_peer, b"second-open\0" * 701)
        await reopened.aclose()
        self.assertTrue(second_raw.was_closed)

    async def test_real_stack_peer_with_window_scale(self):
        network, peer, _ = await self.open_network(window_scale=7)
        await self.roundtrip(network, peer, b"scaled-peer\0" * 701)

    async def test_only_device_target_and_valid_port_are_allowed(self):
        network, peer, _ = await self.open_network()
        for host, port in (("fd00::3", SERVICE_PORT), ("127.0.0.1", SERVICE_PORT),
                           (DEVICE, 0), (DEVICE, 65536), (DEVICE, True), (DEVICE, "58783")):
            with self.assertRaises(ValueError):
                await network.dial(host, port)
        self.assertFalse(peer.connections)

    async def test_outer_transport_loss_marks_network_closed(self):
        network, peer, _ = await self.open_network()
        await self.roundtrip(network, peer, b"before-loss")
        await peer.drop_outer_stream()
        await asyncio.wait_for(network.closed.wait(), 2)
        with self.assertRaises(ConnectionError):
            await network.dial(DEVICE, SERVICE_PORT)


if __name__ == "__main__":
    unittest.main()
