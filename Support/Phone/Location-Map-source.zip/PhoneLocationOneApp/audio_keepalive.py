"""Experimental iOS background audio helper for a-Shell's embedded Python.

Uses public Foundation/AVFAudio APIs through the shipped ctypes module. No
microphone, location permission, files, third-party modules, or native plugin.
Call start() only after simulation starts; call stop() when it ends. This is a
host-capability experiment, not proof that iOS 27 preserves a developer session.
"""

from __future__ import annotations

import ctypes as C
import io
import sys
import threading
import wave


class ObjC:
    def __init__(self):
        if sys.platform not in ("darwin", "ios"):
            raise RuntimeError("This native helper requires a-Shell on iOS")
        self.libs = [C.CDLL("/System/Library/Frameworks/Foundation.framework/Foundation")]
        self.libs.append(C.CDLL("/System/Library/Frameworks/AVFoundation.framework/AVFoundation"))
        self.objc = C.CDLL("/usr/lib/libobjc.A.dylib")
        self.objc.objc_getClass.argtypes = [C.c_char_p]
        self.objc.objc_getClass.restype = C.c_void_p
        self.objc.sel_registerName.argtypes = [C.c_char_p]
        self.objc.sel_registerName.restype = C.c_void_p
        self.address = C.cast(self.objc.objc_msgSend, C.c_void_p).value
        self.functions = {}

    def cls(self, name):
        result = self.objc.objc_getClass(name.encode())
        if not result:
            raise RuntimeError("Missing Objective-C class: " + name)
        return result

    def send(self, receiver, name, result=C.c_void_p, args=(), values=()):
        key = (result, args)
        function = self.functions.get(key)
        if function is None:
            function = C.CFUNCTYPE(result, C.c_void_p, C.c_void_p, *args)(self.address)
            self.functions[key] = function
        return function(receiver, self.objc.sel_registerName(name.encode()), *values)

    def string(self, value):
        return self.send(self.cls("NSString"), "stringWithUTF8String:",
                         args=(C.c_char_p,), values=(value.encode(),))

    def text(self, obj):
        if not obj:
            return None
        value = self.send(obj, "UTF8String", result=C.c_char_p)
        return value.decode("utf-8", errors="replace") if value else None

    def bundle_capabilities(self):
        bundle = self.send(self.cls("NSBundle"), "mainBundle")
        info = self.send(bundle, "infoDictionary")
        def get(key):
            return self.send(info, "objectForKey:", args=(C.c_void_p,), values=(self.string(key),))
        modes = get("UIBackgroundModes")
        count = self.send(modes, "count", result=C.c_ulong) if modes else 0
        mode_names = [self.text(self.send(modes, "objectAtIndex:",
                        args=(C.c_ulong,), values=(n,))) for n in range(count)]
        keys = ["NSLocationWhenInUseUsageDescription", "NSLocationAlwaysUsageDescription",
                "NSLocationAlwaysAndWhenInUseUsageDescription"]
        return {"bundle_id": self.text(get("CFBundleIdentifier")),
                "background_modes": mode_names,
                "location_usage_keys": {key: bool(get(key)) for key in keys},
                "audio_player_class": bool(self.cls("AVAudioPlayer"))}


def silent_wav(seconds=2, rate=16000):
    stream = io.BytesIO()
    with wave.open(stream, "wb") as output:
        output.setnchannels(1)
        output.setsampwidth(2)
        output.setframerate(rate)
        output.writeframes(b"\0\0" * int(seconds * rate))
    return stream.getvalue()


class AudioKeepalive:
    def __init__(self):
        self.bridge = None
        self.player = None
        self.session = None
        self.lock = threading.RLock()

    def _checked(self, receiver, selector, args, values):
        error = C.c_void_p()
        ok = self.bridge.send(receiver, selector, result=C.c_bool,
            args=(*args, C.POINTER(C.c_void_p)), values=(*values, C.byref(error)))
        if not ok:
            description = self.bridge.send(error.value, "localizedDescription") if error.value else None
            raise RuntimeError(self.bridge.text(description) or (selector + " failed"))

    def start(self):
        with self.lock:
            if self.player and self.status()["playing"]:
                return self.status()
            self.stop()
            self.bridge = ObjC()
            pool = self.bridge.send(self.bridge.cls("NSAutoreleasePool"), "new")
            try:
                self.session = self.bridge.send(self.bridge.cls("AVAudioSession"), "sharedInstance")
                # AVAudioSessionCategoryOptionMixWithOthers = 1.
                self._checked(self.session, "setCategory:withOptions:error:",
                    (C.c_void_p, C.c_ulong), (self.bridge.string("AVAudioSessionCategoryPlayback"), 1))
                self._checked(self.session, "setActive:withOptions:error:",
                    (C.c_bool, C.c_ulong), (True, 0))
                wav = silent_wav()
                buffer = C.create_string_buffer(wav)
                data = self.bridge.send(self.bridge.cls("NSData"), "dataWithBytes:length:",
                    args=(C.c_void_p, C.c_ulong), values=(C.cast(buffer, C.c_void_p), len(wav)))
                allocated = self.bridge.send(self.bridge.cls("AVAudioPlayer"), "alloc")
                error = C.c_void_p()
                self.player = self.bridge.send(allocated, "initWithData:error:",
                    args=(C.c_void_p, C.POINTER(C.c_void_p)), values=(data, C.byref(error)))
                if not self.player:
                    description = self.bridge.send(error.value, "localizedDescription") if error.value else None
                    raise RuntimeError(self.bridge.text(description) or "AVAudioPlayer init failed")
                self.bridge.send(self.player, "setNumberOfLoops:", result=None,
                    args=(C.c_long,), values=(-1,))
                # The PCM samples themselves are zero. Leave player volume at 1,
                # since a zero-volume player may be optimized differently by iOS.
                self.bridge.send(self.player, "setVolume:", result=None,
                    args=(C.c_float,), values=(1.0,))
                if not self.bridge.send(self.player, "prepareToPlay", result=C.c_bool):
                    raise RuntimeError("AVAudioPlayer prepareToPlay failed")
                if not self.bridge.send(self.player, "play", result=C.c_bool):
                    raise RuntimeError("AVAudioPlayer play failed; start while the app is foreground")
                return self.status()
            except Exception:
                self.stop()
                raise
            finally:
                self.bridge.send(pool, "drain", result=None)

    def status(self):
        with self.lock:
            if not self.player:
                return {"playing": False, "position": None}
            return {"playing": bool(self.bridge.send(self.player, "isPlaying", result=C.c_bool)),
                    "position": self.bridge.send(self.player, "currentTime", result=C.c_double)}

    def stop(self):
        with self.lock:
            if self.player:
                self.bridge.send(self.player, "stop", result=None)
                self.bridge.send(self.player, "release", result=None)
                self.player = None
            if self.session:
                error = C.c_void_p()
                # AVAudioSessionSetActiveOptionNotifyOthersOnDeactivation = 1.
                self.bridge.send(self.session, "setActive:withOptions:error:", result=C.c_bool,
                    args=(C.c_bool, C.c_ulong, C.POINTER(C.c_void_p)),
                    values=(False, 1, C.byref(error)))
                self.session = None
