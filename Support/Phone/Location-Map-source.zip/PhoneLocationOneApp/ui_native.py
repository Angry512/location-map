"""A real, full-screen MapKit controller inside a-Shell's Python host.

Usage: ``screen = show(controller, initial_area={"lat": ..., "lon": ...})``.
The controller supplies thread-safe, nonblocking snapshot(), set(lat, lon), and
stop(). This module never opens a URL, starts another app, requests Core Location,
or starts simulation merely by selecting a point. The caller keeps Python alive.

An active snapshot requires fresh=True and confirmed_age_ms < 12000. Optional
position_age_ms is checked when supplied; its absence does not imply GPS proof.
close() removes native observers/timers and dismisses the screen; it does not
stop the engine. The runtime owns engine shutdown and background policy.

UIKit, MapKit, libdispatch and the Objective-C runtime are public Apple APIs.
Device execution must still validate that this host permits Python C callbacks.
Pure state helpers remain importable on other platforms for regression tests.
"""

from __future__ import annotations

import ctypes as C
from dataclasses import dataclass
import itertools
import math
import queue
import sys
import threading
import time
import uuid


LEASE_MS = 12_000
UI_REPLY_TIMEOUT = 4.0


def _point(value):
    if isinstance(value, dict):
        values = (value.get("lat", value.get("latitude")),
                  value.get("lon", value.get("longitude")))
    elif isinstance(value, (tuple, list)) and len(value) == 2:
        values = value
    else:
        return None
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) for v in values):
        return None
    latitude, longitude = map(float, values)
    if not (math.isfinite(latitude) and math.isfinite(longitude)):
        return None
    if not (-90 <= latitude <= 90 and -180 <= longitude <= 180):
        return None
    return latitude, longitude


def _normalize_snapshot(value, elapsed_ms=0):
    if not isinstance(value, dict) or value.get("state") not in (
            "idle", "connecting", "active", "error"):
        return {"state": "error", "message": "Device status is unavailable.",
                "fresh": False}
    result = dict(value)
    result["message"] = str(value.get("message") or "")[:600]
    if result["state"] == "active":
        ages = [value.get("confirmed_age_ms")]
        if "position_age_ms" in value:
            ages.append(value["position_age_ms"])
        valid = all(not isinstance(age, bool) and isinstance(age, (int, float))
                    and math.isfinite(age) and age >= 0 for age in ages)
        if (value.get("fresh") is not True or not valid
                or max(ages) + max(0, elapsed_ms) >= LEASE_MS):
            result.update(state="error", fresh=False,
                          message="Connection not confirmed. Stop can reconnect to the device.")
    return result


@dataclass
class _UIModel:
    """State only: selecting or rendering never invokes the engine."""

    state: str = "connecting"
    message: str = "Checking the device connection..."
    selected: tuple | None = None
    draft: bool = False
    possible_active: bool = False
    pending: str | None = None
    foreground: bool = True
    last_reply_at: float | None = None
    last_snapshot: dict | None = None

    def select(self, value):
        candidate = _point(value)
        if candidate is None:
            return False
        self.selected, self.draft = candidate, True
        return True

    def cancel_selection(self):
        self.draft = False
        self.selected = _point(self.last_snapshot) if self.possible_active else None

    def begin(self, operation):
        if operation not in ("set", "stop"):
            raise ValueError("Unknown operation")
        self.pending = operation
        self.state = "connecting"
        self.message = "Applying the selected location..." if operation == "set" else "Stopping simulation..."
        self.possible_active = True
        if operation == "set":
            self.draft = False

    def invalidate(self, message="Checking the current device connection..."):
        self.possible_active |= self.state == "active" or self.pending is not None
        self.state, self.message, self.last_reply_at = "connecting", message, None

    def receive(self, value, now, elapsed_ms=0):
        status = _normalize_snapshot(value, elapsed_ms)
        self.last_snapshot, self.last_reply_at = status, now
        incoming = status["state"]
        if self.pending == "set" and incoming == "idle":
            self.state, self.message = "connecting", "Waiting for device confirmation..."
            return
        if self.pending == "stop" and incoming in ("active", "connecting"):
            self.state, self.message = "connecting", "Stopping simulation..."
            return
        if incoming == "active":
            self.possible_active = True
            if self.pending == "set":
                self.pending, self.draft = None, False
            if not self.draft and _point(status):
                self.selected = _point(status)
        elif incoming == "idle":
            self.possible_active = False
            if self.pending == "stop":
                self.pending, self.selected, self.draft = None, None, False
        elif incoming == "error":
            # An error may represent a previous engine session. Stop must remain
            # available even after Python or the host app was restarted.
            self.possible_active, self.pending = True, None
        self.state = incoming
        self.message = status["message"]

    def view(self):
        if self.draft:
            title = "Dropped Pin"
            subtitle = ("Checking connection..." if self.last_reply_at is None else
                        (self.message or "Connection not confirmed") if self.state == "error" else
                        "Ready to simulate")
        elif self.pending == "stop":
            title, subtitle = "Stopping...", "Waiting for the device"
        elif self.state == "active":
            title, subtitle = "Simulating", "Connection confirmed"
        elif self.state == "error":
            title, subtitle = "Not confirmed", self.message or "Stop can reconnect to the device"
        elif self.state == "connecting":
            title, subtitle = "Checking...", "Waiting for current device status"
        else:
            title, subtitle = "Choose a location", "Tap the map to drop a pin"
        stop_visible = self.possible_active or self.state in ("active", "error")
        return {
            "title": title, "subtitle": subtitle,
            "simulate_visible": self.draft and self.selected is not None,
            "simulate_enabled": (self.foreground and self.last_reply_at is not None
                                 and not self.pending and self.state != "connecting"),
            "stop_visible": stop_visible,
            "stop_enabled": self.foreground and self.pending != "stop",
            "close_visible": self.draft and self.pending is None,
        }


class Point(C.Structure):
    _fields_ = [("x", C.c_double), ("y", C.c_double)]


class Size(C.Structure):
    _fields_ = [("width", C.c_double), ("height", C.c_double)]


class Rect(C.Structure):
    _fields_ = [("origin", Point), ("size", Size)]


class Insets(C.Structure):
    _fields_ = [("top", C.c_double), ("left", C.c_double),
                ("bottom", C.c_double), ("right", C.c_double)]


class Coordinate(C.Structure):
    _fields_ = [("latitude", C.c_double), ("longitude", C.c_double)]


class Span(C.Structure):
    _fields_ = [("latitudeDelta", C.c_double), ("longitudeDelta", C.c_double)]


class Region(C.Structure):
    _fields_ = [("center", Coordinate), ("span", Span)]


class _ObjCSuper(C.Structure):
    _fields_ = [("receiver", C.c_void_p), ("super_class", C.c_void_p)]


class _ObjC:
    def __init__(self):
        if sys.platform not in ("darwin", "ios"):
            raise RuntimeError("Native MapKit requires a-Shell on iOS")
        self.foundation = C.CDLL("/System/Library/Frameworks/Foundation.framework/Foundation")
        self.uikit = C.CDLL("/System/Library/Frameworks/UIKit.framework/UIKit")
        self.mapkit = C.CDLL("/System/Library/Frameworks/MapKit.framework/MapKit")
        self.objc = C.CDLL("/usr/lib/libobjc.A.dylib")
        for name, args, result in (
                ("objc_getClass", [C.c_char_p], C.c_void_p),
                ("sel_registerName", [C.c_char_p], C.c_void_p),
                ("class_getSuperclass", [C.c_void_p], C.c_void_p),
                ("objc_allocateClassPair", [C.c_void_p, C.c_char_p, C.c_size_t], C.c_void_p),
                ("objc_registerClassPair", [C.c_void_p], None),
                ("class_addMethod", [C.c_void_p, C.c_void_p, C.c_void_p, C.c_char_p], C.c_bool),
                ("objc_getProtocol", [C.c_char_p], C.c_void_p),
                ("class_addProtocol", [C.c_void_p, C.c_void_p], C.c_bool)):
            function = getattr(self.objc, name)
            function.argtypes, function.restype = args, result
        self.address = C.cast(self.objc.objc_msgSend, C.c_void_p).value
        self.super_address = C.cast(self.objc.objc_msgSendSuper, C.c_void_p).value
        self.functions = {}

    def cls(self, name):
        result = self.objc.objc_getClass(name.encode())
        if not result:
            raise RuntimeError("Missing Objective-C class: " + name)
        return result

    def selector(self, name):
        return self.objc.sel_registerName(name.encode())

    def send(self, receiver, name, result=C.c_void_p, args=(), values=()):
        key = (False, result, args)
        if key not in self.functions:
            self.functions[key] = C.CFUNCTYPE(result, C.c_void_p, C.c_void_p, *args)(self.address)
        return self.functions[key](receiver, self.selector(name), *values)

    def super(self, receiver, native_class, name, args=(), values=()):
        key = (True, None, args)
        if key not in self.functions:
            self.functions[key] = C.CFUNCTYPE(None, C.POINTER(_ObjCSuper), C.c_void_p, *args)(self.super_address)
        value = _ObjCSuper(receiver, self.objc.class_getSuperclass(native_class))
        self.functions[key](C.byref(value), self.selector(name), *values)

    def responds(self, receiver, name):
        return self.send(receiver, "respondsToSelector:", result=C.c_bool,
                         args=(C.c_void_p,), values=(self.selector(name),))

    def string(self, value):
        return self.send(self.cls("NSString"), "stringWithUTF8String:",
                         args=(C.c_char_p,), values=(str(value).encode("utf-8"),))

    def require_main(self):
        if not self.send(self.cls("NSThread"), "isMainThread", result=C.c_bool):
            raise RuntimeError("UIKit operation attempted outside the iOS main thread")


# CFUNCTYPE instances used as native IMPs must outlive every Objective-C instance.
# These anchors are intentionally permanent for this interpreter's lifetime.
_SCREENS = {}
_IMP_CALLBACKS = []
_NATIVE_CLASS = None
_CLASS_LOCK = threading.Lock()
_MAIN_CALLBACK = None
_MAIN_DISPATCH = None
_MAIN_QUEUE = None
_MAIN_JOBS = {}
_MAIN_LOCK = threading.Lock()
_JOB_IDS = itertools.count(1)


def _on_main(bridge, function, wait=False):
    global _MAIN_CALLBACK, _MAIN_DISPATCH, _MAIN_QUEUE
    if bridge.send(bridge.cls("NSThread"), "isMainThread", result=C.c_bool):
        return function()
    with _MAIN_LOCK:
        if _MAIN_CALLBACK is None:
            dispatch = C.CDLL("/usr/lib/system/libdispatch.dylib")
            callback_type = C.CFUNCTYPE(None, C.c_void_p)

            def invoke(context):
                with _MAIN_LOCK:
                    job = _MAIN_JOBS.pop(int(context or 0), None)
                if not job:
                    return
                pool = None
                try:
                    if not job.get("cancelled"):
                        pool = job["bridge"].send(job["bridge"].cls("NSAutoreleasePool"), "new")
                        job["result"] = job["function"]()
                except BaseException as error:
                    job["error"] = error
                finally:
                    if pool:
                        job["bridge"].send(pool, "drain", result=None)
                    job["finished"].set()

            _MAIN_CALLBACK = callback_type(invoke)
            _MAIN_QUEUE = C.addressof(C.c_char.in_dll(dispatch, "_dispatch_main_q"))
            dispatch.dispatch_async_f.argtypes = [C.c_void_p, C.c_void_p, callback_type]
            dispatch.dispatch_async_f.restype = None
            _MAIN_DISPATCH = dispatch
        key = next(_JOB_IDS)
        job = {"bridge": bridge, "function": function, "finished": threading.Event()}
        _MAIN_JOBS[key] = job
    _MAIN_DISPATCH.dispatch_async_f(_MAIN_QUEUE, C.c_void_p(key), _MAIN_CALLBACK)
    if not wait:
        return None
    if not job["finished"].wait(10):
        # The single C trampoline stays retained even when a queued job times out.
        job["cancelled"] = True
        raise RuntimeError("The iOS main queue did not respond within 10 seconds")
    if "error" in job:
        raise job["error"]
    return job.get("result")


def _native_class(bridge):
    global _NATIVE_CLASS
    with _CLASS_LOCK:
        if _NATIVE_CLASS:
            return _NATIVE_CLASS
        native_class = bridge.objc.objc_allocateClassPair(
            bridge.cls("UIViewController"),
            ("PLNativeMap_" + uuid.uuid4().hex[:12]).encode(), 0)
        if not native_class:
            raise RuntimeError("Cannot allocate the native map controller class")

        def install(selector, restype, arguments, encoding, method, default=None):
            callback_type = C.CFUNCTYPE(restype, C.c_void_p, C.c_void_p, *arguments)

            def invoke(receiver, _command, *values):
                screen = _SCREENS.get(int(receiver or 0))
                if screen is None:
                    return default
                try:
                    screen.bridge.require_main()
                    return getattr(screen, method)(*values)
                except BaseException as error:
                    screen._callback_error(error)
                    return default

            callback = callback_type(invoke)
            _IMP_CALLBACKS.append(callback)
            if not bridge.objc.class_addMethod(native_class, bridge.selector(selector),
                    C.cast(callback, C.c_void_p), encoding):
                raise RuntimeError("Cannot install Objective-C action " + selector)

        install("viewDidLayoutSubviews", None, (), b"v@:", "_did_layout")
        install("viewDidAppear:", None, (C.c_bool,), b"v@:B", "_did_appear")
        install("viewWillDisappear:", None, (C.c_bool,), b"v@:B", "_will_disappear")
        for selector, method in (
                ("mapTapped:", "_map_tapped"), ("simulatePressed:", "_simulate_pressed"),
                ("stopPressed:", "_stop_pressed"), ("closePressed:", "_close_pressed"),
                ("recenterPressed:", "_recenter_pressed"), ("statusTick:", "_status_tick"),
                ("appResigned:", "_app_resigned"), ("appActivated:", "_app_activated")):
            install(selector, None, (C.c_void_p,), b"v@:@", method)
        install("gestureRecognizer:shouldRecognizeSimultaneouslyWithGestureRecognizer:",
                C.c_bool, (C.c_void_p, C.c_void_p), b"B@:@@", "_simultaneous", False)
        install("gestureRecognizer:shouldReceiveTouch:", C.c_bool,
                (C.c_void_p, C.c_void_p), b"B@:@@", "_should_receive_touch", False)
        install("mapView:viewForAnnotation:", C.c_void_p,
                (C.c_void_p, C.c_void_p), b"@@:@@", "_annotation_view")
        protocol = bridge.objc.objc_getProtocol(b"UIGestureRecognizerDelegate")
        if protocol:
            bridge.objc.class_addProtocol(native_class, protocol)
        protocol = bridge.objc.objc_getProtocol(b"MKMapViewDelegate")
        if protocol:
            bridge.objc.class_addProtocol(native_class, protocol)
        bridge.objc.objc_registerClassPair(native_class)
        _NATIVE_CLASS = native_class
        return native_class


class NativeMapScreen:
    """Retained native screen. All methods that touch UIKit run on its main queue."""

    def __init__(self, controller, initial_area=None):
        for name in ("snapshot", "set", "stop"):
            if not callable(getattr(controller, name, None)):
                raise TypeError("controller must implement " + name)
        if initial_area is not None and _point(initial_area) is None:
            raise ValueError("initial_area must contain valid latitude/longitude")
        self.controller, self.initial_area = controller, _point(initial_area)
        self.bridge, self.model = _ObjC(), _UIModel()
        self.native_class = _native_class(self.bridge)
        self.native_controller = None
        self.mapview = self.view = self.card = self.content = None
        self.title_label = self.subtitle_label = None
        self.simulate_button = self.stop_button = self.close_button = None
        self.recenter_card = self.recenter_button = self.gesture = self.timer = None
        self.annotation = None
        self.location_annotation = None
        self._annotation_added = False
        self._annotation_point = None
        self._closed = threading.Event()
        self._wake = threading.Event()
        self._commands = queue.Queue(maxsize=8)
        self._lock = threading.Lock()
        self._generation = 0
        self._foreground = True
        self._latest = None
        self._update_queued = False
        self._ready = False
        self._last_tick = time.monotonic()
        self.last_error = None
        self._worker = None

    def _send(self, receiver, selector, result=C.c_void_p, args=(), values=()):
        return self.bridge.send(receiver, selector, result, args, values)

    def _set(self, receiver, selector, value, argument=C.c_void_p):
        self._send(receiver, selector, result=None, args=(argument,), values=(value,))

    def _color(self, name):
        return self._send(self.bridge.cls("UIColor"), name)

    def _font(self, size, weight=0):
        return self._send(self.bridge.cls("UIFont"), "systemFontOfSize:weight:",
                          args=(C.c_double, C.c_double), values=(size, weight))

    def _label(self, size, weight=0, secondary=False):
        label = self._send(self.bridge.cls("UILabel"), "new")
        self._set(label, "setFont:", self._font(size, weight))
        self._set(label, "setTextColor:", self._color("secondaryLabelColor" if secondary else "labelColor"))
        self._set(label, "setNumberOfLines:", 2 if secondary else 1, C.c_long)
        self._set(self.content, "addSubview:", label)
        return label

    def _button(self, title, action, background=None, symbol=None, parent=None):
        button = self._send(self.bridge.cls("UIButton"), "buttonWithType:",
                            args=(C.c_long,), values=(1,))
        self._send(button, "setTitle:forState:", result=None,
                   args=(C.c_void_p, C.c_ulong), values=(self.bridge.string(title), 0))
        self._send(button, "addTarget:action:forControlEvents:", result=None,
                   args=(C.c_void_p, C.c_void_p, C.c_ulong),
                   values=(self.native_controller, self.bridge.selector(action), 1 << 6))
        self._set(button, "setTintColor:", self._color("systemBlueColor"))
        title_label = self._send(button, "titleLabel")
        self._set(title_label, "setFont:", self._font(16, .3))
        if background:
            self._set(button, "setBackgroundColor:", self._color(background))
            self._send(button, "setTitleColor:forState:", result=None,
                       args=(C.c_void_p, C.c_ulong), values=(self._color("whiteColor"), 0))
            self._round(button, 16)
        if symbol:
            image = self._send(self.bridge.cls("UIImage"), "systemImageNamed:",
                               args=(C.c_void_p,), values=(self.bridge.string(symbol),))
            self._send(button, "setImage:forState:", result=None,
                       args=(C.c_void_p, C.c_ulong), values=(image, 0))
        self._set(parent or self.content, "addSubview:", button)
        return button

    def _round(self, view, radius):
        layer = self._send(view, "layer")
        self._set(layer, "setCornerRadius:", radius, C.c_double)
        self._set(view, "setClipsToBounds:", True, C.c_bool)

    def _glass(self, parent):
        effect = self._send(self.bridge.cls("UIBlurEffect"), "effectWithStyle:",
                            args=(C.c_long,), values=(8,))  # systemMaterial
        glass = self._send(self._send(self.bridge.cls("UIVisualEffectView"), "alloc"),
                           "initWithEffect:", args=(C.c_void_p,), values=(effect,))
        self._set(parent, "addSubview:", glass)
        return glass

    def _find_presenter(self):
        app = self._send(self.bridge.cls("UIApplication"), "sharedApplication")
        scenes = self._send(self._send(app, "connectedScenes"), "allObjects")
        root = None
        for n in range(self._send(scenes, "count", result=C.c_ulong)):
            scene = self._send(scenes, "objectAtIndex:", args=(C.c_ulong,), values=(n,))
            if self._send(scene, "activationState", result=C.c_long) != 0:
                continue
            if not self.bridge.responds(scene, "windows"):
                continue
            windows = self._send(scene, "windows")
            for index in range(self._send(windows, "count", result=C.c_ulong)):
                window = self._send(windows, "objectAtIndex:", args=(C.c_ulong,), values=(index,))
                if self._send(window, "isKeyWindow", result=C.c_bool):
                    root = self._send(window, "rootViewController")
                    break
            if root:
                break
        if not root:
            raise RuntimeError("No active a-Shell window. Open the host app first.")
        while True:
            presented = self._send(root, "presentedViewController")
            if not presented:
                return root
            root = presented

    def _present(self):
        self.bridge.require_main()
        presenter = self._find_presenter()
        self.native_controller = self._send(self.native_class, "new")
        _SCREENS[int(self.native_controller)] = self
        self.view = self._send(self.native_controller, "view")
        host_bounds = self._send(self._send(presenter, "view"), "bounds", result=Rect)
        self._set(self.view, "setFrame:", host_bounds, Rect)
        self.mapview = self._send(self._send(self.bridge.cls("MKMapView"), "alloc"),
                                  "initWithFrame:", args=(Rect,), values=(host_bounds,))
        self._set(self.mapview, "setAutoresizingMask:", 18, C.c_ulong)
        self._set(self.mapview, "setShowsUserLocation:", False, C.c_bool)
        self._set(self.mapview, "setDelegate:", self.native_controller)
        self._set(self.mapview, "setShowsCompass:", True, C.c_bool)
        self._set(self.mapview, "setShowsScale:", False, C.c_bool)
        self._set(self.view, "addSubview:", self.mapview)
        # Native MapKit supplies cartography and markers. No MapKit JS token,
        # custom tile service, HTML, or additional location permission.
        if self.bridge.responds(self.mapview, "setPointOfInterestFilter:"):
            poi = self._send(self.bridge.cls("MKPointOfInterestFilter"), "filterExcludingAllCategories")
            self._set(self.mapview, "setPointOfInterestFilter:", poi)
        if self.bridge.responds(self.mapview, "setSelectableMapFeatures:"):
            self._set(self.mapview, "setSelectableMapFeatures:", 0, C.c_ulong)
        self._center(self.initial_area, animated=False)
        self._sync_location_dot()
        self.card = self._glass(self.view)
        self._round(self.card, 28)
        self.content = self._send(self.card, "contentView")
        self.title_label = self._label(20, .3)
        self.subtitle_label = self._label(12, secondary=True)
        self.simulate_button = self._button("Simulate", "simulatePressed:", "systemBlueColor")
        self.stop_button = self._button("Stop", "stopPressed:", "systemRedColor")
        self.close_button = self._button("", "closePressed:", symbol="xmark.circle.fill")
        self._set(self.close_button, "setAccessibilityLabel:", self.bridge.string("Cancel selected location"))
        self.recenter_card = self._glass(self.view)
        self._round(self.recenter_card, 25)
        self.recenter_button = self._button("", "recenterPressed:", symbol="location",
                                          parent=self._send(self.recenter_card, "contentView"))
        self._set(self.recenter_button, "setAccessibilityLabel:", self.bridge.string("Zoom to your location"))
        self._set(self.recenter_card, "setHidden:", self.initial_area is None, C.c_bool)
        self.gesture = self._send(self._send(self.bridge.cls("UITapGestureRecognizer"), "alloc"),
                                 "initWithTarget:action:", args=(C.c_void_p, C.c_void_p),
                                 values=(self.native_controller, self.bridge.selector("mapTapped:")))
        self._set(self.gesture, "setCancelsTouchesInView:", False, C.c_bool)
        self._set(self.gesture, "setDelegate:", self.native_controller)
        existing = self._send(self.mapview, "gestureRecognizers")
        for index in range(self._send(existing, "count", result=C.c_ulong)):
            other = self._send(existing, "objectAtIndex:", args=(C.c_ulong,), values=(index,))
            is_tap = self._send(other, "isKindOfClass:", result=C.c_bool,
                                args=(C.c_void_p,), values=(self.bridge.cls("UITapGestureRecognizer"),))
            if is_tap and self._send(other, "numberOfTapsRequired", result=C.c_ulong) > 1:
                self._set(self.gesture, "requireGestureRecognizerToFail:", other)
        self._set(self.mapview, "addGestureRecognizer:", self.gesture)
        self._set(self.native_controller, "setModalPresentationStyle:", 0, C.c_long)  # fullScreen
        self._set(self.native_controller, "setModalInPresentation:", True, C.c_bool)
        center = self._send(self.bridge.cls("NSNotificationCenter"), "defaultCenter")
        for name, selector in (
                ("UIApplicationWillResignActiveNotification", "appResigned:"),
                ("UIApplicationDidBecomeActiveNotification", "appActivated:")):
            notification = C.c_void_p.in_dll(self.bridge.uikit, name).value
            self._send(center, "addObserver:selector:name:object:", result=None,
                       args=(C.c_void_p, C.c_void_p, C.c_void_p, C.c_void_p),
                       values=(self.native_controller, self.bridge.selector(selector), notification, None))
        self.timer = self._send(self.bridge.cls("NSTimer"),
            "scheduledTimerWithTimeInterval:target:selector:userInfo:repeats:",
            args=(C.c_double, C.c_void_p, C.c_void_p, C.c_void_p, C.c_bool),
            values=(1.0, self.native_controller, self.bridge.selector("statusTick:"), None, True))
        self._ready = True
        self._render()
        self._send(presenter, "presentViewController:animated:completion:", result=None,
                   args=(C.c_void_p, C.c_bool, C.c_void_p),
                   values=(self.native_controller, True, None))
        return self

    def _center(self, value, animated=True, zoomed=False):
        coordinate = value or (20, 0)
        span = (.0025 if zoomed else .04) if value else 120
        self._send(self.mapview, "setRegion:animated:", result=None,
                   args=(Region, C.c_bool),
                   values=(Region(Coordinate(*coordinate), Span(span, span)), animated))

    def _frame(self, view, x, y, width, height):
        self._set(view, "setFrame:", Rect(Point(x, y), Size(max(0, width), max(0, height))), Rect)

    def _layout(self):
        if not self._ready or self._closed.is_set():
            return
        self.bridge.require_main()
        bounds = self._send(self.view, "bounds", result=Rect)
        safe = self._send(self.view, "safeAreaInsets", result=Insets)
        width, height = bounds.size.width, bounds.size.height
        self._frame(self.mapview, 0, 0, width, height)
        controls = self.model.view()
        actions = controls["simulate_visible"] or controls["stop_visible"]
        card_width = min(430, max(200, width - safe.left - safe.right - 28))
        card_height = 143 if actions else 82
        left = safe.left + (width - safe.left - safe.right - card_width) / 2
        top = max(safe.top + 10, height - max(14, safe.bottom) - card_height)
        self._frame(self.card, left, top, card_width, card_height)
        self._frame(self.title_label, 18, 13, card_width - 70, 27)
        self._frame(self.subtitle_label, 18, 41, card_width - 36, 30)
        self._frame(self.close_button, card_width - 49, 9, 36, 36)
        both = controls["simulate_visible"] and controls["stop_visible"]
        button_width = (card_width - 45) / 2 if both else card_width - 36
        self._frame(self.simulate_button, 18, 81, button_width, 48)
        self._frame(self.stop_button, 27 + button_width if both else 18, 81, button_width, 48)
        self._frame(self.recenter_card, width - safe.right - 66, max(safe.top + 12, top - 66), 50, 50)
        self._frame(self.recenter_button, 0, 0, 50, 50)

    def _render(self):
        if not self._ready or self._closed.is_set():
            return
        self.bridge.require_main()
        controls = self.model.view()
        self._set(self.title_label, "setText:", self.bridge.string(controls["title"]))
        self._set(self.subtitle_label, "setText:", self.bridge.string(controls["subtitle"]))
        for button, prefix in ((self.simulate_button, "simulate"), (self.stop_button, "stop")):
            self._set(button, "setHidden:", not controls[prefix + "_visible"], C.c_bool)
            self._set(button, "setEnabled:", controls[prefix + "_enabled"], C.c_bool)
        self._set(self.close_button, "setHidden:", not controls["close_visible"], C.c_bool)
        self._sync_annotation()
        self._layout()

    def _sync_annotation(self):
        candidate = self.model.selected
        if candidate is None:
            if self._annotation_added:
                self._set(self.mapview, "removeAnnotation:", self.annotation)
                self._annotation_added = False
            self._annotation_point = None
            return
        if not self.annotation:
            self.annotation = self._send(self.bridge.cls("MKPointAnnotation"), "new")
        if candidate != self._annotation_point:
            self._set(self.annotation, "setCoordinate:", Coordinate(*candidate), Coordinate)
            self._annotation_point = candidate
        self._set(self.annotation, "setTitle:", self.bridge.string("Dropped Pin" if self.model.draft else "Simulated location"))
        if not self._annotation_added:
            self._set(self.mapview, "addAnnotation:", self.annotation)
            self._annotation_added = True

    def _sync_location_dot(self):
        # This is the owner's precise launch-time location from Shortcuts,
        # separate from the selection/simulation pin and its status.
        if self.initial_area is None:
            return
        if not self.location_annotation:
            self.location_annotation = self._send(self.bridge.cls("MKPointAnnotation"), "new")
            self._set(self.location_annotation, "setTitle:",
                      self.bridge.string("Your location when opened"))
            self._set(self.location_annotation, "setCoordinate:", Coordinate(*self.initial_area), Coordinate)
            self._set(self.mapview, "addAnnotation:", self.location_annotation)
        else:
            self._set(self.location_annotation, "setCoordinate:", Coordinate(*self.initial_area), Coordinate)

    def _annotation_view(self, mapview, annotation):
        if not self.location_annotation or annotation != self.location_annotation:
            return None  # Keep MapKit's normal dropped/simulation pin.
        reuse = self.bridge.string("PhoneLocationCurrentDot")
        view = self._send(mapview, "dequeueReusableAnnotationViewWithIdentifier:",
                          args=(C.c_void_p,), values=(reuse,))
        if view:
            self._set(view, "setAnnotation:", annotation)
            return view
        view = self._send(self._send(self.bridge.cls("MKAnnotationView"), "alloc"),
                          "initWithAnnotation:reuseIdentifier:",
                          args=(C.c_void_p, C.c_void_p), values=(annotation, reuse))
        self._frame(view, 0, 0, 36, 36)
        blue = self._color("systemBlueColor")
        halo = self._send(blue, "colorWithAlphaComponent:",
                          args=(C.c_double,), values=(.18,))
        self._set(view, "setBackgroundColor:", halo)
        self._round(view, 18)
        for size, color in ((20, self._color("whiteColor")), (14, blue)):
            circle = self._send(self.bridge.cls("UIView"), "new")
            self._frame(circle, (36-size)/2, (36-size)/2, size, size)
            self._set(circle, "setBackgroundColor:", color)
            self._round(circle, size/2)
            self._set(circle, "setUserInteractionEnabled:", False, C.c_bool)
            self._set(view, "addSubview:", circle)
        self._set(view, "setCanShowCallout:", False, C.c_bool)
        self._set(view, "setDisplayPriority:", 1000, C.c_float)
        self._set(view, "setAccessibilityLabel:", self.bridge.string("Your location when opened"))
        return view

    def _did_layout(self):
        self.bridge.super(self.native_controller, self.native_class, "viewDidLayoutSubviews")
        self._layout()

    def _did_appear(self, animated):
        self.bridge.super(self.native_controller, self.native_class, "viewDidAppear:", (C.c_bool,), (animated,))
        self._set_foreground(True)

    def _will_disappear(self, animated):
        self.bridge.super(self.native_controller, self.native_class, "viewWillDisappear:", (C.c_bool,), (animated,))
        self._set_foreground(False)

    def _app_resigned(self, _notification):
        self._set_foreground(False)

    def _app_activated(self, _notification):
        self._set_foreground(True)

    def _set_foreground(self, foreground):
        if self._closed.is_set():
            return
        with self._lock:
            self._generation += 1
            self._foreground = foreground
        self.model.foreground = foreground
        prepare_link = getattr(self.controller, 'set_foreground', None)
        if prepare_link is not None:
            prepare_link(foreground)
        self.model.invalidate("Checking the current device connection..." if foreground
                              else "Connection will be checked when you return.")
        self._last_tick = time.monotonic()
        self._render()
        self._wake.set()

    def _status_tick(self, _timer):
        if self._closed.is_set():
            return
        now = time.monotonic()
        app = self._send(self.bridge.cls("UIApplication"), "sharedApplication")
        foreground = self._send(app, "applicationState", result=C.c_long) == 0
        window = self._send(self.view, "window")
        scene = self._send(window, "windowScene") if window else None
        if scene and self._send(scene, "activationState", result=C.c_long) != 0:
            foreground = False
        if foreground != self._foreground or now - self._last_tick > UI_REPLY_TIMEOUT:
            self._set_foreground(foreground)
        self._last_tick = now
        if (foreground and self.model.last_reply_at is not None
                and now - self.model.last_reply_at > UI_REPLY_TIMEOUT):
            self.model.invalidate("Waiting for current device status...")
            self._render()
        self._wake.set()

    def _map_tapped(self, gesture):
        if self._closed.is_set() or not self._foreground:
            return
        if self._send(gesture, "state", result=C.c_long) != 3:  # UIGestureRecognizerStateRecognized
            return
        location = self._send(gesture, "locationInView:", result=Point,
                              args=(C.c_void_p,), values=(self.mapview,))
        coordinate = self._send(self.mapview, "convertPoint:toCoordinateFromView:", result=Coordinate,
                                args=(Point, C.c_void_p), values=(location, self.mapview))
        if self.model.select((coordinate.latitude, coordinate.longitude)):
            self._render()

    def _simultaneous(self, _gesture, _other):
        return True

    def _should_receive_touch(self, _gesture, touch):
        view = self._send(touch, "view")
        for _ in range(15):
            if not view or view == self.mapview:
                return True
            if self._send(view, "isKindOfClass:", result=C.c_bool,
                          args=(C.c_void_p,), values=(self.bridge.cls("UIControl"),)):
                return False
            view = self._send(view, "superview")
        return False

    def _simulate_pressed(self, _button):
        if self.model.view()["simulate_enabled"] and self.model.selected:
            self._enqueue("set", self.model.selected)

    def _stop_pressed(self, _button):
        if self.model.view()["stop_enabled"]:
            self._enqueue("stop")

    def _close_pressed(self, _button):
        self.model.cancel_selection()
        self._render()

    def _recenter_pressed(self, _button):
        if self.initial_area:
            self._center(self.initial_area, zoomed=True)

    def update_area(self, area):
        value = _point(area)
        if value is None:
            return
        def apply():
            state = self.controller.snapshot()
            if self._closed.is_set() or state['state'] != 'idle' or state.get('requires_stop'):
                return
            self.initial_area = value
            self._sync_location_dot()
            self._set(self.recenter_card, 'setHidden:', False, C.c_bool)
            if not self.model.draft:
                self._center(value)
        _on_main(self.bridge, apply)

    def _enqueue(self, operation, coordinate=None):
        if self._closed.is_set():
            return
        try:
            self._commands.put_nowait((operation, coordinate))
        except queue.Full:
            self.model.receive({"state": "error", "message": "A device command is still pending."}, time.monotonic())
        else:
            self.model.begin(operation)
            self._wake.set()
        self._render()

    def _callback_error(self, error):
        self.last_error = str(error)
        try:
            self.model.receive({"state": "error", "message": "Close and reopen Location Map."}, time.monotonic())
            self._render()
        except BaseException:
            # Exceptions must never escape through a ctypes native callback.
            pass

    def _queue_status(self, snapshot, generation, started, completed):
        with self._lock:
            self._latest = (snapshot, generation, started, completed)
            if self._update_queued:
                return
            self._update_queued = True
        _on_main(self.bridge, self._consume_status)

    def _consume_status(self):
        self.bridge.require_main()
        with self._lock:
            latest, self._latest = self._latest, None
            self._update_queued = False
            generation, foreground = self._generation, self._foreground
        if self._closed.is_set() or latest is None or not foreground:
            return
        snapshot, captured_generation, started, completed = latest
        now = time.monotonic()
        if captured_generation != generation or now - completed > UI_REPLY_TIMEOUT:
            return
        self.model.receive(snapshot, now, max(0, (now - started) * 1000))
        self._render()

    def _run(self):
        while not self._closed.is_set():
            self._wake.wait(.75)
            self._wake.clear()
            while not self._closed.is_set():
                try:
                    operation, coordinate = self._commands.get_nowait()
                except queue.Empty:
                    break
                try:
                    if operation == "set":
                        self.controller.set(*coordinate)
                    else:
                        self.controller.stop()
                except BaseException as error:
                    with self._lock:
                        generation = self._generation
                    now = time.monotonic()
                    self._queue_status({"state": "error", "message": str(error)}, generation, now, now)
            with self._lock:
                generation, foreground = self._generation, self._foreground
            if not foreground or self._closed.is_set():
                continue
            started = time.monotonic()
            try:
                value = self.controller.snapshot()
                snapshot = dict(value) if isinstance(value, dict) else value
            except BaseException as error:
                snapshot = {"state": "error", "message": str(error)}
            self._queue_status(snapshot, generation, started, time.monotonic())

    def close(self):
        """Dismiss only this UI. The runtime must stop its engine separately."""
        if self._closed.is_set():
            return
        self._closed.set()
        self._wake.set()

        def dismiss():
            self.bridge.require_main()
            if self.timer:
                self._send(self.timer, "invalidate", result=None)
                self.timer = None
            center = self._send(self.bridge.cls("NSNotificationCenter"), "defaultCenter")
            self._set(center, "removeObserver:", self.native_controller)
            if self.gesture:
                self._set(self.gesture, "setDelegate:", None)
                self._set(self.mapview, "removeGestureRecognizer:", self.gesture)
            self._set(self.mapview, "setDelegate:", None)
            if self._send(self.native_controller, "presentingViewController"):
                self._send(self.native_controller, "dismissViewControllerAnimated:completion:", result=None,
                           args=(C.c_bool, C.c_void_p), values=(False, None))
            # Keep the native object and permanent method trampolines anchored.
            # UIKit may still deliver lifecycle callbacks after dismissal returns.

        _on_main(self.bridge, dismiss, wait=True)


def show(controller, initial_area=None):
    """Present a full-screen native map inside the current a-Shell window.

    Does not block the runtime or request location permission. The returned screen
    and native callbacks remain retained until interpreter shutdown. The caller
    must keep Python running, and call screen.close() before shutting it down.
    """
    screen = NativeMapScreen(controller, initial_area)
    try:
        _on_main(screen.bridge, screen._present, wait=True)
        screen._worker = threading.Thread(target=screen._run, name="PhoneLocation-UI", daemon=True)
        screen._worker.start()
        screen._wake.set()
        return screen
    except BaseException:
        if screen.native_controller:
            try:
                screen.close()
            except BaseException:
                pass
        raise
