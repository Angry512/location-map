import contextlib
import io
import pathlib
import shlex
import sys
import tempfile
import unittest
from unittest.mock import patch

from startup_profile import merge_profile


class StartupProfileTests(unittest.TestCase):
    def run_command(self, profile, home):
        command = next(line for line in profile.splitlines() if line.startswith('python3 -c '))
        with patch.object(pathlib.Path, 'home', return_value=home), patch.object(sys, 'path', sys.path[:]):
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                exec(shlex.split(command)[2], {})
            return output.getvalue()

    def test_migrates_old_absolute_path_and_runs_from_relocated_container(self):
        old = 'alias useful=ls\n# Location Map native startup\nclear\n' + (
            'python3 /private/var/mobile/Containers/Data/Application/old/Documents/'
            'PhoneLocationOneApp/phone_location.py\n')
        profile = merge_profile(old)
        self.assertTrue(profile.startswith('alias useful=ls\n'))
        self.assertNotIn('/Application/old/', profile)
        self.assertEqual(merge_profile(profile), profile)
        with tempfile.TemporaryDirectory() as folder:
            home = pathlib.Path(folder) / 'new container'
            project = home / 'Documents' / 'PhoneLocationOneApp'
            project.mkdir(parents=True)
            (project / 'phone_location.py').write_text('import test_profile_sibling\nprint("ready")\n')
            (project / 'test_profile_sibling.py').write_text('')
            try:
                self.assertEqual(self.run_command(profile, home), 'ready\n')
                self.assertEqual(self.run_command(profile, home / 'Documents'), 'ready\n')
            finally:
                sys.modules.pop('test_profile_sibling', None)

    def test_missing_entry_has_repair_message(self):
        with tempfile.TemporaryDirectory() as folder:
            self.assertIn('Run Location Map Repair', self.run_command(merge_profile(''), pathlib.Path(folder)))

    def test_unrecognized_old_block_is_not_silently_replaced(self):
        with self.assertRaises(ValueError):
            merge_profile('# Location Map native startup\npython3 unrelated.py\n')
