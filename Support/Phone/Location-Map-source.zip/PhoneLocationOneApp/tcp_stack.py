"""Userspace IPv6/TCP bridge, adapted from pymobiledevice3 11.49.1.

Original source: pymobiledevice3/remote/userspace_tunnel.py. Source and license
are preserved in UPSTREAM/. Adaptations: standalone imports, raw IPv6 without
OS TUN headers, bounded mobile socket buffers, and device-only dial restriction.
No privileged interface or global asyncio monkeypatch is used.
"""
from __future__ import annotations
import asyncio
import errno
import logging
import socket
import struct
from contextlib import suppress
from typing import Any, Optional, Protocol, cast
from pmd_net_addr import Ip6Address, Ip6IfAddr, MacAddress
from pmd_pytcp import stack
from pmd_pytcp.lib.interface_layer import InterfaceLayer
from pmd_pytcp.lib.io_backend import register_interface_fd, unregister_interface_fd
from pmd_pytcp.socket import AF_INET6, SHUT_RDWR, SOCK_STREAM
from pmd_pytcp.socket import socket as pytcp_socket
logger = logging.getLogger(__name__)


_ETH_IPV6 = 0x86DD

_STACK_MAC = "02:00:00:00:00:01"

_PEER_MAC = "02:00:00:00:00:02"

INTERFACE_MTU = 16000

# Keep the advertised window valid even if a peer omits TCP window scaling.
# Location messages are small; reliable negotiation takes priority over bulk speed.
MAX_RECV_WINDOW = 65535

BASE_MSS_SEED = 1400

PROBE_TIMER_MS = 1500

MIN_RTO_MS = 200

ACK_DELAY_MS = 1

def throughput_sysctls() -> dict[str, int]:
    """The ``stack.init(sysctls=...)`` entries that tune the tunnel for bulk transfer and latency.

    These ride pmd-pytcp's public sysctls: ``tcp.rcv_wnd_max`` raises the advertised receive
    window for fast downloads; ``tcp.delayed_ack.delay_ms`` drops the delayed-ACK timer so
    interactive request/response services are not stalled by it (:data:`ACK_DELAY_MS`);
    ``net.default.rx_cksum_validate`` turns off the software RX checksum pass (the tunnel is
    AEAD-authenticated, so the RFC 1071 checksum only re-verifies bytes that cannot have been
    corrupted) — measured ~+35% bulk-download throughput on an iOS 17+ DSC fetch.

    Host->device segment sizing is dynamic: RFC 4821/8899 PLPMTUD (``tcp.mtu_probing`` = 2)
    starts every connection at the proven-safe 1340-byte send MSS (``tcp.base_mss`` =
    :data:`BASE_MSS_SEED`) and raises it only through packet sizes the device has actually
    ACKed, so each device/transport converges to its own real forwarding limit with no
    hardcoded per-device size and a worst case equal to the old static 1340 cap.

    Every knob here is guaranteed by the pmd-pytcp version floor in pyproject.toml — no
    capability probing.
    """
    return {
        "tcp.rcv_wnd_max": MAX_RECV_WINDOW,
        "tcp.delayed_ack.delay_ms": ACK_DELAY_MS,
        "tcp.rto.min_ms": MIN_RTO_MS,
        "tcp.default.mtu_probing": 2,
        "tcp.default.base_mss": BASE_MSS_SEED,
        "tcp.plpmtud.default.probe_timer_ms": PROBE_TIMER_MS,
        # Software RX-checksum offload: every packet reaching the stack came through the
        # AEAD-authenticated tunnel and an in-memory socketpair, so the RFC 1071 checksum
        # verifies RAM. TX checksums stay on (the device kernel verifies them).
        "net.default.rx_cksum_validate": False,
    }

SOCKET_BUFFER_SIZE = 128 * 1024

_CHUNK = 65536

RELAY_SOCKET_BUFFER_SIZE = 128 * 1024

LOOPBACK_HEADER = b''

class _AsyncPytcpSocket(Protocol):
    """The async surface pmd-pytcp stack sockets actually expose at runtime.

    pmd-pytcp's public ``socket`` class types ``connect``/``send``/``recv``/``sendto`` as
    synchronous placeholders (they raise ``NotImplementedError`` on the base and are overridden as
    coroutines on the concrete stack sockets), so the awaited calls in this module type-check
    against this protocol rather than the base class."""

    async def connect(self, address: tuple[str, int]) -> None: ...

    async def send(self, data: bytes) -> int: ...

    async def recv(self, bufsize: int = ...) -> bytes: ...

    async def sendto(self, data: bytes, address: tuple[str, int]) -> None: ...

    def bind(self, address: tuple[str, int]) -> None: ...

    def getsockname(self) -> tuple[str, int]: ...

    def shutdown(self, how: int) -> None: ...

    def close(self) -> None: ...

    @property
    def state(self) -> Any: ...

_FIN_EMIT_TIMEOUT = 0.25

_FIN_EGRESS_GRACE = 0.02

_FIN_UNSENT_STATES = frozenset({"SYN_RCVD", "ESTABLISHED", "CLOSE_WAIT"})

def _fin_unsent(psock: _AsyncPytcpSocket) -> bool:
    return getattr(getattr(psock, "state", None), "name", None) in _FIN_UNSENT_STATES

def _mac_to_bytes(mac: str) -> bytes:
    return bytes(int(x, 16) for x in mac.split(":"))

def _eth_header(dst_mac: str, src_mac: str) -> bytes:
    return _mac_to_bytes(dst_mac) + _mac_to_bytes(src_mac) + struct.pack("!H", _ETH_IPV6)

_ETH_HDR_TO_STACK = _eth_header(_STACK_MAC, _PEER_MAC)

_ETH_IPV6_BYTES = struct.pack("!H", _ETH_IPV6)

def _grow_relay_buffers(sock: Any) -> None:
    """Raise an AF_UNIX relay socket's buffers to :data:`RELAY_SOCKET_BUFFER_SIZE` (no-op for other families)."""
    if sock is None or sock.family != getattr(socket, "AF_UNIX", None):
        return
    for option in (socket.SO_SNDBUF, socket.SO_RCVBUF):
        with suppress(OSError):
            sock.setsockopt(socket.SOL_SOCKET, option, RELAY_SOCKET_BUFFER_SIZE)

def _packet_socketpair() -> tuple[socket.socket, socket.socket]:
    """A connected datagram socket pair preserving packet boundaries (one send == one recv).
    Unix uses an AF_UNIX SOCK_DGRAM socketpair; Windows (no such socketpair) uses a connected
    localhost UDP pair."""
    try:
        return socket.socketpair(socket.AF_UNIX, socket.SOCK_DGRAM)
    except (AttributeError, OSError):
        a = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        b = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        a.bind(("127.0.0.1", 0))
        b.bind(("127.0.0.1", 0))
        a.connect(b.getsockname())
        b.connect(a.getsockname())
        return a, b

class UserspaceTun:
    """Tunnel interface backed by a PyTCP L2 stack — the userspace stand-in for
    ``pytun_pmd3.TunTapDevice`` (same ``mtu``/``addr`` attributes and ``write`` call; ``up`` and
    ``close`` are coroutines and reads go through ``async_read``, which
    :meth:`RemotePairingTunnel.start_tunnel` / ``tun_read_task`` handle).

    PyTCP's stack is a process-global singleton, so one tunnel per process is supported
    (the normal case)."""

    def __init__(self, interface_name: str = "utun-userspace") -> None:
        self.name = interface_name
        self._mtu = 1500
        self._addr: Optional[str] = None
        self._ifidx: Optional[int] = None
        self._closed = False
        self._send_error_logged = False
        self._peer, self._pend = _packet_socketpair()
        for s in (self._peer, self._pend):
            with suppress(OSError):
                s.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, SOCKET_BUFFER_SIZE)
                s.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, SOCKET_BUFFER_SIZE)
        # Both directions run on the event loop (async_read via loop.sock_recv, write via a
        # direct non-blocking send), so neither end may block the loop.
        self._peer.setblocking(False)

    # --- TunTapDevice-compatible surface ---
    @property
    def mtu(self) -> int:
        return self._mtu

    @mtu.setter
    def mtu(self, value: int) -> None:
        self._mtu = int(value)

    @property
    def addr(self) -> Optional[str]:
        return self._addr

    @addr.setter
    def addr(self, address: str) -> None:
        self._addr = address

    async def up(self) -> None:
        self._mtu = min(self._mtu, INTERFACE_MTU)

        if not getattr(stack, "_pmd3_inited", False):
            # accept_dad off (point-to-point link, no DAD peer) + the throughput sysctls
            # (public PyTCP knobs; omitted automatically on a PyTCP too old to have them).
            sysctls = {"icmp6.default.accept_dad": 0, **throughput_sysctls()}
            stack.init(sysctls=sysctls)
            stack._pmd3_inited = True  # type: ignore[attr-defined]
        register_interface_fd(self._pend)
        self._ifidx = stack.add_interface(
            fd=self._pend.fileno(),
            layer=InterfaceLayer.L2,
            mac_address=MacAddress(_STACK_MAC),
            mtu=self._mtu,
            ip6_support=True,
            ip6_host=Ip6IfAddr(f"{self._addr}/64"),
            ip6_lla_autoconfig=True,
            ip6_gua_autoconfig=False,
            ip4_support=False,
        )
        await stack.start()  # pyright: ignore[reportGeneralTypeIssues]  # pmd-pytcp types start() as sync; it is a coroutine at runtime
        # The interface address is installed by the stack's own tasks shortly AFTER start()
        # returns; until it lands, source-address selection finds no local host and a stack
        # connect fails with gaierror. Today the dial plane's relay hop happens to
        # add enough event-loop round trips to win that race, but nothing guarantees it — and
        # an embedder calling connect_tcp() right after aopen() has no such slack. The tun is
        # not "up" until its address is actually usable, so wait for it (yielding, not
        # sleeping: the install normally lands within a loop tick or two).
        target = Ip6Address(self._addr)
        deadline = asyncio.get_running_loop().time() + 5
        while not any(host.address == target for host in stack.local_ip6_hosts()):
            if asyncio.get_running_loop().time() > deadline:
                raise RuntimeError(
                    f"The userspace tunnel address {self._addr} was not assigned within 5 seconds."
                )
            await asyncio.sleep(0)
        logger.debug("userspace tunnel up: pytcp L2 iface=%s addr=%s/64 mtu=%s", self._ifidx, self._addr, self._mtu)

    def set_peer(self, device_addr: str) -> None:
        """Install a static neighbor for the device (point-to-point; skips ND)."""
        assert self._ifidx is not None
        stack.neighbor.interface(self._ifidx).add(ip=Ip6Address(device_addr), mac=MacAddress(_PEER_MAC))

    def write(self, data: bytes) -> None:
        # inbound (device -> stack): strip pmd3 loopback header, add Ethernet, enqueue. The
        # socket is non-blocking; a full buffer drops the packet (tunnel loss, TCP recovers).
        ipv6 = data[len(LOOPBACK_HEADER) :] if data[: len(LOOPBACK_HEADER)] == LOOPBACK_HEADER else data
        try:
            self._peer.send(_ETH_HDR_TO_STACK + ipv6)
        except BlockingIOError:
            pass  # Linux: the buffer is full
        except OSError as e:
            if e.errno == errno.ENOBUFS:
                return  # macOS: the buffer is full
            # Any other error (e.g. EMSGSIZE) fails again on every retransmission, so the
            # connection stalls for good: say why, once.
            if not self._send_error_logged:
                self._send_error_logged = True
                logger.warning("userspace tunnel dropped a %d-byte packet from the device: %s", len(ipv6), e)

    async def async_read(self) -> bytes:
        # outbound (stack -> device): await an Ethernet frame off the stack's socketpair and
        # return its raw IPv6 payload (no loopback header — tun_read_task checks the version
        # nibble). stop_tunnel() ends tun_read_task by cancelling it before close() releases the
        # socketpair: closing a socket under a pending sock_recv() would not wake it.
        while not self._closed:
            frame = await asyncio.get_running_loop().sock_recv(self._peer, 65535)
            if len(frame) < 14 or frame[12:14] != _ETH_IPV6_BYTES:
                continue
            return frame[14:]
        return b""

    async def async_read_batch(self) -> list[bytes]:
        """Await at least one outbound frame, then greedily drain every further frame already
        queued on the socketpair, returning their raw IPv6 payloads in arrival order.

        One event-loop wakeup services a whole egress burst — the userspace counterpart of the
        kernel tun's ``_tun_read_loop_via_reader`` batch-drain. Paying a loop reschedule per
        MSS-sized packet caps uploads at a few thousand packets/s, because the same loop also
        runs the pytcp stack. ``stop_tunnel()`` ends ``tun_read_task`` by cancelling it before
        ``close()`` releases the socketpair (closing a socket under a pending ``sock_recv()`` would
        not wake it)."""
        frame = await asyncio.get_running_loop().sock_recv(self._peer, 65535)
        packets: list[bytes] = []
        while True:
            if len(frame) > 14 and frame[12:14] == _ETH_IPV6_BYTES:
                packets.append(frame[14:])
            try:
                frame = self._peer.recv(65535)
            except (BlockingIOError, InterruptedError):
                return packets

    async def connect_tcp(self, addr: str, port: int) -> _AsyncPytcpSocket:
        """Open a PyTCP TCP socket connected to (addr, port) over this stack."""
        s = cast(_AsyncPytcpSocket, pytcp_socket(AF_INET6, SOCK_STREAM))
        await s.connect((addr, port))
        return s

    async def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        # Stop the stack first (clean teardown against live fds: loop readers/writers are
        # removed, worker tasks cancelled and awaited), then release the socketpair. No
        # thread-wakeup gymnastics remain — the pure-asyncio stack has nothing parked off-loop.
        try:
            await stack.stop()  # pyright: ignore[reportGeneralTypeIssues]  # pmd-pytcp types stop() as sync; it is a coroutine at runtime
        except Exception:
            logger.debug("error stopping pytcp stack", exc_info=True)
        finally:
            # Clear the init marker even when stop() raised: a later open->close->open cycle
            # must re-run stack.init() rather than reuse a half-stopped stack.
            stack._pmd3_inited = False  # type: ignore[attr-defined]
        unregister_interface_fd(self._pend)
        for s in (self._peer, self._pend):
            with suppress(Exception):
                s.close()

class UserspaceDialPlane:
    """Provides an ``asyncio.open_connection``-compatible :meth:`dial` that bridges device-bound
    connections to PyTCP sockets.

    Each dial is a ``socket.socketpair()``: the caller gets one end, a relay task pumps the other
    against a PyTCP socket. There is no listener, so no other process can ever reach the device's
    services through the relay, and nothing depends on how the platform completes a connect
    (iSH's AF_UNIX connect blocks until accept, which deadlocked a same-loop listener, #2068).
    The caller still gets a real socket, as ``ServiceConnection`` requires.

    Pass :meth:`dial` to ``RemoteServiceDiscoveryService(open_connection=...)`` so ONLY connections
    made through that RSD are relayed. This deliberately does NOT monkeypatch the process-global
    ``asyncio.open_connection``: a library consumer who establishes a userspace tunnel keeps the
    stdlib function untouched, so unrelated connections elsewhere in their process are unaffected.

    Use as an async context manager so the relays are torn down on exit."""

    def __init__(self, tun: UserspaceTun, device_addr: str) -> None:
        self._tun = tun
        self._device_addr = str(device_addr)
        self._relay_tasks: set[asyncio.Task[None]] = set()  # in-flight relays, cancelled on exit
        self._closing = False  # teardown began; no new relay may start
        self._closed_socks: set[_AsyncPytcpSocket] = set()  # closed, FIN not yet acknowledged

    async def __aenter__(self) -> UserspaceDialPlane:
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        self._closing = True
        # A relay parked on device traffic never finishes on its own (issue #1756), so cancel
        # them all. Cancelling here (instead of leaving orphan tasks for the loop's shutdown to
        # cancel) also guarantees each handler's psock cleanup runs while the stack is still
        # up, and that no relay task outlives the dial plane. Nothing can join _relay_tasks
        # after the first snapshot (_closing was set before any await in this method, and dial()
        # checks it in the await-free step that spawns a relay), but repeat the cancel a few
        # times anyway: on Python <= 3.11 a cancellation racing an inner future's completion can
        # be swallowed (the old wait_for behavior), and a survivor here would park __aexit__
        # forever.
        for _ in range(3):
            if not self._relay_tasks:
                break
            for task in list(self._relay_tasks):
                task.cancel()
            await asyncio.gather(*list(self._relay_tasks), return_exceptions=True)
        # close() only queues the FIN. The caller stops the stack right after this returns, so
        # without this wait the FIN of every connection closed just before teardown (a CLI
        # command's last service connection) never left, and the device kept the connection:
        # notification_proxy went on holding a notification state for a client long gone.
        # The device's ACK cannot be awaited: nothing is received any more at this point.
        if self._closed_socks:
            deadline = asyncio.get_running_loop().time() + _FIN_EMIT_TIMEOUT
            while any(_fin_unsent(psock) for psock in self._closed_socks):
                if asyncio.get_running_loop().time() > deadline:
                    break
                await asyncio.sleep(0.001)
            await asyncio.sleep(_FIN_EGRESS_GRACE)
        self._closed_socks.clear()

    async def _relay_handler(self, port: int, creader: asyncio.StreamReader, cwriter: asyncio.StreamWriter) -> None:
        try:
            psock = await self._tun.connect_tcp(self._device_addr, port)
        except Exception:
            logger.debug("relay connect_tcp(%s:%s) failed", self._device_addr, port, exc_info=True)
            cwriter.close()
            return
        except BaseException:
            # Cancellation (dial-plane teardown) while connecting: the accepted transport must
            # still be closed, or it stays attached to the relay server and __aexit__ hangs in
            # Server.wait_closed() (which waits for all attached connections since 3.12.1).
            cwriter.close()
            raise

        # Both pump directions are plain awaits on the same event loop the stack runs on: a
        # cancelled handler cancels the pumps at their await points, so nothing can stay
        # parked past teardown (the failure mode that used to require the rx-pump thread,
        # its 1 s poll and the daemon teardown thread — #1756).

        async def client_to_device() -> None:
            try:
                while True:
                    data = await creader.read(_CHUNK)
                    if not data:
                        break
                    await psock.send(data)
            except Exception:
                pass
            finally:
                # The client is gone — nothing in pymobiledevice3 half-closes its side
                # (every ServiceConnection teardown is a full close), so no device byte can
                # ever be delivered again. Fully close the pytcp socket: the FIN still goes
                # out (services that treat EOF as "finish and close" behave exactly as with
                # the previous SHUT_WR half-close), but the session is now ORPHANED, so a
                # device that neither answers nor FINs is reaped by pmd-pytcp's FIN_WAIT_2
                # orphan timer instead of pinning the session — and this handler — forever.
                # A mere half-close kept the socket open (a reader existed: device_to_client)
                # and the reaper is deliberately orphan-only, so abandoned relays accumulated
                # for the tunnel's lifetime (measured: 24 of 30 abandoned service connections
                # parked at psock.recv() until teardown). pmd-pytcp >= 0.3.4 wakes the pending
                # recv() on the session's death, letting the whole handler finish promptly.
                with suppress(Exception):
                    psock.close()

        async def device_to_client() -> None:
            try:
                while True:
                    data = await psock.recv(_CHUNK)
                    if not data:
                        break
                    cwriter.write(data)
                    await cwriter.drain()
            except Exception:
                pass
            finally:
                # Mirror of the half-close above: the device's EOF must reach the client, or
                # client_to_device keeps waiting on a client that has no reason to close.
                with suppress(Exception):
                    if cwriter.can_write_eof():
                        cwriter.write_eof()

        try:
            await asyncio.gather(client_to_device(), device_to_client())
        finally:
            with suppress(Exception):
                cwriter.close()
            # Socket teardown is sync and loop-safe now (no FSM lock to wedge on — the whole
            # stack runs on this loop).
            with suppress(Exception):
                psock.shutdown(SHUT_RDWR)
            with suppress(Exception):
                psock.close()
            self._closed_socks = {sock for sock in self._closed_socks if _fin_unsent(sock)}
            self._closed_socks.add(psock)

    async def dial(self, host: Optional[str] = None, port: Optional[int] = None, **kwargs: Any):
        """``asyncio.open_connection``-compatible dialer passed to the RSD via ``open_connection=``.

        Connections to the device's tunnel address are relayed through the userspace stack;
        everything else falls through to the stdlib ``asyncio.open_connection`` unchanged."""
        if host is not None and str(host) == self._device_addr:
            assert port is not None
            if self._closing:
                raise ConnectionError("userspace dial plane is closed")
            client, relay = socket.socketpair()
            _grow_relay_buffers(client)
            _grow_relay_buffers(relay)
            writer: Optional[asyncio.StreamWriter] = None
            try:
                reader, writer = await asyncio.open_connection(sock=client, **kwargs)
                creader, cwriter = await asyncio.open_connection(sock=relay)
            except BaseException:
                if writer is not None:
                    writer.close()
                client.close()
                relay.close()
                raise
            if self._closing:
                # Teardown began while the streams were being set up.
                writer.close()
                cwriter.close()
                raise ConnectionError("userspace dial plane is closed")
            task = asyncio.create_task(self._relay_handler(port, creader, cwriter), name=f"userspace-relay-{port}")
            self._relay_tasks.add(task)
            task.add_done_callback(self._relay_tasks.discard)
            # A relay cancelled before its first step never runs its own cleanup.
            task.add_done_callback(lambda _: cwriter.close())
            return reader, writer
        raise ValueError("The dialer only connects to this device tunnel")
