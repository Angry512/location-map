"""Portable native-UI regressions. No UIKit, phone, network, or browser calls.

Run: python3 -B tests_ui.py
Passing these checks does not verify a-Shell's libffi callbacks or presentation.
"""

import queue
import threading
import unittest
from unittest.mock import patch

import ui_native as ui


IDLE = {"state": "idle", "message": "Ready", "fresh": False}
ACTIVE = {"state": "active", "fresh": True, "confirmed_age_ms": 50,
          "message": "Recent developer acknowledgment", "lat": 40.7, "lon": -74.0}


class PointTests(unittest.TestCase):
    def test_valid_bounds_and_field_names(self):
        self.assertEqual(ui._point((90, -180)), (90., -180.))
        self.assertEqual(ui._point({"latitude": 40.7, "longitude": -74}), (40.7, -74.))

    def test_invalid_points(self):
        for value in ((91, 0), (0, 181), (float("nan"), 0), (True, 0),
                      ("40", -74), None, {}, (1, 2, 3)):
            with self.subTest(value=value):
                self.assertIsNone(ui._point(value))


class FreshnessTests(unittest.TestCase):
    def test_recent_ack_does_not_require_independent_gps_age(self):
        self.assertEqual(ui._normalize_snapshot(ACTIVE)["state"], "active")

    def test_stale_or_missing_ack_is_unconfirmed(self):
        variants = ({"fresh": False}, {"confirmed_age_ms": 12000},
                    {"confirmed_age_ms": None}, {"confirmed_age_ms": True},
                    {"confirmed_age_ms": -1}, {"confirmed_age_ms": float("nan")})
        for changes in variants:
            with self.subTest(changes=changes):
                self.assertEqual(ui._normalize_snapshot(dict(ACTIVE, **changes))["state"], "error")

    def test_optional_gps_age_is_checked_only_when_present(self):
        self.assertEqual(ui._normalize_snapshot(dict(ACTIVE, position_age_ms=20))["state"], "active")
        for age in (None, True, -1, 12000, float("inf")):
            self.assertEqual(ui._normalize_snapshot(dict(ACTIVE, position_age_ms=age))["state"], "error")

    def test_ui_delivery_time_counts_against_lease(self):
        self.assertEqual(ui._normalize_snapshot(ACTIVE, 11949)["state"], "active")
        self.assertEqual(ui._normalize_snapshot(ACTIVE, 11950)["state"], "error")

    def test_malformed_snapshot_never_claims_active(self):
        for value in (None, [], {}, {"state": "unexpected"}):
            self.assertEqual(ui._normalize_snapshot(value)["state"], "error")


class ModelTests(unittest.TestCase):
    def setUp(self):
        self.model = ui._UIModel()
        self.model.receive(IDLE, 1)

    def test_selection_only_creates_a_draft(self):
        self.assertTrue(self.model.select((40.7, -74)))
        self.assertEqual(self.model.state, "idle")
        self.assertIsNone(self.model.pending)
        self.assertTrue(self.model.view()["simulate_visible"])
        self.assertTrue(self.model.view()["simulate_enabled"])
        self.assertFalse(self.model.view()["stop_visible"])

    def test_queued_set_waits_for_actual_active_reply(self):
        self.model.select((40.7, -74))
        self.model.begin("set")
        self.model.receive(IDLE, 2)
        self.assertNotEqual(self.model.view()["title"], "Simulating")
        self.assertEqual(self.model.pending, "set")
        self.assertTrue(self.model.view()["stop_enabled"])
        self.model.receive(ACTIVE, 3)
        self.assertEqual(self.model.view()["title"], "Simulating")
        self.assertIsNone(self.model.pending)
        self.assertTrue(self.model.view()["stop_visible"])

    def test_background_clears_active_until_fresh_foreground_reply(self):
        self.model.receive(ACTIVE, 2)
        self.model.foreground = False
        self.model.invalidate()
        self.assertNotEqual(self.model.view()["title"], "Simulating")
        self.assertFalse(self.model.view()["stop_enabled"])
        self.model.foreground = True
        self.assertNotEqual(self.model.view()["title"], "Simulating")
        self.model.receive(ACTIVE, 3)
        self.assertEqual(self.model.view()["title"], "Simulating")

    def test_new_draft_preserves_stop_and_cancel_restores_active_point(self):
        self.model.receive(ACTIVE, 2)
        self.model.select((41, -73))
        self.assertTrue(self.model.view()["simulate_visible"])
        self.assertTrue(self.model.view()["stop_visible"])
        self.model.cancel_selection()
        self.assertEqual(self.model.selected, (40.7, -74.))
        self.assertFalse(self.model.draft)

    def test_stop_waits_for_idle_and_clears_selection(self):
        self.model.receive(ACTIVE, 2)
        self.model.begin("stop")
        self.model.receive(ACTIVE, 3)
        self.assertEqual(self.model.view()["title"], "Stopping...")
        self.model.receive(IDLE, 4)
        self.assertIsNone(self.model.selected)
        self.assertIsNone(self.model.pending)
        self.assertFalse(self.model.view()["stop_visible"])

    def test_previous_session_error_keeps_stop_available(self):
        self.model.receive({"state": "error", "message": "Previous session unconfirmed"}, 2)
        self.assertEqual(self.model.view()["title"], "Not confirmed")
        self.assertTrue(self.model.view()["stop_visible"])
        self.assertTrue(self.model.view()["stop_enabled"])


class NativeHandoffTests(unittest.TestCase):
    def make_screen(self):
        # Construct only the Python handoff layer, without calling _ObjC().
        screen = object.__new__(ui.NativeMapScreen)
        screen.bridge = type("FakeBridge", (), {"require_main": lambda _self: None})()
        screen._lock = threading.Lock()
        screen._generation, screen._foreground = 2, True
        screen._closed, screen._wake = threading.Event(), threading.Event()
        screen._update_queued = True
        screen.model = ui._UIModel()
        screen.renders = []
        screen._render = lambda: screen.renders.append(screen.model.view())
        return screen

    def test_pre_background_generation_cannot_restore_active(self):
        screen = self.make_screen()
        screen._latest = (ACTIVE, 1, 100, 100)
        with patch.object(ui.time, "monotonic", return_value=100):
            screen._consume_status()
        self.assertFalse(screen.renders)
        self.assertNotEqual(screen.model.view()["title"], "Simulating")

    def test_late_or_background_delivery_is_ignored(self):
        for foreground, completed in ((True, 90), (False, 100)):
            screen = self.make_screen()
            screen._foreground = foreground
            screen._latest = (ACTIVE, 2, completed, completed)
            with patch.object(ui.time, "monotonic", return_value=100):
                screen._consume_status()
            self.assertFalse(screen.renders)

    def test_current_foreground_delivery_updates_native_view_model(self):
        screen = self.make_screen()
        screen._latest = (ACTIVE, 2, 100, 100)
        with patch.object(ui.time, "monotonic", return_value=100):
            screen._consume_status()
        self.assertEqual(screen.renders[-1]["title"], "Simulating")

    def test_native_actions_reach_controller_only_through_worker(self):
        screen = self.make_screen()
        screen._commands = queue.Queue(maxsize=8)
        screen.model.receive(IDLE, 1)
        screen.model.select((40.7, -74))
        calls = []

        class Controller:
            def set(self, latitude, longitude):
                calls.append(("set", latitude, longitude))

            def stop(self):
                calls.append(("stop",))

            def snapshot(self):
                screen._closed.set()
                return IDLE

        screen.controller = Controller()
        screen._queue_status = lambda *_args: None
        screen._simulate_pressed(None)
        screen._stop_pressed(None)
        self.assertEqual(calls, [], "A UIKit action must not perform engine work inline")
        screen._run()
        self.assertEqual(calls, [("set", 40.7, -74.), ("stop",)])


if __name__ == "__main__":
    unittest.main(verbosity=2)
