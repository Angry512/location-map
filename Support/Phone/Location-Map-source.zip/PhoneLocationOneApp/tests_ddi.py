"""Reboot recovery tests use local mock wire peers and a mock Apple responder."""
import asyncio
from contextlib import asynccontextmanager
import os
from pathlib import Path
import plistlib
import struct
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "vendor"))

import ddi
import services
from tests_services import MockServices, pipe


def asset_fixture(directory):
    manifest = {}
    payloads = {}
    for index, (key, name) in enumerate(ddi.PAYLOADS):
        data = (bytes([index + 1]) * 180000) if name == "image" else bytes([index + 1]) * 350
        path = name + ".bin"
        Path(directory, path).write_bytes(data)
        payloads[name] = data
        manifest[key] = {"Info": {"Path": path, "Personalize": name != "image"},
                         "Digest": bytes([index + 5]) * 48}
    identity = {
        "Info": {"Variant": "Developer Disk Image Cryptex"}, "Manifest": manifest,
        "Cryptex1,ChipID": "0x6020", "Cryptex1,ProductClass": "0x1",
        "Cryptex1,Type": 1, "Cryptex1,SubType": 2, "Cryptex1,UseProductClass": True,
        "Cryptex1,NonceDomain": 4, "Cryptex1,Version": "1", "Cryptex1,PreauthorizationVersion": "1",
    }
    Path(directory, "BuildManifest.plist").write_bytes(plistlib.dumps({"BuildIdentities": [identity]}))
    return identity, payloads


class MockCryptex(MockServices):
    def __init__(self):
        super().__init__()
        self.cryptex_port = None
        self.installed = False
        self.version = "27.0.1"
        self.routines = []
        self.uploads = {}
        self.descriptors = {}
        self.tss_ticket = b"mock-fresh-device-ticket"
        self.nonces = [b"a" * 32, b"a" * 32]
        self.ecids = [0x1122334455667788, 0x1122334455667788]
        self.next_nonce = 0
        self.next_chip = 0
        self.install_signed_index = False
        self.data_lengths = []
        self.errors = []
        self.reject_install = False

    async def start(self):
        server = await asyncio.start_server(
            lambda r, w: self._guard(self.handle_cryptex, r, w), "127.0.0.1", 0)
        self.servers.append(server)
        self.cryptex_port = server.sockets[0].getsockname()[1]
        return await super().start()

    async def dial(self, host, port):
        if host == "fd00::1" and port == self.cryptex_port:
            return await asyncio.open_connection("127.0.0.1", port)
        return await super().dial(host, port)

    def discovery_info(self):
        info = super().discovery_info()
        info["Properties"]["OSVersion"] = self.version
        info["Services"][ddi.CRYPTEX_SERVICE] = {"Port": str(self.cryptex_port), "Properties": {
            "UsesRemoteXPC": True, "Features": ["CryptexInstall", "ReadIdentifiers"]}}
        return info

    def response(self, routine):
        if routine == "copy-installed":
            entries = [{"remote-cryptex-identifier": ddi.DDI_IDENTIFIER,
                        "remote-cryptex-version": "mock-ddi-1"}] if self.installed else []
            return {"error": 0, "argv": {"remote-cryptex-array": entries}}
        if routine == "read-personalization-id":
            ecid = self.ecids[min(self.next_chip, len(self.ecids) - 1)]
            self.next_chip += 1
            return {"argv": {"img4_chip_chip": 0x8120, "img4_chip_ecid": ecid,
                             "img4_chip_cpro": True}}
        if routine == "get-nonce":
            nonce = self.nonces[min(self.next_nonce, len(self.nonces) - 1)]
            self.next_nonce += 1
            return {"error": 0, "argv": {"nonce": b"\0\0" + nonce + struct.pack("<I", len(nonce))}}
        raise AssertionError("Unexpected cryptex routine")

    async def handle_cryptex(self, reader, writer):
        try:
            await self._handle_cryptex(reader, writer)
        except (asyncio.IncompleteReadError, ConnectionError):
            raise
        except Exception as error:
            self.errors.append(error)
            raise

    async def _handle_cryptex(self, reader, writer):
        assert await reader.readexactly(24) == services.HTTP2_PREFACE
        # A small initial stream window forces the uploader to pump WINDOW_UPDATE.
        writer.write(services._h2_frame(4, 0, struct.pack(">HI", 4, 4096)))
        await writer.drain()
        connection_window = 65535
        stream_windows = {}
        root = bytearray()
        files = {}
        install_id = None
        while True:
            header = await reader.readexactly(9)
            size = int.from_bytes(header[:3], "big")
            assert size <= 16384
            kind, flags = header[3:5]
            stream = int.from_bytes(header[5:9], "big")
            payload = await reader.readexactly(size)
            if kind == 4 and not flags & 1:
                writer.write(services._h2_frame(4, 0, flags=1))
            if kind == 1 and stream >= 5:
                files[stream] = {"id": None, "data": bytearray()}
            if kind != 0:
                await writer.drain()
                continue
            stream_windows.setdefault(stream, 4096)
            connection_window -= size
            stream_windows[stream] -= size
            assert connection_window >= 0 and stream_windows[stream] >= 0, "Sender exceeded HTTP/2 window"
            if size:
                self.data_lengths.append(size)
                writer.write(services._h2_frame(8, 0, struct.pack(">I", size)))
                writer.write(services._h2_frame(8, stream, struct.pack(">I", size)))
                connection_window += size
                stream_windows[stream] += size
            if stream >= 5:
                file = files[stream]
                if file["id"] is None:
                    magic, xflags, length, transfer_id = struct.unpack("<IIQQ", payload)
                    assert (magic, xflags, length) == (0x29B00B92, 0x100001, 0)
                    file["id"] = transfer_id
                else:
                    file["data"].extend(payload)
                if flags & 1:
                    transfer_id = file["id"]
                    name, expected = self.descriptors[transfer_id]
                    assert len(file["data"]) == expected
                    self.uploads[name] = bytes(file["data"])
                    writer.write(services._h2_frame(3, stream, struct.pack(">I", 0)))
                    if len(self.uploads) == 5:
                        response = {"error": 5 if self.reject_install else 0}
                        if not self.reject_install:
                            self.installed = True
                        writer.write(services._h2_frame(0, 3, services._xpc_wrapper(
                            response, flags=0x20101, message_id=install_id)))
            elif stream == 1:
                root.extend(payload)
                while len(root) >= 24:
                    magic, _, length, identifier = struct.unpack("<IIQQ", root[:24])
                    assert magic == 0x29B00B92 and length <= services.MAX_XPC
                    if len(root) < 24 + length:
                        break
                    body = bytes(root[24:24 + length])
                    del root[:24 + length]
                    if not body:
                        continue
                    decoder = services._XpcReader(body)
                    assert decoder.take(8) == struct.pack("<II", 0x42133742, 5)
                    request = decoder.object()
                    if not request:
                        continue
                    routine = request["routine"]
                    self.routines.append(routine)
                    if routine == "install":
                        install_id = identifier
                        args = request["argv"]
                        self.install_signed_index = struct.pack("<Iq", 0x3000, 10) in body
                        assert args["image-type-index"] == 10 and args["client-version"] == 3
                        for name in ("image", "trustcache", "im4m", "info", "volumehash"):
                            descriptor = args[name]
                            assert isinstance(descriptor, services.XpcFileTransfer)
                            self.descriptors[descriptor.transfer_id] = (name, descriptor.size)
                    else:
                        writer.write(services._h2_frame(0, 3, services._xpc_wrapper(
                            self.response(routine), flags=0x20101, message_id=identifier)))
            await writer.drain()


@asynccontextmanager
async def cryptex_peer():
    peer = await MockCryptex().start()
    try:
        yield peer
    finally:
        await peer.aclose()


class DdiTests(unittest.IsolatedAsyncioTestCase):
    def apple_response(self, captured):
        def post(body):
            captured.append(plistlib.loads(body))
            return b"STATUS=0&MESSAGE=SUCCESS&REQUEST_STRING=" + plistlib.dumps(
                {"Cryptex1,Ticket": b"mock-fresh-device-ticket"})
        return post

    async def test_current_nonce_personalization_five_uploads_and_final_confirmation(self):
        with tempfile.TemporaryDirectory() as directory:
            identity, payloads = asset_fixture(directory)
            original_files = set(os.listdir(directory))
            captured = []
            async with cryptex_peer() as peer:
                with mock.patch.object(ddi, "_post_tss", side_effect=self.apple_response(captured)):
                    result = await ddi.prepare_ddi(peer.dial, "fd00::1", peer.rsd_port, directory)
                self.assertEqual(result["identifier"], ddi.DDI_IDENTIFIER)
                self.assertEqual(peer.uploads, {**payloads, "im4m": peer.tss_ticket})
                self.assertTrue(peer.install_signed_index)
                self.assertGreater(len(peer.data_lengths), 40)
                self.assertLessEqual(max(peer.data_lengths), 4096)
                self.assertEqual(peer.errors, [])
                self.assertEqual(peer.routines, ["copy-installed", "read-personalization-id", "get-nonce",
                                                 "read-personalization-id", "get-nonce", "install", "copy-installed"])
            self.assertEqual(set(os.listdir(directory)), original_files)
            self.assertEqual(len(captured), 1)
            request = captured[0]
            self.assertEqual(request["Cryptex1,UDID"], struct.pack(">QQ", 0x8120, 0x1122334455667788))
            self.assertEqual(request["Cryptex1,Nonce"], b"a" * 32)
            self.assertNotIn("Cryptex1,GenericDmg", request)
            self.assertEqual(request["Cryptex1,GenericTrustCache"], {
                "Digest": identity["Manifest"]["Cryptex1,GenericTrustCache"]["Digest"]})
            self.assertNotIn("ApECID", request)

    async def test_existing_ddi_needs_neither_assets_nor_tss(self):
        async with cryptex_peer() as peer:
            peer.installed = True
            with mock.patch.object(ddi, "_post_tss") as post:
                await ddi.prepare_ddi(peer.dial, "fd00::1", peer.rsd_port, "missing-assets")
            post.assert_not_called()
            self.assertEqual(peer.routines, ["copy-installed"])

    async def test_nonce_change_does_not_upload_or_reuse_a_ticket(self):
        with tempfile.TemporaryDirectory() as directory:
            asset_fixture(directory)
            captured = []
            async with cryptex_peer() as peer:
                peer.nonces = [b"a" * 32, b"b" * 32]
                with mock.patch.object(ddi, "_post_tss", side_effect=self.apple_response(captured)):
                    with self.assertRaisesRegex(ddi.DdiError, "nonce changed"):
                        await ddi.prepare_ddi(peer.dial, "fd00::1", peer.rsd_port, directory)
                self.assertNotIn("install", peer.routines)
                self.assertEqual(peer.uploads, {})

    async def test_phone_identity_change_does_not_upload(self):
        with tempfile.TemporaryDirectory() as directory:
            asset_fixture(directory)
            async with cryptex_peer() as peer:
                peer.ecids = [1, 2]
                with mock.patch.object(ddi, "_post_tss", side_effect=self.apple_response([])):
                    with self.assertRaisesRegex(ddi.DdiError, "phone changed"):
                        await ddi.prepare_ddi(peer.dial, "fd00::1", peer.rsd_port, directory)
                self.assertNotIn("install", peer.routines)

    async def test_apple_rejection_never_falls_back_to_an_old_ticket(self):
        with tempfile.TemporaryDirectory() as directory:
            asset_fixture(directory)
            Path(directory, "old.im4m").write_bytes(b"OLD_NONCE_TICKET")
            async with cryptex_peer() as peer:
                with mock.patch.object(ddi, "_post_tss", return_value=b"STATUS=94&MESSAGE=NOT_SIGNED"):
                    with self.assertRaises(ddi.DdiError):
                        await ddi.prepare_ddi(peer.dial, "fd00::1", peer.rsd_port, directory)
                self.assertNotIn("install", peer.routines)

    async def test_older_ios_is_rejected_before_install(self):
        async with cryptex_peer() as peer:
            peer.version = "26.3.1"
            with self.assertRaisesRegex(ddi.DdiError, "26.4"):
                await ddi.prepare_ddi(peer.dial, "fd00::1", peer.rsd_port, "missing-assets")
            self.assertEqual(peer.routines, [])

    async def test_install_negative_ack_is_not_success(self):
        with tempfile.TemporaryDirectory() as directory:
            asset_fixture(directory)
            async with cryptex_peer() as peer:
                peer.reject_install = True
                with mock.patch.object(ddi, "_post_tss", side_effect=self.apple_response([])):
                    with self.assertRaisesRegex(ddi.DdiError, "rejected"):
                        await ddi.prepare_ddi(peer.dial, "fd00::1", peer.rsd_port, directory)
                self.assertFalse(peer.installed)

    def test_manifest_asset_traversal_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            identity, _ = asset_fixture(directory)
            identity["Manifest"]["Cryptex1,GenericDmg"]["Info"]["Path"] = "../outside.bin"
            Path(directory, "BuildManifest.plist").write_bytes(plistlib.dumps({"BuildIdentities": [identity]}))
            with self.assertRaisesRegex(ddi.DdiError, "outside"):
                ddi.load_assets(directory)

    async def test_window_shrink_preserves_spent_credit_and_zero_updates_fail(self):
        wire = (services._h2_frame(4, 0, struct.pack(">HI", 4, 10))
                + services._h2_frame(8, 5, struct.pack(">I", 65535))
                + services._h2_frame(8, 0, struct.pack(">I", 0)))
        connection = services.RemoteXpcConnection(*pipe(wire))
        connection.stream_windows[5] = 100  # The initial window has mostly been spent.
        await connection.frame()
        self.assertEqual(connection.stream_windows[5], 100 + 10 - 65535)
        await connection.frame()
        self.assertEqual(connection.stream_windows[5], 110)
        with self.assertRaisesRegex(services.ProtocolError, "zero"):
            await connection.frame()
        await connection.aclose()

    async def test_uncorrelated_xpc_reply_cannot_acknowledge_an_install(self):
        wire = services._h2_frame(0, 3, services._xpc_wrapper(
            {"error": 0}, flags=0x20101, message_id=99))
        connection = services.RemoteXpcConnection(*pipe(wire))
        with self.assertRaisesRegex(services.ProtocolError, "uncorrelated"):
            await connection.receive_reply(1)
        await connection.aclose()

    def test_tss_uses_fixed_https_destination_and_certificate_validation(self):
        with mock.patch.object(ddi.http.client, "HTTPSConnection") as connection_type:
            response = connection_type.return_value.getresponse.return_value
            response.status = 200
            response.read.return_value = b"mock response"
            self.assertEqual(ddi._post_tss(b"mock request"), b"mock response")
            arguments = connection_type.call_args
            self.assertEqual(arguments.args, ("gs.apple.com", 443))
            context = arguments.kwargs["context"]
            self.assertTrue(context.check_hostname)
            self.assertEqual(context.verify_mode, ddi.ssl.CERT_REQUIRED)
            request = connection_type.return_value.request.call_args
            self.assertEqual(request.args[:2], ("POST", "/TSS/controller?action=2"))
            response.read.assert_called_once_with(ddi.MAX_TSS_RESPONSE + 1)


if __name__ == "__main__":
    unittest.main()
