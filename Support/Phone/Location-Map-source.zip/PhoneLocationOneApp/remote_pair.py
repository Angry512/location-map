"""Existing-pair RemotePairing -> TLS-PSK CDTunnel, for Python 3.13/a-Shell.

Protocol reference: jkcoxson/idevice commit 89702099f4d7552f704f93b4526756abda319ceb,
remote_pairing/{mod,socket,rp_pairing_file,tunnel,tlv}.rs. No new pairing, record
updates, subprocesses, or native dependencies beyond a-Shell's existing crypto.

The original RpPairingFile stores HOST keys only. Such records prove the host to
the peer and establish session encryption, matching the working Rust client;
they cannot authenticate the peer's long-term identity. Connections are therefore
restricted to LocalDevVPN 10.7.0.1 or loopback. If a record additionally contains
trusted peer_identifier + peer_public_key, PV-Msg02 MUST verify against both.
No trust-on-first-use or silent persistence is performed.

After the CDTunnel handshake, reader/writer carry raw IPv6 packets. The owner
must retain this object, and close it to release both TLS and control sockets.
"""

from __future__ import annotations

import asyncio
import base64
from dataclasses import dataclass
import hmac
import ipaddress
import json
from pathlib import Path
import plistlib
import ssl

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ed25519, x25519
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305
from cryptography.hazmat.primitives.kdf.hkdf import HKDF


IO_TIMEOUT = 20.0
MAX_FRAME = 65535
MAX_RECORD = 256 * 1024
MAX_TLV = 16 * 1024
DEFAULT_MTU = 16000
CIPHER = "PSK-AES256-CBC-SHA384"
RP_MAGIC = b"RPPairing"
CD_MAGIC = b"CDTunnel"


class PairingError(Exception):
    """A bounded stage/code only; never contains an upstream payload or key."""

    def __init__(self, stage, code):
        self.stage = stage
        self.code = code
        super().__init__(f"{stage}: {code}")

    @property
    def location_map_hint(self):
        if self.stage == 'connect' and self.code in ('timeout', 'connection_failed'):
            return 'Join Wi-Fi and make sure LocalDevVPN is connected.'
        if self.stage == 'record':
            return 'The phone pairing needs repair.'
        if self.code == 'pairing_rejected':
            return 'The iPhone rejected the pairing. Pairing repair may be needed.'
        return None


def _fail(stage, code):
    raise PairingError(stage, code)


def _path(value, *keys):
    for key in keys:
        if not isinstance(value, dict) or key not in value:
            _fail("control", "unexpected_response")
        value = value[key]
    return value


def _json_bytes(value):
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()


def _json_parse(data, stage):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                _fail(stage, "duplicate_json_key")
            result[key] = value
        return result
    try:
        result = json.loads(data, object_pairs_hook=unique,
                            parse_constant=lambda _: _fail(stage, "invalid_json"))
        if not isinstance(result, dict):
            _fail(stage, "invalid_json")
        return result
    except PairingError:
        raise
    except (ValueError, UnicodeError, RecursionError):
        _fail(stage, "invalid_json")


def _b64(data):
    return base64.b64encode(data).decode("ascii")


def _unb64(value, stage, limit=MAX_TLV):
    if not isinstance(value, str) or len(value) > (limit + 2) // 3 * 4:
        _fail(stage, "invalid_bytes")
    try:
        result = base64.b64decode(value, validate=True)
    except (ValueError, UnicodeError):
        _fail(stage, "invalid_bytes")
    if len(result) > limit:
        _fail(stage, "oversized_bytes")
    return result


def _tlv_encode(entries):
    result = bytearray()
    for kind, data in entries:
        if not 0 <= kind <= 255 or not isinstance(data, bytes) or len(data) > MAX_TLV:
            _fail("pair_verify", "invalid_tlv")
        for offset in range(0, max(1, len(data)), 255):
            part = data[offset:offset + 255]
            result.extend((kind, len(part)))
            result.extend(part)
    if len(result) > MAX_TLV:
        _fail("pair_verify", "oversized_tlv")
    return bytes(result)


def _tlv_decode(data):
    if not isinstance(data, bytes) or len(data) > MAX_TLV:
        _fail("pair_verify", "oversized_tlv")
    result = {}
    offset = 0
    previous = None
    while offset < len(data):
        if offset + 2 > len(data):
            _fail("pair_verify", "truncated_tlv")
        kind, size = data[offset:offset + 2]
        offset += 2
        if offset + size > len(data):
            _fail("pair_verify", "truncated_tlv")
        if kind in result and kind != previous:
            _fail("pair_verify", "duplicate_tlv")
        result[kind] = result.get(kind, b"") + data[offset:offset + size]
        offset += size
        previous = kind
    return result


def _hkdf(secret, info, salt=None):
    return HKDF(algorithm=hashes.SHA512(), length=32, salt=salt, info=info).derive(secret)


def _public(key):
    return key.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)


@dataclass(repr=False)
class _Record:
    identifier: bytes
    private_key: object
    peer_identifier: bytes | None = None
    peer_public_key: object | None = None


def _load_record(path):
    try:
        with Path(path).open("rb") as handle:
            data = handle.read(MAX_RECORD + 1)
        if len(data) > MAX_RECORD:
            _fail("record", "oversized_record")
        value = plistlib.loads(data)
        if not isinstance(value, dict):
            _fail("record", "invalid_record")
        identifier = value.get("identifier")
        private = value.get("private_key")
        public = value.get("public_key")
        if (not isinstance(identifier, str) or not 1 <= len(identifier.encode()) <= 1024
                or "\0" in identifier or not isinstance(private, bytes) or len(private) != 32
                or not isinstance(public, bytes) or len(public) != 32):
            _fail("record", "invalid_host_keys")
        key = ed25519.Ed25519PrivateKey.from_private_bytes(private)
        if not hmac.compare_digest(_public(key.public_key()), public):
            _fail("record", "host_key_mismatch")
        peer_id = value.get("peer_identifier")
        peer_key = value.get("peer_public_key")
        if peer_id is not None or peer_key is not None:
            if (not isinstance(peer_id, str) or not 1 <= len(peer_id.encode()) <= 1024
                    or not isinstance(peer_key, bytes) or len(peer_key) != 32):
                _fail("record", "invalid_peer_identity")
            return _Record(identifier.encode(), key, peer_id.encode(),
                           ed25519.Ed25519PublicKey.from_public_bytes(peer_key))
        return _Record(identifier.encode(), key)
    except PairingError:
        raise
    except Exception:
        raise PairingError("record", "unreadable_record") from None


async def _close(writer):
    if writer is not None:
        writer.close()
        try:
            await asyncio.wait_for(writer.wait_closed(), 2)
        except Exception:
            pass


async def _read_frame(reader, magic, stage):
    header = await asyncio.wait_for(reader.readexactly(len(magic) + 2), IO_TIMEOUT)
    if header[:len(magic)] != magic:
        _fail(stage, "invalid_magic")
    size = int.from_bytes(header[-2:], "big")
    if not 1 <= size <= MAX_FRAME:
        _fail(stage, "invalid_size")
    data = await asyncio.wait_for(reader.readexactly(size), IO_TIMEOUT)
    return _json_parse(data, stage)


async def _write_frame(writer, magic, value, stage):
    data = _json_bytes(value)
    if not 1 <= len(data) <= MAX_FRAME:
        _fail(stage, "invalid_size")
    writer.write(magic + len(data).to_bytes(2, "big") + data)
    await asyncio.wait_for(writer.drain(), IO_TIMEOUT)


class _Control:
    def __init__(self, reader, writer):
        self.reader, self.writer = reader, writer
        self.sequence = 0

    async def send(self, payload, encrypted=False):
        message = {"streamEncrypted" if encrypted else "plain": {"_0": payload}}
        await _write_frame(self.writer, RP_MAGIC,
                           {"message": message, "originatedBy": "host", "sequenceNumber": self.sequence},
                           "control")
        self.sequence += 1

    async def receive(self, encrypted=False):
        frame = await _read_frame(self.reader, RP_MAGIC, "control")
        return _path(frame, "message", "streamEncrypted" if encrypted else "plain", "_0")

    async def pairing(self, data, start_new):
        await self.send({"event": {"_0": {"pairingData": {"_0": {
            "data": _b64(data), "kind": "verifyManualPairing", "startNewSession": start_new}}}}})
        value = await self.receive()
        data = _path(value, "event", "_0")
        if "pairingRejectedWithError" in data:
            _fail("pair_verify", "pairing_rejected")
        data = _unb64(_path(data, "pairingData", "_0", "data"), "pair_verify")
        result = _tlv_decode(data)
        if 7 in result:
            _fail("pair_verify", "pairing_rejected")
        return result

    async def verify(self, record):
        await self.send({"request": {"_0": {"handshake": {"_0": {
            "hostOptions": {"attemptPairVerify": True}, "wireProtocolVersion": 19}}}}})
        _path(await self.receive(), "response", "_1", "handshake", "_0")
        ephemeral = x25519.X25519PrivateKey.generate()
        public = _public(ephemeral.public_key())
        response = await self.pairing(_tlv_encode(((6, b"\x01"), (3, public))), True)
        if response.get(6) != b"\x02" or len(response.get(3, b"")) != 32:
            _fail("pair_verify", "invalid_verify_response")
        peer_public = response[3]
        secret = ephemeral.exchange(x25519.X25519PublicKey.from_public_bytes(peer_public))
        verify_cipher = ChaCha20Poly1305(_hkdf(secret, b"Pair-Verify-Encrypt-Info",
                                             b"Pair-Verify-Encrypt-Salt"))
        peer_authenticated = False
        if 5 in response:
            try:
                peer = _tlv_decode(verify_cipher.decrypt(b"\0\0\0\0PV-Msg02", response[5], b""))
                if record.peer_public_key is not None:
                    identifier = peer.get(1, b"")
                    signature = peer.get(10, b"")
                    if (not hmac.compare_digest(identifier, record.peer_identifier)
                            or len(signature) != 64):
                        _fail("pair_verify", "peer_identity_mismatch")
                    record.peer_public_key.verify(signature, peer_public + identifier + public)
                    peer_authenticated = True
            except PairingError:
                raise
            except Exception:
                raise PairingError("pair_verify", "peer_verification_failed") from None
        elif record.peer_public_key is not None:
            _fail("pair_verify", "missing_peer_proof")
        signature = record.private_key.sign(public + record.identifier + peer_public)
        plaintext = _tlv_encode(((1, record.identifier), (10, signature)))
        encrypted = verify_cipher.encrypt(b"\0\0\0\0PV-Msg03", plaintext, b"")
        response = await self.pairing(_tlv_encode(((6, b"\x03"), (5, encrypted))), False)
        if response.get(6) != b"\x04":
            _fail("pair_verify", "invalid_verify_completion")
        return secret, peer_authenticated

    async def listener(self, secret):
        nonce = bytes(12)  # First encrypted RPC uses sequence 0, LE u64 + 4 zeros.
        request = {"request": {"_0": {"createListener": {
            "key": _b64(secret), "transportProtocolType": "tcp"}}}}
        cipher = ChaCha20Poly1305(_hkdf(secret, b"ClientEncrypt-main"))
        await self.send(_b64(cipher.encrypt(nonce, _json_bytes(request), b"")), encrypted=True)
        encrypted = _unb64(await self.receive(encrypted=True), "listener", MAX_FRAME)
        try:
            cipher = ChaCha20Poly1305(_hkdf(secret, b"ServerEncrypt-main"))
            response = _json_parse(cipher.decrypt(nonce, encrypted, b""), "listener")
        except PairingError:
            raise
        except Exception:
            raise PairingError("listener", "invalid_encrypted_response") from None
        port = _path(response, "response", "_1", "createListener", "port")
        if type(port) is not int or not 1 <= port <= 65535:
            _fail("listener", "invalid_port")
        return port


def _tls_context(secret):
    if not getattr(ssl, "HAS_PSK", False) or not hasattr(ssl.SSLContext, "set_psk_client_callback"):
        _fail("tls", "python_313_psk_required")
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE  # Peer authenticates TLS using the X25519-derived PSK.
    context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_2
    context.set_ciphers(CIPHER)
    context.set_psk_client_callback(lambda hint: ("", secret))
    return context


@dataclass(repr=False)
class Tunnel:
    reader: asyncio.StreamReader
    writer: asyncio.StreamWriter
    client_address: str
    server_address: str
    rsd_port: int
    mtu: int
    peer_authenticated: bool
    _control: _Control

    @property
    def authentication_mode(self):
        return "verified_peer_identity" if self.peer_authenticated else "host_proof_and_session_encryption"

    async def aclose(self):
        try:
            await _close(self.writer)
        finally:
            await _close(self._control.writer)


def _host_allowed(host):
    try:
        return host == "10.7.0.1" or ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


async def open_tunnel(pairing_path, host="10.7.0.1", port=49152):
    """Return an IPv6 CDTunnel using an existing, unmodified XML/binary plist.

    Optional trusted record fields: peer_identifier (str), peer_public_key (32
    bytes). With those fields, an invalid/missing device proof always fails.
    Original host-only records remain usable on the private local VPN endpoint.
    All externally surfaced errors contain fixed stage/code text only.
    """
    if not isinstance(host, str) or not _host_allowed(host):
        _fail("connect", "local_vpn_endpoint_required")
    if type(port) is not int or not 1 <= port <= 65535:
        _fail("connect", "invalid_port")
    record = _load_record(pairing_path)
    control_writer = tls_writer = None
    stage = "connect"
    try:
        reader, control_writer = await asyncio.wait_for(asyncio.open_connection(host, port), IO_TIMEOUT)
        control = _Control(reader, control_writer)
        stage = "pair_verify"
        secret, peer_authenticated = await control.verify(record)
        stage = "listener"
        listener_port = await control.listener(secret)
        stage = "tls"
        reader, tls_writer = await asyncio.wait_for(asyncio.open_connection(
            host, listener_port, ssl=_tls_context(secret), server_hostname="",
            ssl_handshake_timeout=IO_TIMEOUT), IO_TIMEOUT + 1)
        stage = "cdtunnel"
        await _write_frame(tls_writer, CD_MAGIC,
                           {"type": "clientHandshakeRequest", "mtu": DEFAULT_MTU}, stage)
        response = await _read_frame(reader, CD_MAGIC, stage)
        if response.get("type") != "serverHandshakeResponse":
            _fail(stage, "invalid_handshake_type")
        client = _path(response, "clientParameters")
        client_address = str(ipaddress.IPv6Address(_path(client, "address")))
        server_address = str(ipaddress.IPv6Address(_path(response, "serverAddress")))
        mtu, rsd_port = _path(client, "mtu"), _path(response, "serverRSDPort")
        if (type(mtu) is not int or not 1280 <= mtu <= DEFAULT_MTU
                or type(rsd_port) is not int or not 1 <= rsd_port <= 65535):
            _fail(stage, "invalid_tunnel_parameters")
        return Tunnel(reader, tls_writer, client_address, server_address, rsd_port, mtu,
                      peer_authenticated, control)
    except BaseException as exc:
        await _close(tls_writer)
        await _close(control_writer)
        if not isinstance(exc, Exception):
            raise
        if isinstance(exc, PairingError):
            raise
        raise PairingError(stage, "timeout" if isinstance(exc, TimeoutError) else "connection_failed") from None
