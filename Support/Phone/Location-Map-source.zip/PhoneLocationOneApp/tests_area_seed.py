import json
import os
from pathlib import Path
import plistlib
import tempfile
import unittest

from area_seed import decode_seed, AreaSeedWatcher


class AreaTests(unittest.TestCase):
    def test_shared_file_supersedes_the_legacy_inbox_and_preserves_active_guard(self):
        class Controller:
            mode = 'idle'
            def snapshot(self):
                return {'state': self.mode, 'requires_stop': self.mode != 'idle'}
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            legacy, shared = root / 'old.txt', root / 'location-map-seed.txt'
            legacy.write_text('https://maps.apple.com/?ll=1,2')
            os.utime(legacy, (10, 10))
            shared.write_text('https://maps.apple.com/?ll=3,4')
            os.utime(shared, (20, 20))
            controller, seen = Controller(), []
            watcher = AreaSeedWatcher((legacy, shared), root / 'cache', controller, seen.append)
            watcher.tick()
            self.assertEqual(seen, [{'lat': 3.0, 'lon': 4.0}])
            controller.mode = 'active'
            shared.write_text('https://maps.apple.com/?ll=5,6')
            os.utime(shared, (30, 30))
            watcher.tick()
            controller.mode = 'idle'
            watcher.tick()
            self.assertEqual(seen, [{'lat': 3.0, 'lon': 4.0}])

    def test_native_maps_url_and_webloc_parse(self):
        url = 'https://maps.apple.com/?ll=38.9%2C-77.0&q=Current%20Location'
        expected = {'lat': 38.9, 'lon': -77.0}
        self.assertEqual(decode_seed(url.encode()), expected)
        self.assertEqual(decode_seed(plistlib.dumps({'URL': url})), expected)
        self.assertEqual(decode_seed(json.dumps(expected).encode()), expected)

    def test_untrusted_malformed_and_out_of_range_seeds_are_ignored(self):
        for value in (b'https://example.com/?ll=1,2', b'https://maps.apple.com/?ll=91,2',
                      b'https://maps.apple.com/?ll=nan,2', b'partial', b'x' * 17000):
            self.assertIsNone(decode_seed(value))

    def test_active_seed_cannot_be_reused_after_stop(self):
        class Controller:
            mode = 'active'
            def snapshot(self):
                return {'state': self.mode, 'requires_stop': self.mode == 'active'}
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            source, cache = root / 'seed', root / 'area'
            source.write_text('https://maps.apple.com/?ll=1,2')
            controller, seen = Controller(), []
            watcher = AreaSeedWatcher(source, cache, controller, seen.append)
            watcher.tick()
            controller.mode = 'idle'
            watcher.tick()
            self.assertEqual(seen, [])
            self.assertFalse(cache.exists())
            source.write_text('https://maps.apple.com/?ll=38.9,-77')
            watcher.tick()
            self.assertEqual(seen, [{'lat': 38.9, 'lon': -77.0}])
            self.assertEqual(json.loads(cache.read_text())['area'], seen[0])

    def test_partial_file_can_complete_before_next_tick(self):
        class Controller:
            def snapshot(self):
                return {'state': 'idle', 'requires_stop': False}
        with tempfile.TemporaryDirectory() as name:
            root = Path(name)
            source = root / 'seed'
            source.write_bytes(b'<partial')
            seen = []
            watcher = AreaSeedWatcher(source, root / 'cache', Controller(), seen.append)
            watcher.tick()
            self.assertEqual(seen, [])
            source.write_text('https://maps.apple.com/?sll=38.9,-77')
            watcher.tick()
            self.assertEqual(len(seen), 1)


if __name__ == '__main__':
    unittest.main()
