"""Reinstall the bundled Cryptex1 DDI using the current phone's nonce and ECID.

The implementation follows the pinned MIT idevice cryptexd/TSS flow. It supports
the Cryptex DDI protocol used from iOS 26.4, not the older PersonalizedDMG image
mounter. Assets are local; only a normal HTTPS Apple TSS personalization request
leaves the phone. No Apple Account, paid service, old ticket cache or nonce roll
is used. Successful return requires a final copy-installed confirmation.
"""
import asyncio
import http.client
import os
from pathlib import Path
import plistlib
import re
import ssl
import struct
import uuid

import services


CRYPTEX_SERVICE = "com.apple.security.cryptexd.remote"
DDI_IDENTIFIER = "com.apple.MobileAsset.DDI"
PREPARE_TIMEOUT = 600.0
MAX_MANIFEST = 8 * 1024 * 1024
MAX_COMPONENT = 128 * 1024 * 1024
MAX_TSS_RESPONSE = 2 * 1024 * 1024
PAYLOADS = (
    ("Cryptex1,GenericDmg", "image"),
    ("Cryptex1,GenericTrustCache", "trustcache"),
    ("Cryptex1,CryptexInfoPlist", "info"),
    ("Cryptex1,GenericVolume", "volumehash"),
)


class DdiError(services.ServiceError):
    pass


def _uint(value):
    if isinstance(value, bool):
        raise DdiError("A developer-image identity contains an invalid integer.")
    try:
        result = int(value, 16 if value.lower().startswith("0x") else 10) if isinstance(value, str) else value
    except (ValueError, TypeError):
        raise DdiError("A developer-image identity contains an invalid integer.") from None
    if not isinstance(result, int) or not 0 <= result <= 0xFFFFFFFFFFFFFFFF:
        raise DdiError("A developer-image identity contains an invalid integer.")
    return result


def _required(mapping, key):
    if not isinstance(mapping, dict) or key not in mapping:
        raise DdiError("The developer-image identity is incomplete.")
    return mapping[key]


def _bounded_read(path, limit):
    try:
        with open(path, "rb") as source:
            data = source.read(limit + 1)
    except OSError:
        raise DdiError("The bundled developer-image files are unavailable. Reinstall the complete app package.") from None
    if not data or len(data) > limit:
        raise DdiError("A bundled developer-image file is empty or exceeds its size limit.")
    return data


def load_assets(directory):
    root = Path(directory).resolve()
    try:
        manifest = plistlib.loads(_bounded_read(root / "BuildManifest.plist", MAX_MANIFEST))
    except (plistlib.InvalidFileException, ValueError, TypeError, OverflowError):
        raise DdiError("The bundled developer-image manifest is invalid.") from None
    identities = _required(manifest, "BuildIdentities")
    if not isinstance(identities, list):
        raise DdiError("The developer-image manifest has no build identities.")
    candidates = [entry for entry in identities if isinstance(entry, dict)
                  and isinstance(entry.get("Info"), dict)
                  and str(entry["Info"].get("Variant", "")).endswith("Developer Disk Image Cryptex")]
    if len(candidates) != 1:
        raise DdiError("The bundled image does not contain one compatible Cryptex DDI identity.")
    identity = candidates[0]
    payloads = {}
    for key, name in PAYLOADS:
        entry = _required(_required(identity, "Manifest"), key)
        relative = _required(_required(entry, "Info"), "Path")
        if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
            raise DdiError("The developer-image manifest contains an invalid asset path.")
        target = (root / relative).resolve()
        try:
            target.relative_to(root)
        except ValueError:
            raise DdiError("The developer-image manifest points outside its asset directory.") from None
        payloads[name] = _bounded_read(target, MAX_COMPONENT)
    # Validate these before opening an installation connection.
    properties = {
        "Cryptex1,UseProductClass": _required(identity, "Cryptex1,UseProductClass"),
        "MountedCryptex": False,
        "Cryptex1,SubType": _uint(_required(identity, "Cryptex1,SubType")),
        "Cryptex1,NonceDomain": _uint(_required(identity, "Cryptex1,NonceDomain")),
        "Cryptex1,Version": _required(identity, "Cryptex1,Version"),
        "Cryptex1,PreauthVersion": _required(identity, "Cryptex1,PreauthorizationVersion"),
    }
    return identity, payloads, properties


def _udid(chip):
    return struct.pack(">QQ", _uint(_required(chip, "img4_chip_chip")),
                       _uint(_required(chip, "img4_chip_ecid")))


def build_tss_request(identity, chip, nonce):
    if not isinstance(nonce, bytes) or not 16 <= len(nonce) <= 64:
        raise DdiError("The phone returned an invalid developer-image nonce.")
    production = _required(chip, "img4_chip_cpro")
    if not isinstance(production, (bool, int)):
        raise DdiError("The phone returned an invalid production-mode identifier.")
    request = {
        "@HostPlatformInfo": "mac", "@VersionInfo": "libauthinstall-1033.0.2",
        "@UUID": str(uuid.uuid4()).upper(), "@Cryptex1,Ticket": True,
        "Cryptex1,ChipID": _uint(_required(identity, "Cryptex1,ChipID")),
        "Cryptex1,ProductClass": _uint(_required(identity, "Cryptex1,ProductClass")),
        "Cryptex1,Nonce": nonce, "Cryptex1,ProductionMode": bool(production),
        "Cryptex1,UDID": _udid(chip), "Cryptex1,UniqueTagList": b"",
    }
    for key in ("Cryptex1,Type", "Cryptex1,SubType", "Cryptex1,UseProductClass",
                "Cryptex1,NonceDomain", "Cryptex1,Version", "Cryptex1,PreauthorizationVersion"):
        request[key] = _required(identity, key)
    manifest = _required(identity, "Manifest")
    for key, entry in manifest.items():
        if not key.startswith("Cryptex1,") or not isinstance(entry, dict):
            continue
        if entry.get("Info", {}).get("Personalize") is not True:
            continue
        digest = _required(entry, "Digest")
        if not isinstance(digest, bytes) or not digest:
            raise DdiError("A personalized developer-image component has no digest.")
        request[key] = {"Digest": digest}
    return request


def _post_tss(body):
    """Fixed HTTPS destination with normal certificate validation; no redirects."""
    connection = http.client.HTTPSConnection("gs.apple.com", 443, timeout=30,
                                             context=ssl.create_default_context())
    try:
        connection.request("POST", "/TSS/controller?action=2", body=body, headers={
            "Content-Type": 'text/xml; charset="utf-8"', "Cache-Control": "no-cache",
            "User-Agent": "InetURL/1.0",
        })
        response = connection.getresponse()
        if response.status != 200:
            raise DdiError("Apple's developer-image signing service did not accept the request.")
        result = response.read(MAX_TSS_RESPONSE + 1)
        if len(result) > MAX_TSS_RESPONSE:
            raise DdiError("Apple's developer-image signing response exceeded its size limit.")
        return result
    except (OSError, http.client.HTTPException):
        raise DdiError("Could not reach Apple's developer-image signing service securely. Check internet access and retry.") from None
    finally:
        connection.close()


def request_ticket(request):
    try:
        body = plistlib.dumps(request, fmt=plistlib.FMT_XML, sort_keys=False)
        response = _post_tss(body)
        prefix, xml = response.split(b"REQUEST_STRING=", 1)
        fields = prefix.rstrip(b"&").split(b"&")
        if b"STATUS=0" not in fields or b"MESSAGE=SUCCESS" not in fields:
            raise DdiError("Apple did not sign this developer image for the current phone and nonce.")
        result = plistlib.loads(xml)
        ticket = result.get("Cryptex1,Ticket", result.get("ApImg4Ticket"))
        if not isinstance(ticket, bytes) or not 1 <= len(ticket) <= 512 * 1024:
            raise DdiError("Apple's response did not contain a valid developer-image ticket.")
        return ticket
    except DdiError:
        raise
    except Exception:
        raise DdiError("Apple returned an invalid developer-image signing response.") from None


def _unwrap_reply(routine, response):
    if "cferr" in response:
        raise DdiError("The phone rejected the developer-image operation.")
    error = response.get("error", 0)
    if isinstance(error, bool) or not isinstance(error, int) or error != 0:
        raise DdiError("The phone rejected the developer-image operation.")
    if routine == "install" and "error" not in response:
        raise DdiError("The phone did not acknowledge developer-image installation.")
    if "error" not in response and "argv" not in response:
        raise DdiError("The phone returned an incomplete developer-image response.")
    return response.get("argv")


async def _routine(dial, address, port, routine, arguments=None, files=None):
    connection = None
    try:
        reader, writer = await dial(address, port)
        connection = services.RemoteXpcConnection(reader, writer)
        await asyncio.wait_for(connection.start(), 15.0)
        identifier = await connection.request({"routine": routine, "argv": arguments or {}})
        if files:
            for transfer_id, data in files:
                await connection.send_file(transfer_id, data)
        response = await asyncio.wait_for(connection.receive_reply(identifier), 60.0 if files else 15.0)
        return _unwrap_reply(routine, response)
    finally:
        if connection is not None:
            await connection.aclose()


def _installed(response):
    if response is None:
        return None
    if not isinstance(response, dict) or not isinstance(response.get("remote-cryptex-array", []), list):
        raise DdiError("The phone returned an invalid installed-image list.")
    for entry in response.get("remote-cryptex-array", []):
        if isinstance(entry, dict) and entry.get("remote-cryptex-identifier") == DDI_IDENTIFIER:
            return {"identifier": DDI_IDENTIFIER, "version": str(entry.get("remote-cryptex-version", ""))}
    return None


def _nonce(response):
    blob = response.get("nonce") if isinstance(response, dict) else None
    if not isinstance(blob, bytes) or len(blob) < 6:
        raise DdiError("The phone returned an invalid developer-image nonce.")
    length = struct.unpack("<I", blob[-4:])[0]
    if not 16 <= length <= 64 or 2 + length > len(blob) - 4:
        raise DdiError("The phone returned an invalid developer-image nonce.")
    return blob[2:2 + length]


def _require_supported_version(peer):
    properties = peer.get("Properties", {})
    version = properties.get("OSVersion", "") if isinstance(properties, dict) else ""
    match = re.fullmatch(r"(\d+)\.(\d+)(?:\.\d+)*(?:[a-zA-Z0-9 .()-]*)?", version)
    if match is None or tuple(map(int, match.groups()[:2])) < (26, 4):
        raise DdiError("Automatic recovery with this bundled Cryptex image requires iOS 26.4 or later. Older iOS needs its compatible PersonalizedDMG image-mounter flow.")


async def prepare_ddi(dial, server_address, rsd_port, asset_directory):
    """Confirm or personalize/install the bundled DDI, using this device now.

    Reads the live chip identity and nonce, requests a fresh Apple ticket, checks
    both identifiers again before upload, sends five flow-controlled components,
    and confirms the installed identifier. It changes no simulated location.
    No ticket is read from or written to disk, and none is reused after a retry.
    """
    rsd = None

    async def prepare():
        nonlocal rsd
        reader, writer = await dial(server_address, rsd_port)
        rsd = services._Rsd(reader, writer)
        peer = await rsd.discover()
        _require_supported_version(peer)
        entry = peer.get("Services", {}).get(CRYPTEX_SERVICE)
        if not isinstance(entry, dict):
            raise DdiError("The phone did not advertise its developer-image service. Check Developer Mode and reconnect the tunnel.")
        port = _uint(_required(entry, "Port"))
        if not 1 <= port <= 65535:
            raise DdiError("The phone advertised an invalid developer-image service port.")
        properties = entry.get("Properties", {})
        features = properties.get("Features", []) if isinstance(properties, dict) else []
        if features and not {"CryptexInstall", "ReadIdentifiers"}.issubset(features):
            raise DdiError("The phone's developer-image service does not support this recovery flow.")
        rsd.monitor = asyncio.create_task(rsd.keep_open())
        async def invoke(routine, arguments=None, files=None):
            return await _routine(dial, server_address, port, routine, arguments, files)
        existing = _installed(await invoke("copy-installed"))
        if existing is not None:
            return existing
        identity, payloads, cryptex_properties = await asyncio.to_thread(load_assets, asset_directory)
        chip = await invoke("read-personalization-id")
        identity_now = _udid(chip)
        domain = {"nonce-domain-handle": _uint(_required(identity, "Cryptex1,NonceDomain"))}
        nonce = _nonce(await invoke("get-nonce", domain))
        request = build_tss_request(identity, chip, nonce)
        ticket = await asyncio.wait_for(asyncio.to_thread(request_ticket, request), 65.0)
        # A reconnect/reboot while Apple was signing must not upload a stale ticket.
        if _udid(await invoke("read-personalization-id")) != identity_now:
            raise DdiError("The connected phone changed during personalization. Reconnect and retry.")
        if _nonce(await invoke("get-nonce", domain)) != nonce:
            raise DdiError("The phone's developer-image nonce changed. Retry to request a fresh ticket.")
        components = [("image", payloads["image"]), ("trustcache", payloads["trustcache"]),
                      ("im4m", ticket), ("info", payloads["info"]), ("volumehash", payloads["volumehash"])]
        arguments = {"auth": 0, "client-version": 3, "cryptex1-properties": cryptex_properties,
                     "image-type-index": services.XpcInt64(10), "nonce-persistence": 1, "persistence": 2}
        for index, (name, data) in enumerate(components, 1):
            arguments[name] = services.XpcFileTransfer(index, len(data))
        await invoke("install", arguments, [(index, data) for index, (_, data) in enumerate(components, 1)])
        installed = _installed(await invoke("copy-installed"))
        if installed is None:
            raise DdiError("The phone did not confirm the developer image after installation.")
        return installed

    try:
        return await asyncio.wait_for(prepare(), PREPARE_TIMEOUT)
    except asyncio.CancelledError:
        raise
    except asyncio.TimeoutError:
        raise DdiError("Developer-image recovery timed out. Keep the phone unlocked, connected to the tunnel and internet, then retry.") from None
    except services.ServiceError:
        raise
    except Exception:
        raise DdiError("Developer-image recovery failed. Check the tunnel, Developer Mode, bundled image and internet access.") from None
    finally:
        if rsd is not None:
            await rsd.aclose()
