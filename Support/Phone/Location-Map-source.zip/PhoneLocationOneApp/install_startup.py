"""Enable only AFTER the native screen and physical Set/Stop have been verified."""
import argparse
import os
import shutil
import sys
import tempfile

from phone_location import ROOT, runtime_check
from startup_profile import merge_profile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--enable-after-device-check', action='store_true', required=True)
    parser.parse_args()
    if sys.platform not in ('darwin', 'ios'):
        raise SystemExit('Startup installation is only for the iPhone host.')
    caps = runtime_check(native=True)
    if not caps['ready_for_device_probe']:
        raise SystemExit('The installed host did not pass native prerequisites.')
    if not (ROOT / 'private/pairing.plist').is_file():
        raise SystemExit('The existing pairing file must be imported first.')
    # Python's home is the container root, which iOS makes read-only.
    # a-Shell reads its startup file from the writable Documents directory.
    profile = ROOT.parent / '.profile'
    existing = profile.read_text(encoding='utf-8') if profile.exists() else ''
    new_profile = merge_profile(existing)
    if new_profile == existing:
        print('Native map startup is already configured.')
        return
    backup = profile.with_name('.profile.before-location-map')
    if profile.exists() and not backup.exists():
        shutil.copy2(profile, backup)
    with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=profile.parent,
                                     prefix='.location-map-profile-', delete=False) as pending:
        pending.write(new_profile)
    os.replace(pending.name, profile)
    print('Native map startup configured; the previous profile is preserved.')


if __name__ == '__main__':
    main()
