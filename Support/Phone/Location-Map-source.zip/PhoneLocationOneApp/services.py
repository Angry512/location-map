"""Small asynchronous RSD -> DTX location service client.

The caller owns pairing, the tunnel, and its userspace TCP dialer.  This module
does not open host sockets, initiate pairing, install a developer image, retry a
location command, or claim that a DTX acknowledgment proves GPS accuracy.

Wire formats follow the MIT-licensed idevice revision
89702099f4d7552f704f93b4526756abda319ceb (rsd, xpc, dvt/message,
dvt/remote_server and dvt/location_simulation).  The HTTP/2 opening order also
matches modern remoted: Headers#3 precedes the root termination message.
NSKeyedArchive encoding/decoding is provided by the separate bpylist2 package.

Developer-image behavior is deliberately explicit: a compatible personalized
DDI must already be mounted and Developer Mode enabled.  Missing dtservicehub or
failure to open LocationSimulation raises DeveloperServiceUnavailable; no DDI
download, personalization, installation, or Apple authentication is attempted.
"""

import asyncio
import contextlib
import math
import struct
import uuid
from dataclasses import dataclass

from bpylist2 import archiver


DVT_SERVICE = "com.apple.instruments.dtservicehub"
LOCATION_SERVICE = "com.apple.instruments.server.services.LocationSimulation"
SET_SELECTOR = "simulateLocationWithLatitude:longitude:"
CLEAR_SELECTOR = "stopLocationSimulation"
IO_TIMEOUT = 15.0
CONNECT_TIMEOUT = 35.0
MAX_XPC = 1024 * 1024
MAX_DTX = 2 * 1024 * 1024
MAX_FRAME = 1024 * 1024
MAX_FRAGMENTS = 64
HTTP2_PREFACE = b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n"
_HOST_UUID = uuid.uuid4()  # One identity for all RSD reconnects in this process.
_DTX_HEADER = struct.Struct("<IIHHIIIiI")
_PAYLOAD_HEADER = struct.Struct("<BBBBIII")


class ServiceError(Exception):
    """Sanitized user-facing service failure; never contains packet contents."""


class ProtocolError(ServiceError):
    pass


class DeveloperServiceUnavailable(ServiceError):
    pass


class CommandRejected(ServiceError):
    pass


class ServiceTimeout(ServiceError):
    pass


class XpcInt64(int):
    """Explicit signed integer, required for cryptexd's image-type-index."""


@dataclass(frozen=True)
class XpcFileTransfer:
    transfer_id: int
    size: int


def _archive(value):
    try:
        return archiver.archive(value)
    except Exception:
        raise ProtocolError("Cannot encode the developer-service request.") from None


def _unarchive(data):
    if not data:
        return None
    try:
        return archiver.unarchive(bytes(data))
    except Exception:
        raise ProtocolError("The developer service returned an unsupported archive.") from None


async def _close_writer(writer):
    if writer is None:
        return
    with contextlib.suppress(Exception):
        writer.close()
    with contextlib.suppress(Exception):
        await asyncio.wait_for(writer.wait_closed(), 2.0)


def _pad4(data):
    return data + b"\0" * (-len(data) % 4)


def _xpc_encode(value):
    """The bounded RSD subset: dictionaries, arrays, strings and scalar values."""
    if value is None:
        return struct.pack("<I", 0x1000)
    if isinstance(value, bool):
        return struct.pack("<II", 0x2000, value)
    if isinstance(value, XpcInt64):
        return struct.pack("<Iq", 0x3000, value)
    if isinstance(value, int):
        return struct.pack("<IQ", 0x4000, value)
    if isinstance(value, XpcFileTransfer):
        return struct.pack("<IQ", 0x1A000, value.transfer_id) + _xpc_encode({"s": value.size})
    if isinstance(value, float):
        return struct.pack("<Id", 0x5000, value)
    if isinstance(value, uuid.UUID):
        return struct.pack("<I", 0xA000) + value.bytes
    if isinstance(value, str):
        data = value.encode("utf-8") + b"\0"
        return struct.pack("<II", 0x9000, len(data)) + _pad4(data)
    if isinstance(value, bytes):
        return struct.pack("<II", 0x8000, len(value)) + _pad4(value)
    if isinstance(value, dict):
        entries = b"".join(_pad4(key.encode("utf-8") + b"\0") + _xpc_encode(item)
                           for key, item in value.items())
        body = struct.pack("<I", len(value)) + entries
        return struct.pack("<II", 0xF000, len(body)) + body
    if isinstance(value, list):
        body = struct.pack("<I", len(value)) + b"".join(_xpc_encode(item) for item in value)
        return struct.pack("<II", 0xE000, len(body)) + body
    raise ProtocolError("Unsupported RSD request type.")


class _XpcReader:
    def __init__(self, data):
        self.data = memoryview(data)
        self.offset = 0

    def take(self, length):
        if length < 0 or length > len(self.data) - self.offset:
            raise ProtocolError("The RSD response is truncated.")
        result = self.data[self.offset:self.offset + length].tobytes()
        self.offset += length
        return result

    def number(self, fmt):
        return struct.unpack(fmt, self.take(struct.calcsize(fmt)))[0]

    def object(self, depth=0):
        if depth > 32:
            raise ProtocolError("The RSD response is nested too deeply.")
        tag = self.number("<I")
        if tag == 0x1000:
            return None
        if tag == 0x2000:
            return bool(self.number("<I"))
        if tag in (0x3000, 0x4000, 0x7000):
            return self.number("<Q" if tag == 0x4000 else "<q")
        if tag == 0x5000:
            return self.number("<d")
        if tag == 0xA000:
            return uuid.UUID(bytes=self.take(16))
        if tag == 0x1A000:
            transfer_id = self.number("<Q")
            descriptor = self.object(depth + 1)
            size = descriptor.get("s") if isinstance(descriptor, dict) else None
            if isinstance(size, bool) or not isinstance(size, int) or size < 0:
                raise ProtocolError("Invalid RemoteXPC file descriptor.")
            return XpcFileTransfer(transfer_id, size)
        if tag in (0x8000, 0x9000):
            size = self.number("<I")
            data = self.take(size)
            self.take(-size % 4)
            if tag == 0x8000:
                return data
            if not data.endswith(b"\0"):
                raise ProtocolError("Invalid RSD string.")
            try:
                return data[:-1].decode("utf-8")
            except UnicodeDecodeError:
                raise ProtocolError("Invalid RSD string.") from None
        if tag in (0xE000, 0xF000):
            size = self.number("<I")
            end = self.offset + size
            if size < 4 or end > len(self.data):
                raise ProtocolError("Invalid RSD container length.")
            count = self.number("<I")
            if count > 16384:
                raise ProtocolError("The RSD response contains too many entries.")
            result = {} if tag == 0xF000 else []
            for _ in range(count):
                if tag == 0xF000:
                    begin = self.offset
                    while self.offset < end and self.data[self.offset] != 0:
                        self.offset += 1
                    if self.offset >= end:
                        raise ProtocolError("Invalid RSD dictionary key.")
                    try:
                        key = self.data[begin:self.offset].tobytes().decode("utf-8")
                    except UnicodeDecodeError:
                        raise ProtocolError("Invalid RSD dictionary key.") from None
                    self.offset += 1
                    self.take(-(self.offset - begin) % 4)
                    if key in result:
                        raise ProtocolError("Duplicate RSD dictionary key.")
                    result[key] = self.object(depth + 1)
                else:
                    result.append(self.object(depth + 1))
                if self.offset > end:
                    raise ProtocolError("Invalid RSD container length.")
            if self.offset != end:
                raise ProtocolError("Invalid RSD container length.")
            return result
        raise ProtocolError("The RSD response uses an unsupported XPC object.")


def _xpc_wrapper(value=None, flags=1, message_id=0):
    payload = b"" if value is None else struct.pack("<II", 0x42133742, 5) + _xpc_encode(value)
    return struct.pack("<IIQQ", 0x29B00B92, flags, len(payload), message_id) + payload


def _h2_frame(kind, stream, payload=b"", flags=0):
    if len(payload) > MAX_FRAME:
        raise ProtocolError("The RSD frame is too large.")
    return len(payload).to_bytes(3, "big") + bytes((kind, flags)) + struct.pack(">I", stream) + payload


class _Rsd:
    def __init__(self, reader, writer):
        self.reader, self.writer = reader, writer
        self.buffers = {1: bytearray(), 3: bytearray()}
        self.monitor = None

    async def send(self, kind, stream, payload=b"", flags=0):
        self.writer.write(_h2_frame(kind, stream, payload, flags))
        await self.writer.drain()

    async def frame(self):
        header = await self.reader.readexactly(9)
        size = int.from_bytes(header[:3], "big")
        kind, flags = header[3:5]
        stream = int.from_bytes(header[5:9], "big") & 0x7FFFFFFF
        if size > MAX_FRAME:
            raise ProtocolError("The RSD frame exceeds the size limit.")
        payload = await self.reader.readexactly(size)
        if kind == 4:  # SETTINGS
            if stream or (flags & 1 and payload) or len(payload) % 6:
                raise ProtocolError("Invalid RSD settings frame.")
            if not flags & 1:
                await self.send(4, 0, flags=1)
        elif kind == 6:  # PING
            if stream or len(payload) != 8:
                raise ProtocolError("Invalid RSD ping frame.")
            if not flags & 1:
                await self.send(6, 0, payload, flags=1)
        elif kind in (3, 7):
            if kind == 3 and stream in getattr(self, "finished_files", ()):
                return kind, flags, stream, payload
            raise ProtocolError("The phone closed the RSD connection.")
        return kind, flags, stream, payload

    async def discover(self):
        self.writer.write(HTTP2_PREFACE)
        await self.writer.drain()
        await self.send(4, 0, struct.pack(">HIHI", 3, 100, 4, 1024 * 1024))
        await self.send(8, 0, struct.pack(">I", 1024 * 1024 - 65535))
        await self.send(1, 1, flags=4)
        await self.send(0, 1, _xpc_wrapper({}))
        await self.send(1, 3, flags=4)
        await self.send(0, 1, _xpc_wrapper(flags=0x0201))
        await self.send(0, 3, _xpc_wrapper(flags=0x400001))
        # SETTINGS may be preceded by the peer's connection WINDOW_UPDATE.
        for _ in range(64):
            kind, flags, _, _ = await self.frame()
            if kind == 4 and not flags & 1:
                break
            if kind not in (4, 6, 8):
                raise ProtocolError("Unexpected frame during RSD startup.")
        else:
            raise ProtocolError("The phone did not provide RSD settings.")
        await self.send(0, 1, _xpc_wrapper({
            "MessageType": "Handshake", "MessagingProtocolVersion": 7,
            "UUID": _HOST_UUID,
            "Properties": {"RemoteXPCVersionFlags": 0x0100000000000006,
                           "SensitivePropertiesVisible": True},
            "Services": {},
        }, flags=0x101, message_id=1))
        while True:
            response = await self.receive()
            if isinstance(response, dict) and "Services" in response:
                return response

    async def receive(self):
        while True:
            for buffer in self.buffers.values():
                while len(buffer) >= 24:
                    magic, _, size, _ = struct.unpack("<IIQQ", buffer[:24])
                    if magic != 0x29B00B92 or size > MAX_XPC:
                        raise ProtocolError("Invalid RSD message header.")
                    if len(buffer) < 24 + size:
                        break
                    payload = bytes(buffer[24:24 + size])
                    del buffer[:24 + size]
                    if not payload:
                        continue
                    reader = _XpcReader(payload)
                    if reader.take(8) != struct.pack("<II", 0x42133742, 5):
                        raise ProtocolError("Unsupported RSD message version.")
                    value = reader.object()
                    if reader.offset != len(payload):
                        raise ProtocolError("Unexpected data after the RSD object.")
                    if value:
                        return value
            kind, flags, stream, payload = await self.frame()
            if kind != 0:
                continue
            if stream not in self.buffers or flags & 1:
                raise ProtocolError("The phone closed or replaced an RSD stream.")
            flow_size = len(payload)
            if flags & 8:  # DATA padding
                if not payload or payload[0] >= len(payload):
                    raise ProtocolError("Invalid RSD DATA padding.")
                payload = payload[1:len(payload) - payload[0]]
            buffer = self.buffers[stream]
            if len(buffer) + len(payload) > MAX_XPC + 24:
                raise ProtocolError("The RSD message exceeds the size limit.")
            buffer.extend(payload)
            if flow_size:
                await self.send(8, 0, struct.pack(">I", flow_size))
                await self.send(8, stream, struct.pack(">I", flow_size))

    async def keep_open(self):
        # Continue handling RSD control traffic while the DTX service is in use.
        try:
            while True:
                await self.receive()
        except (ServiceError, OSError, asyncio.IncompleteReadError):
            pass

    async def aclose(self):
        if self.monitor is not None:
            self.monitor.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self.monitor
        await _close_writer(self.writer)


class RemoteXpcConnection(_Rsd):
    """Bounded RemoteXPC RPC/file-upload transport for cryptexd.

    Only this object may read its stream. Sending pumps inbound control frames
    when flow control blocks, preserving early reply data for receive_reply().
    """
    def __init__(self, reader, writer):
        super().__init__(reader, writer)
        self.connection_window = 65535
        self.initial_window = 65535
        self.stream_windows = {}
        self.peer_frame_size = 16384
        self.finished_files = set()
        self.next_stream = 5
        self.next_message = 1

    async def _raw_send(self, kind, stream, payload=b"", flags=0):
        self.writer.write(_h2_frame(kind, stream, payload, flags))
        await self.writer.drain()

    async def send(self, kind, stream, payload=b"", flags=0):
        if kind != 0 or not payload:
            return await self._raw_send(kind, stream, payload, flags)
        offset = 0
        view = memoryview(payload)
        while offset < len(view):
            window = self.stream_windows.setdefault(stream, self.initial_window)
            count = min(self.connection_window, window, self.peer_frame_size,
                        16384, len(view) - offset)
            if count <= 0:
                try:
                    await asyncio.wait_for(self._pump(), 30.0)
                except asyncio.TimeoutError:
                    raise ServiceTimeout("The phone stopped accepting developer-image data.") from None
                continue
            self.connection_window -= count
            self.stream_windows[stream] -= count
            end = offset + count
            await self._raw_send(0, stream, view[offset:end].tobytes(),
                                 flags if end == len(view) else flags & ~1)
            offset = end

    async def frame(self):
        kind, flags, stream, payload = await super().frame()
        if kind == 4 and not flags & 1:
            for offset in range(0, len(payload), 6):
                setting, value = struct.unpack(">HI", payload[offset:offset + 6])
                if setting == 4:
                    if value > 0x7FFFFFFF:
                        raise ProtocolError("Invalid RemoteXPC initial window.")
                    delta = value - self.initial_window
                    self.initial_window = value
                    for key in self.stream_windows:
                        self.stream_windows[key] += delta
                elif setting == 5:
                    if not 16384 <= value <= 0xFFFFFF:
                        raise ProtocolError("Invalid RemoteXPC frame size.")
                    self.peer_frame_size = min(value, MAX_FRAME)
        elif kind == 8:
            if len(payload) != 4:
                raise ProtocolError("Invalid RemoteXPC window update.")
            increment = struct.unpack(">I", payload)[0] & 0x7FFFFFFF
            if not increment:
                raise ProtocolError("Invalid zero RemoteXPC window update.")
            if stream == 0:
                self.connection_window += increment
                value = self.connection_window
            else:
                if stream not in self.stream_windows and stream not in (1, 3):
                    raise ProtocolError("RemoteXPC updated an unopened stream.")
                value = self.stream_windows.setdefault(stream, self.initial_window) + increment
                self.stream_windows[stream] = value
            if value > 0x7FFFFFFF:
                raise ProtocolError("RemoteXPC send window overflow.")
        return kind, flags, stream, payload

    async def start(self):
        self.writer.write(HTTP2_PREFACE)
        await self.writer.drain()
        await self.send(4, 0, struct.pack(">HIHI", 3, 100, 4, 1024 * 1024))
        await self.send(8, 0, struct.pack(">I", 1024 * 1024 - 65535))
        await self.send(1, 1, flags=4)
        await self.send(0, 1, _xpc_wrapper({}))
        await self.send(1, 3, flags=4)
        await self.send(0, 1, _xpc_wrapper(flags=0x201))
        await self.send(0, 3, _xpc_wrapper(flags=0x400001))
        for _ in range(64):
            kind, flags, _, _ = await self._pump()
            if kind == 4 and not flags & 1:
                return
            if kind not in (4, 6, 8):
                raise ProtocolError("Unexpected frame during RemoteXPC startup.")
        raise ProtocolError("The phone did not provide RemoteXPC settings.")

    async def _pump(self):
        kind, flags, stream, payload = await self.frame()
        if kind == 0:
            if stream not in self.buffers:
                raise ProtocolError("Unexpected incoming RemoteXPC data stream.")
            flow_size = len(payload)
            if flags & 8:
                if not payload or payload[0] >= len(payload):
                    raise ProtocolError("Invalid RemoteXPC DATA padding.")
                payload = payload[1:len(payload) - payload[0]]
            buffer = self.buffers[stream]
            if len(buffer) + len(payload) > MAX_XPC + 24:
                raise ProtocolError("The RemoteXPC reply exceeds the size limit.")
            buffer.extend(payload)
            if flow_size:
                await self._raw_send(8, 0, struct.pack(">I", flow_size))
                await self._raw_send(8, stream, struct.pack(">I", flow_size))
            if flags & 1 and not payload:
                raise ProtocolError("The phone ended its RemoteXPC reply stream.")
        return kind, flags, stream, payload

    def _buffered_message(self):
        for stream, buffer in self.buffers.items():
            while len(buffer) >= 24:
                magic, flags, size, identifier = struct.unpack("<IIQQ", buffer[:24])
                if magic != 0x29B00B92 or size > MAX_XPC:
                    raise ProtocolError("Invalid RemoteXPC reply header.")
                if len(buffer) < 24 + size:
                    break
                body = bytes(buffer[24:24 + size])
                del buffer[:24 + size]
                if not body:
                    continue
                decoder = _XpcReader(body)
                if decoder.take(8) != struct.pack("<II", 0x42133742, 5):
                    raise ProtocolError("Unsupported RemoteXPC reply version.")
                value = decoder.object()
                if decoder.offset != len(body):
                    raise ProtocolError("Unexpected data after the RemoteXPC reply.")
                if value:
                    return stream, flags, identifier, value
        return None

    async def receive_reply(self, identifier):
        while True:
            result = self._buffered_message()
            if result is None:
                await self._pump()
                continue
            stream, flags, reply_id, value = result
            if stream != 3 or not flags & 0x20000 or reply_id != identifier:
                raise ProtocolError("The phone sent an uncorrelated RemoteXPC reply.")
            if not isinstance(value, dict):
                raise ProtocolError("The phone sent a non-dictionary RemoteXPC reply.")
            return value

    async def request(self, value):
        identifier = self.next_message
        self.next_message += 2
        await self.send(0, 1, _xpc_wrapper(value, flags=0x10101, message_id=identifier))
        return identifier

    async def send_file(self, transfer_id, data):
        if len(data) > 128 * 1024 * 1024:
            raise ProtocolError("The developer-image component exceeds the size limit.")
        stream = self.next_stream
        self.next_stream += 2
        await self.send(1, stream, flags=4)
        await self.send(0, stream, _xpc_wrapper(flags=0x100001, message_id=transfer_id))
        await self.send(0, stream, data)
        self.finished_files.add(stream)
        await self.send(0, stream, flags=1)


def _auxiliary(arguments):
    if not arguments:
        return b""
    body = bytearray()
    for tag, value in arguments:
        body.extend(struct.pack("<II", 10, tag))
        if tag == 3:
            body.extend(struct.pack("<I", value))
        elif tag == 2:
            body.extend(struct.pack("<I", len(value)))
            body.extend(value)
        else:
            raise ProtocolError("Unsupported DTX argument type.")
    return struct.pack("<IIQ", 0x1F0, 0, len(body)) + body


def _dtx_packet(identifier, channel, selector=None, arguments=(), conversation=0,
                message_type=2, expects_reply=True):
    auxiliary = _auxiliary(arguments)
    payload = b"" if selector is None else _archive(selector)
    body = _PAYLOAD_HEADER.pack(message_type, 0, 0, 0, len(auxiliary),
                                len(auxiliary) + len(payload), 0) + auxiliary + payload
    return _DTX_HEADER.pack(0x1F3D5B79, 32, 0, 1, len(body), identifier,
                            conversation, channel, int(expects_reply)) + body


@dataclass
class _DtxMessage:
    identifier: int
    conversation: int
    channel: int
    flags: int
    kind: int
    auxiliary: bytes
    payload: bytes


class LocationClient:
    """One serialized DTX channel; set/clear return only after a correlated ACK.

    ``aclose`` releases transports; it does not confirm a location reset.  Call
    and await ``clear`` explicitly before closing when a confirmed stop is needed.
    """
    def __init__(self, reader, writer, rsd):
        self.reader, self.writer, self.rsd = reader, writer, rsd
        self.lock = asyncio.Lock()
        self.identifier = 0
        self.closed = False
        self.fragments = {}
        self.buffered_bytes = 0

    async def _message(self):
        while True:
            values = _DTX_HEADER.unpack(await self.reader.readexactly(32))
            magic, header_size, index, count, size, identifier, conversation, channel, flags = values
            if (magic != 0x1F3D5B79 or not 32 <= header_size <= 256
                    or not 1 <= count <= MAX_FRAGMENTS or index >= count
                    or size > MAX_DTX or flags & ~1):
                raise ProtocolError("Invalid developer-service fragment header.")
            await self.reader.readexactly(header_size - 32)
            key = (identifier, conversation, channel)
            if count > 1 and index == 0:
                if key in self.fragments or len(self.fragments) >= 8 or size < 16:
                    raise ProtocolError("Invalid developer-service fragment sequence.")
                self.fragments[key] = [count, 1, size, flags, bytearray()]
                continue  # Fragment zero declares total length and has no body.
            data = await self.reader.readexactly(size)
            if count > 1:
                entry = self.fragments.get(key)
                if entry is None or entry[0] != count or entry[1] != index or entry[3] != flags:
                    raise ProtocolError("Out-of-order developer-service fragments.")
                if self.buffered_bytes + len(data) > MAX_DTX:
                    raise ProtocolError("Developer-service fragments exceed the size limit.")
                entry[4].extend(data)
                self.buffered_bytes += len(data)
                entry[1] += 1
                if index != count - 1:
                    continue
                del self.fragments[key]
                data = bytes(entry[4])
                self.buffered_bytes -= len(data)
                if len(data) != entry[2]:
                    raise ProtocolError("Developer-service fragment length mismatch.")
            if len(data) < 16:
                raise ProtocolError("The developer-service payload is truncated.")
            kind, a, b, reserved, aux_size, total_size, payload_flags = _PAYLOAD_HEADER.unpack(data[:16])
            if kind not in (0, 1, 2, 3, 4) or a or b or reserved or payload_flags:
                raise ProtocolError("Unsupported developer-service payload format.")
            if total_size != len(data) - 16 or aux_size > total_size:
                raise ProtocolError("Developer-service payload length mismatch.")
            return _DtxMessage(identifier, conversation, channel, flags, kind,
                               data[16:16 + aux_size], data[16 + aux_size:])

    async def _send(self, channel, selector, arguments=(), expects_reply=True):
        self.identifier += 1
        self.writer.write(_dtx_packet(self.identifier, channel, selector, arguments,
                                      expects_reply=expects_reply))
        await self.writer.drain()
        return self.identifier

    async def _control(self, message):
        if message.channel != 0 or message.conversation != 0 or message.kind != 2:
            return False
        selector = _unarchive(message.payload)
        if selector == "_channelCanceled:":
            raise ProtocolError("The phone canceled the location service.")
        if selector == "_notifyOfPublishedCapabilities:":
            if message.flags & 1:
                self.writer.write(_dtx_packet(message.identifier, 0, conversation=1,
                                              message_type=0, expects_reply=False))
                await self.writer.drain()
            return True
        return False

    async def _wait_ack(self, identifier, channel):
        for _ in range(128):
            message = await self._message()
            if await self._control(message):
                continue
            if message.identifier != identifier:
                continue
            if message.conversation != 1 or message.channel != channel or message.flags:
                raise ProtocolError("The developer service sent an invalid acknowledgment.")
            if message.kind == 4:
                raise CommandRejected("The phone rejected the developer-service request.")
            if message.auxiliary or message.kind not in (0, 3):
                raise ProtocolError("The developer service did not acknowledge the request.")
            if message.kind == 0 and message.payload:
                raise ProtocolError("Invalid empty developer-service acknowledgment.")
            if message.kind == 3 and _unarchive(message.payload) is not None:
                raise CommandRejected("The developer service returned an unexpected result.")
            return
        raise ProtocolError("Too many unrelated developer-service messages.")

    async def _exchange(self, channel, selector, arguments=()):
        identifier = await self._send(channel, selector, arguments)
        await self._wait_ack(identifier, channel)

    async def _open(self):
        capabilities = {"com.apple.private.DTXBlockCompression": 0,
                        "com.apple.private.DTXConnection": 1}
        await self._send(0, "_notifyOfPublishedCapabilities:",
                         [(2, _archive(capabilities))], expects_reply=False)
        for _ in range(128):
            message = await self._message()
            if await self._control(message):
                break
        else:
            raise ProtocolError("The developer-service capability handshake failed.")
        try:
            await self._exchange(0, "_requestChannelWithCode:identifier:",
                                 [(3, 1), (2, _archive(LOCATION_SERVICE))])
        except CommandRejected:
            raise DeveloperServiceUnavailable(
                "The location service is unavailable. Enable Developer Mode and mount a compatible developer image first; this app does not install developer images."
            ) from None

    async def _command(self, selector, arguments):
        async with self.lock:
            if self.closed:
                raise ServiceError("The location-service connection is closed.")
            try:
                await asyncio.wait_for(self._exchange(1, selector, arguments), IO_TIMEOUT)
            except asyncio.CancelledError:
                await self.aclose()
                raise
            except asyncio.TimeoutError:
                await self.aclose()
                raise ServiceTimeout("The phone did not acknowledge the location command; its location is unconfirmed.") from None
            except (ServiceError, OSError, asyncio.IncompleteReadError) as error:
                await self.aclose()
                if isinstance(error, ServiceError):
                    raise
                raise ServiceError("The phone's location-service connection ended; its location is unconfirmed.") from None

    async def set(self, lat, lon):
        if (isinstance(lat, bool) or isinstance(lon, bool)
                or not isinstance(lat, (int, float)) or not isinstance(lon, (int, float))
                or not math.isfinite(lat) or not math.isfinite(lon)
                or not -90 <= lat <= 90 or not -180 <= lon <= 180):
            raise ValueError("Use finite latitude from -90 to 90 and longitude from -180 to 180.")
        await self._command(SET_SELECTOR, [(2, _archive(float(lat))), (2, _archive(float(lon)))])

    async def clear(self):
        # Requiring a reply is intentional. If this iOS service only supports a
        # fire-and-forget Stop, report it as unconfirmed rather than claiming success.
        await self._command(CLEAR_SELECTOR, ())

    async def aclose(self):
        if self.closed:
            return
        self.closed = True
        await _close_writer(self.writer)
        await self.rsd.aclose()


async def connect_location(dial, server_address, rsd_port):
    """Discover DVT over a caller-supplied tunnel dialer and open LocationSimulation.

    ``dial(host, port)`` must return an asyncio-compatible ``(reader, writer)``.
    A successful connection changes no location.  A compatible DDI must already
    be mounted.  Set/Stop must be awaited, and only their successful return is a
    protocol acknowledgment; it is not a GPS/Find My accuracy guarantee.
    """
    if isinstance(rsd_port, bool) or not isinstance(rsd_port, int) or not 1 <= rsd_port <= 65535:
        raise ValueError("Invalid RSD port.")
    rsd = None
    client = None

    async def connect():
        nonlocal rsd, client
        reader, writer = await dial(server_address, rsd_port)
        rsd = _Rsd(reader, writer)
        peer = await rsd.discover()
        services = peer.get("Services")
        entry = services.get(DVT_SERVICE) if isinstance(services, dict) else None
        if not isinstance(entry, dict):
            raise DeveloperServiceUnavailable(
                "The phone did not advertise its developer service. Enable Developer Mode and mount a compatible developer image first; this app does not install developer images."
            )
        try:
            port = int(entry["Port"])
        except (KeyError, TypeError, ValueError):
            raise ProtocolError("The phone advertised an invalid developer-service port.") from None
        if not 1 <= port <= 65535 or isinstance(entry.get("Port"), bool):
            raise ProtocolError("The phone advertised an invalid developer-service port.")
        if entry.get("Properties", {}).get("UsesRemoteXPC", False):
            raise ProtocolError("The advertised developer service uses an unsupported transport.")
        reader, writer = await dial(server_address, port)
        client = LocationClient(reader, writer, rsd)
        rsd.monitor = asyncio.create_task(rsd.keep_open())
        await client._open()
        return client

    try:
        return await asyncio.wait_for(connect(), CONNECT_TIMEOUT)
    except BaseException as error:
        if client is not None:
            await client.aclose()
        elif rsd is not None:
            await rsd.aclose()
        if isinstance(error, asyncio.CancelledError):
            raise
        if isinstance(error, asyncio.TimeoutError):
            raise ServiceTimeout("The phone's developer-service connection timed out. Check the tunnel, Developer Mode and the mounted developer image.") from None
        if isinstance(error, (ServiceError, ValueError)):
            raise
        raise ServiceError("Could not open the phone's developer location service. Check the tunnel, Developer Mode and the mounted developer image.") from None
